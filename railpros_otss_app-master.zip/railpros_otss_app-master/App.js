// Imports: Dependencies
import React, { useState, useEffect, useRef } from "react";
import { View, Image } from "react-native";
import { PersistGate } from "redux-persist/es/integration/react";
import { Provider, useSelector } from "react-redux";
import * as SplashScreen from "expo-splash-screen";
import * as Font from "expo-font";
import * as Device from "expo-device";
import {
  FontAwesome,
  FontAwesome5,
  Ionicons,
  AntDesign,
  MaterialCommunityIcons,
} from "@expo/vector-icons";
import { StyleProvider, Root } from "native-base";
import * as Notifications from "expo-notifications";
import * as Location from "expo-location";
import Constants from "expo-constants";
import { AlertBox } from "react-native-alertbox";
import * as Sentry from "sentry-expo";
import * as ScreenOrientation from "expo-screen-orientation";
import { Camera } from "expo-camera";

import "react-native-get-random-values"; // this is required for uuid to work

import getTheme from "./src/theme/components";
import { FsAlert } from "./src/components/CustomComponents";
import material from "./src/theme/variables/material";
import ReduxNavigation from "./src/navigation/ReduxNavigation";
import { store, persistor } from "./src/store/store";
import { pollCurrentPosition } from "./src/sharedMethods/location";
// import { getFormBScreenRedirectionPermission } from './src/actions/common';
import { syncAppVersion } from "./src/actions/user";
import NetStateProvider from "./src/context/netStateContext";
import OfflineIntro from "./src/components/offline/OfflineIntro";
import BackOnlineModal from "./src/components/offline/BackOnlineModal";
import CheckForAppUpdates from "./src/components/CheckForAppUpdates";
import { SafeAreaProvider } from "react-native-safe-area-context";

Sentry.init({
  dsn: "https://6b087415253b4400a56a6b4db06a964d@o352785.ingest.sentry.io/5212865",
  enableInExpoDevelopment: true,
  debug: false,
  environment: process.env.NODE_ENV,
});

const splashScreen = require("./src/assets/images/splash.gif");

let notificationId = null;

const getBarCodeScannerPermissions = async () => {
  const { status } = await Camera.requestCameraPermissionsAsync();
  console.log(status);
};

const registerForPushNotificationsAsync = async () => {
  let token;

  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#FF231F7C",
    });
  }

  if (Device.isDevice && Constants.appOwnership !== "expo") {
    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;
    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }
    if (finalStatus !== "granted") {
      alert("Failed to get push token for push notification!");
      return;
    }
    // Learn more about projectId:
    // https://docs.expo.dev/push-notifications/push-notifications-setup/#configure-projectid
    token = (
      await Notifications.getExpoPushTokenAsync({
        projectId: Constants.expoConfig.extra.eas.projectId,
      })
    ).data;
    console.log(token);
  } else {
    alert("Must use physical device for Push Notifications");
  }

  return token;
};

const getNotificationId = async () => {
  notificationId = await registerForPushNotificationsAsync();
};

const App = (props) => {
  const [appVersionInfoShown, setAppVersionInfoShown] = useState(false);
  const [isReady, setIsReady] = useState(false);
  const responseListener = useRef();
  const { userData } = useSelector((state) => ({
    userData: state.auth.user,
  }));

  const initialize = async () =>
    await Promise.all([
      await Font.loadAsync({
        // 'Ionicons': require('native-base/Fonts/Ionicons.ttf'),
        ...Ionicons.font,
        ...FontAwesome.font,
        ...FontAwesome5.font,
        ...AntDesign.font,
        ...MaterialCommunityIcons.font,
        "Font-Light": require("./src/assets/fonts/Montserrat-Light.ttf"),
        "Font-Regular": require("./src/assets/fonts/Montserrat-Regular.ttf"),
        "Font-Semibold": require("./src/assets/fonts/Montserrat-SemiBold.ttf"),
        "Font-Bold": require("./src/assets/fonts/Montserrat-Bold.ttf"),
        "RobotoCondensed-Regular": require("./src/assets/fonts/RobotoCondensed-Regular.ttf"),
      }),
      await getLocationPermission(),
      () => SplashScreen.hideAsync(),
      await new Promise((resolve, reject) => {
        setTimeout(resolve, 2500);
      }),
      setIsReady(true),
    ]);

  const handleNotificationInteraction = async ({
    notification: {
      request: {
        content: { data },
      },
    },
  }) => {
    // This never worked properly, so it's commented out for now

    // const formBId = data.body ? data.body.formBId : data.formBId;
    // const redirectionDetails = await store.dispatch(
    //   getFormBScreenRedirectionPermission(formBId, userData.id)
    // );

    // if (redirectionDetails && redirectionDetails.error) {
    //   return FsAlert.alertOk(
    //     "Can't access to this protection's screen",
    //     redirectionDetails.error
    //   );
    // } else if (redirectionDetails) {
    //   return store.dispatch(
    //     NavigationActions.navigate({
    //       routeName: 'OthersFormBSScreen',
    //       params: { currentUserData: redirectionDetails.creatorData },
    //     })
    //   );
    // }

    return false;
  };

  useEffect(() => {
    getBarCodeScannerPermissions();
    getNotificationId();
    pollCurrentPosition(store.dispatch);
    // pollCurrentPositionInBackground(store.getState); // temporal - disabling background location tracking
    SplashScreen.hideAsync();
    ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
    initialize();
    responseListener.current =
      Notifications.addNotificationResponseReceivedListener(
        handleNotificationInteraction
      );

    return () => {
      Notifications.removeNotificationSubscription(responseListener);
    };
  }, []);

  useEffect(() => {
    if (userData && userData.app_version && !appVersionInfoShown) {
      const currentVersion = Constants.expoConfig.version;
      if (userData.app_version !== currentVersion) {
        setAppVersionInfoShown(true);
        FsAlert.alertOk(
          `OTSS has been updated!`,
          `OTSS has successfully updated to ${currentVersion}.`
        );
        syncAppVersion(userData.app_version);
      }
    }
  }, [userData]);

  const getLocationPermission = async () =>
    await Location.requestForegroundPermissionsAsync();

  if (!isReady && !props.skipLoadingScreen) {
    return (
      <View
        style={{
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          height: "100%",
        }}
      >
        <Image source={splashScreen} />
      </View>
    );
  }
  return <ReduxNavigation />;
};

// temporal - disabling background location tracking
// TaskManager.defineTask(LOCATION_TASK_NAME, ({ data, error }) => {
//   if (error) {
//     console.log('ERROR BG PROCESS', error.message);
//     return;
//   }
//   if (data && data.locations && data.locations.length > 0) {
//     const { locations } = data;
//     store.dispatch(setLocation(locations[0]));

//     const state = store.getState();

//     if (
//       state &&
//       state.auth &&
//       state.auth.user &&
//       Object.keys(state.auth.user).length !== 0
//     ) {
//       const { user } = state.auth;

//       const isOnDuty = getHasAlreadyReportedToDuty(user);

//       if (isOnDuty && notificationId) {
//         saveLocation(notificationId, locations[0]);
//       }
//     }
//   }
// });

export default () => (
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <StyleProvider style={getTheme(material)}>
        <Root>
          <SafeAreaProvider>
            <AlertBox />
            <NetStateProvider>
              <BackOnlineModal />
              <OfflineIntro />
              <CheckForAppUpdates />
              <App />
            </NetStateProvider>
          </SafeAreaProvider>
        </Root>
      </StyleProvider>
    </PersistGate>
  </Provider>
);
