import { Linking } from 'react-native';
import { NavigationActions } from 'react-navigation';
import isNil from 'lodash/isNil';
import moment from 'moment-timezone';

import { logoutUser } from '../actions/user';
import { FsAlert } from '../components/CustomComponents';
import { logout } from '../utils/api';

export const getRoleName = (roleId) => {
  switch (roleId) {
    case 1:
      return 'Senior VP';
    case 2:
      return 'Director';
    case 3:
      return 'Manager';
    case 4:
      return 'Supervisor';
    default:
      return 'Flagman';
  }
};

export const onPressCall = (userName, userPhoneNumber) => {
  if (isNil(userPhoneNumber) || userPhoneNumber.trim() === '') {
    FsAlert.alertOk(
      'Invalid Phone Number',
      `${userName} hasn't still set a valid phone number.`
    );
    return true;
  }
  return FsAlert.alertYesCancel(
    'Call',
    `Do you want to call ${userName}?`,
    'Yes',
    'No'
  )
    .then(() => {
      Linking.openURL(`tel:${userPhoneNumber}`);
    })
    .catch((err) => {});
};

export const onSendEmail = (userName, emailAddress) => {
  if (isNil(emailAddress)) {
    FsAlert.alertOk(
      'Invalid Email Address',
      `${userName} hasn't still set a valid email address.`
    );
    return true;
  }
  return FsAlert.alertYesCancel(
    'Email',
    `Do you want to send ${userName} an email?`,
    'Yes',
    'No'
  )
    .then(() => {
      Linking.openURL(`mailto:${emailAddress}`);
    })
    .catch((err) => {});
};

export const logoutAction = (navigation) => async (dispatch) => {
  try {
    await FsAlert.alertYesCancel(
      'Logout',
      `Are you sure that you want to logout?`,
      'Yes',
      'No'
    );
    await logout();
    dispatch(logoutUser());
    // stopBackgroundLocationTracking(); // temporal - disabling background location tracking
    await dispatch(NavigationActions.navigate({ routeName: 'Login' }));
  } catch (error) {}
};

export const getHasAlreadyReportedToDuty = (userData) => {
  let isOnDuty = false;

  const lastReportedToDutyInCurrentTimezone =
    userData.last_reported_to_duty_at_utc &&
    userData.last_reported_to_duty_at_utc !== null &&
    userData.last_reported_to_duty_timezone &&
    userData.last_reported_to_duty_timezone !== null
      ? moment(userData.last_reported_to_duty_at_utc).tz(
          userData.last_reported_to_duty_timezone
        )
      : false;

  const lastDebriefedInCurrentTimezone =
    userData.last_debriefed_at_utc &&
    userData.last_debriefed_at_utc !== null &&
    userData.last_debriefed_timezone &&
    userData.last_debriefed_timezone !== null
      ? moment(userData.last_debriefed_at_utc).tz(
          userData.last_debriefed_timezone
        )
      : false;
  if (
    lastReportedToDutyInCurrentTimezone &&
    (!lastDebriefedInCurrentTimezone ||
      (lastDebriefedInCurrentTimezone &&
        lastReportedToDutyInCurrentTimezone.isAfter(
          lastDebriefedInCurrentTimezone
        )))
  ) {
    isOnDuty = true;
  }
  return isOnDuty;
};

export const formatPhoneNumber = (phoneNumber) => {
  let result = phoneNumber.replace(/\D/g, '').substring(0, 10);

  const phoneNumberLength = result.length;

  if (phoneNumberLength === 0) {
    result = result;
  } else if (phoneNumberLength < 4) {
    result = `(${result.substring(0, 3)}`;
  } else if (phoneNumberLength < 7) {
    result = `(${result.substring(0, 3)}) ${result.substring(3, 6)}`;
  } else {
    result = `(${result.substring(0, 3)}) ${result.substring(
      3,
      6
    )}-${result.substring(6, 10)}`;
  }
  return result;
};
