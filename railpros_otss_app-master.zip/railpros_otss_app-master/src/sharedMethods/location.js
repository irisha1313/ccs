import * as Location from 'expo-location';
import { Platform, Linking } from 'react-native';
import { getHasAlreadyReportedToDuty } from './users';
import { FsAlert } from '../components/CustomComponents';
import { setLocation } from '../actions/location';

export const LOCATION_TASK_NAME = 'locationtracking';

export const verifyLocationPermissions = async (Linking, navigation) => {
  const { status } = await Location.requestForegroundPermissionsAsync();
  if (status !== 'granted') {
    if (navigation) {
      navigation.goBack();
    }
    return FsAlert.alertYesCancel(
      'Location Services Disabled',
      `Do you want to update your preferences?`,
      'Yes',
      'No'
    )
      .then(() => {
        Linking.openSettings();
      })
      .catch(() => {});
  }
  return status;
};

export const pollCurrentPosition = (dispatch) => {
  Location.watchPositionAsync(
    {
      accuracy: Location.Accuracy.Highest,
    },
    (location) => {
      dispatch(setLocation(location.coords));
    }
  );
};

export const getCurrentPosition = async (accuracy = 'Balanced') =>
  await Location.getCurrentPositionAsync({
    accuracy: Location.Accuracy[accuracy],
    maximumAge: 0,
  });

export const startBackgroundLocationTracking = () =>
  Location.startLocationUpdatesAsync(LOCATION_TASK_NAME, {
    accuracy: Location.Accuracy.BestForNavigation,
    distanceInterval: 10,
    showsBackgroundLocationIndicator: true,
    foregroundService: {
      notificationTitle: 'OTSS Tracking',
      notificationBody: 'Tracking your live location',
      notificationColor: '#4287f5',
    },
    pausesUpdatesAutomatically: false,
  });

export const stopBackgroundLocationTracking = () =>
  Location.stopLocationUpdatesAsync(LOCATION_TASK_NAME);

export const pollCurrentPositionInBackground = async (getState) => {
  const state = getState();
  if (
    state &&
    state.auth &&
    state.auth.user &&
    Object.keys(state.auth.user).length !== 0
  ) {
    const user = state.auth.user;
    const isOnDuty = getHasAlreadyReportedToDuty(user);

    if (isOnDuty) {
      return startBackgroundLocationTracking();
    }
  }
  return stopBackgroundLocationTracking();
};

export const navigateToCoords = async (flag) => {
  if (Platform.OS === 'ios') {
    try {
      const selectedOption = await FsAlert.alertOptionsCancel(
        'Opening Maps',
        `What maps service would you like use?`,
        ['Apple Maps', 'Google Maps']
      );
      if (selectedOption === 'Apple Maps') {
        const latLng = `${flag.established_gps_lat},${flag.established_gps_long}`;
        const url = `maps:0,0?q=Destination@${latLng}`;
        return Linking.openURL(url);
      }
    } catch (error) {
      return false;
    }
  }

  // launches google maps
  return Linking.openURL(
    `https://www.google.com/maps/dir/?api=1&destination=${flag.established_gps_lat},${flag.established_gps_long}&dir_action=navigate&travelmode=driving`
  );
};
