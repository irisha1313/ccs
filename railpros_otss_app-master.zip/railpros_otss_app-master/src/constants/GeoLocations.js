export default {
  // 1/40 miles
  MAX_DISTANCE_THRESHOLD: 0.025,
};
