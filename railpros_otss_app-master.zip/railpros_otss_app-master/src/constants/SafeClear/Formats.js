export default {
  receivedDateFormat: 'YYYY-MM-DD',
  displayDateFormat: 'MM/DD/YYYY',
  displayFullDateFormat: 'MM/DD/YYYY HH:mm',
  displayFullDateFormatWithTimezone: 'MM/DD/YYYY HH:mm z',
  displayHourFormat: 'HH:mm',
};
