export default {
    size: {
        xxxsmall: 10,
        xxsmall: 14,
        xsmall: 15,
        small: 16,
        nsmall: 18,
        normal: 20,
        big: 22,
        xbig: 24,
        xxbig: 26,
        xxxbig: 30,
        HowItWorksHeadliner: 44,
    }
};