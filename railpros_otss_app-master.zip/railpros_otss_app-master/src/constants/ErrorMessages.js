export default {
  NOINTERNET: 'No internet',
};
