export const USER_ROLES = Object.freeze({
  SeniorVP: 1,
  Director: 2,
  OrgManager: 3,
  Supervisor: 4,
  Flagmen: 5,
});
