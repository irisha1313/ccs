import React from 'react';
import _ from 'lodash';
import { View, Platform } from 'react-native';
import { Dropdown } from 'react-native-material-dropdown-v2';

import { Fonts, Colors } from '../../constants';
import { FsInputWithLabel, FsText } from '../../components/CustomComponents';
import styles from './styles';

class EditProfileForm extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
    };
  }
  render() {
    const { onChange, roles } = this.props;
    return (
      <View style={styles.EditProfileForm}>
        <FsText
          style={[
            {
              marginTop: 24,
              alignItems: 'center',
              textAlign: 'center',
              fontSize: Fonts.size.xbig,
              color: Colors.primaryLight,
            },
          ]}
        >
          General Information
        </FsText>
        <FsInputWithLabel
          name="name"
          label="NAME"
          selectTextOnFocus={true}
          returnKeyType="next"
          autoCorrect={true}
          autoCapitalize="words"
          containerStyle={[{ marginTop: 24 }]}
          onChangeText={(text) => {
            onChange('name', text);
          }}
        />
        <FsInputWithLabel
          name="email"
          label="EMAIL"
          selectTextOnFocus={true}
          returnKeyType="next"
          autoCapitalize="none"
          containerStyle={[{ marginTop: 24 }]}
          onChangeText={(text) => {
            this.setState({
              email: text,
            });
            onChange('email', text);
          }}
          value={this.state.email}
        />
        <FsInputWithLabel
          name="phone"
          label="PHONE (OPTIONAL)"
          keyboardType={Platform.select({
            ios: 'numbers-and-punctuation',
            android: 'default',
          })}
          selectTextOnFocus={true}
          returnKeyType="next"
          containerStyle={[{ marginTop: 24 }]}
          onChangeText={(text) => {
            onChange('phone', text);
          }}
        />
        <Dropdown
          containerStyle={[{ marginTop: 24 }]}
          containerStyle={[{ paddingHorizontal: 6 }]}
          baseColor={Colors.textSecondary}
          textColor={Colors.text}
          labelFontSize={12}
          fontSize={16}
          pickerStyle={[{ paddingHorizontal: 8 }]}
          label="Role"
          data={roles}
          onChangeText={(value, index, data) =>
            onChange('role_id', data[index].id)
          }
        />
      </View>
    );
  }
}

export default EditProfileForm;
