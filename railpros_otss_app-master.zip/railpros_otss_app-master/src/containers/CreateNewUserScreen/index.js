import React, { useState, useEffect } from 'react';
import _ from 'lodash';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Content, Fab } from 'native-base';

import { Colors, Icons, Styles } from '../../constants';
import { ScrollableScreen, FsAlert } from '../../components/CustomComponents';
import { useDispatch, useSelector } from 'react-redux';
import InviteNewUserForm from './form';
import { createUser, getRoles } from '../../actions/user';
import { showToast } from '../../utils/common';
import { Screen } from '../../components';

const CreateNewUserScreen = (props) => {
  const { currentOrganization } = useSelector((state) => ({
    currentOrganization: state.organizations.currentOrganization,
  }));

  const defaultUserState = {
    name: "",
    email: "",
    phone: "",
    role_id: null,
  };

  const dispatch = useDispatch();
  const [user, setUser] = useState(defaultUserState);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    onRefresh();
  }, []);

  const onRefresh = async () => {
    setLoading(true);
    const fetchedRoles = await getRoles();
    const formattedRoles = fetchedRoles.map((role) => ({
      ...role,
      value: role.name,
    }));
    setRoles(formattedRoles);
    setLoading(false);
  };

  const onChange = (attribute, newValue) => {
    setUser({
      ...user,
      [attribute]: newValue,
    });
  };

  const onPressSaveAndGoBack = () =>
    validateFormAndConfirmSave()
      .then()
      .catch(() => {});

  const validateFormAndConfirmSave = () => {
    if (!!!validateForm()) {
      return Promise.reject(null);
    }

    return confirmSave().then(() => doCreateUser());
  };

  const validateForm = () => {
    if (_.isEmpty(_.trim(user.name))) {
      FsAlert.alertOk("Name Missing", "Please fill in the new user's name.");
      return false;
    }

    if (_.isEmpty(_.trim(user.email)) || !user.email.endsWith("@railpros.com")) {
      FsAlert.alertOk(
        'Invalid Email Address',
        'Please enter a valid RailPros email address.'
      );
      return false;
    }

    if (_.isNil(user.role_id)) {
      FsAlert.alertOk(
        'Missing Role',
        'Please select a role for this new user.'
      );
      return false;
    }

    return true;
  };

  const confirmSave = () => {
    return FsAlert.alertYesCancel(
      "Confirm User Creation",
      `Are you sure that you want to create a user for ${user.email}?`,
      "Yes, Save"
    );
  };

  const defaultUserDataIsEqualToStateData = _.isEqual(defaultUserState, user);

  const doCreateUser = async () => {
    setLoading(true);
    try {
      if (!defaultUserDataIsEqualToStateData) {
        await dispatch(createUser(currentOrganization.settings.id, user));
      }
      props.navigation.goBack();
    } catch (error) {
      console.log(error);
      showToast("There is already a user with this email.", "danger");
    }
    setLoading(false);
  };

  return (
    <Screen title="Invite New User">
      <Content enableOnAndroid enableResetScrollToCoords={false} scrollEnabled={false}>
        <ScrollableScreen
          containerStyle={[{ paddingTop: 0 }]}
          refreshing={loading}
          onRefresh={onRefresh}
        >
          <InviteNewUserForm onChange={onChange} roles={roles} />
        </ScrollableScreen>
      </Content>
      <Fab
        onPress={() => onPressSaveAndGoBack().catch(() => {})}
        style={{ backgroundColor: Colors.primaryDark }}
      >
        <MaterialCommunityIcons
          name={'check'}
          size={Icons.size.big}
          color={
            defaultUserDataIsEqualToStateData
              ? Colors.secondaryDark
              : Colors.textLight
          }
          style={{ top: 1, maxWidth: 24, textAlign: "center" }}
        />
      </Fab>
    </Screen>
  );
};

// Exports
export default CreateNewUserScreen;
