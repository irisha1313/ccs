import React, { useState, useEffect } from 'react';
import { View, ImageBackground } from 'react-native';
import _ from 'lodash';
import { NavigationActions } from 'react-navigation';
import {
  Container,
  Content,
  Text,
  Button,
  Spinner,
  Row,
  Col,
} from 'native-base';
import { connect } from 'react-redux';
import { submit } from 'redux-form';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import AzureLogin from './AzureLogin';

import { Styles, Layout, Colors, Screens, Fonts } from '../../constants';
import { Logo } from '../../components';
import { FsButton } from '../../components/CustomComponents';
import imgs from '../../assets/images';
import * as userActions from '../../actions/user';
import { showToast } from '../../utils/common';
import appStyles from '../../theme/appStyles';
import styles from './styles';
import LoginForm from './form';
import { store } from '../../store/store';
import { pollCurrentPositionInBackground } from '../../sharedMethods/location';
import { USER_ROLES } from '../../utils/userRoles';
import { useIsOnline } from '../../context/netStateContext';

const Login = (props) => {
  const [loading, setLoading] = useState(false);
  const [displayNormalLayout, setDisplayNormalLayout] = useState(false);
  const isOnline = useIsOnline();

  useEffect(() => {
    if (isOnline) {
      props
        .autoLogin()
        .then(authenticate)
        .catch(() => {});
    } else {
      if (props.user) navigateDependingOnRole();
      else props.navigation.replace(Screens.NoInternet.route);
    }
  }, []);

  const navigateDependingOnRole = async () => {
    const { id, role_id } = props.user;

    if (isOnline) {
      // await registerForPushNotificationsAsync(id);
      props.navigate(
        [USER_ROLES.Director, USER_ROLES.SeniorVP, USER_ROLES.OrgManager, USER_ROLES.Supervisor].includes(role_id)
          ? 'HighRole'
          : 'NormalRole'
      );
    } else {
      props.navigate('SafeClearHomeScreen', { userData: props.user });
    }
    setLoading(false);
  };

  const authenticate = () => {
    if (props.user) {
      props.fetchFullUserData().then(navigateDependingOnRole);
    }
  };

  const handleAuthenticationError = (error) => {
    console.log(error, 'error');
    switch (error.response?.status) {
      case 403:
        props.logout();
        break;
      case 401:
        showToast('Invalid email/password', 'danger');
        break;
      default:
        props.navigation.replace(Screens.NoInternet.route);
    }
  };

  const registerForPushNotificationsAsync = async (userId) => {
    const { status } = await Notifications.requestPermissionsAsync();
    // only asks if permissions have not already been determined, because
    // iOS won't necessarily prompt the user a second time.
    // On Android, permissions are granted on app installation, so
    // `getAsync` will never prompt the user

    // Stop here if the user did not grant permissions
    if (status !== 'granted') {
      return;
    }

    // // Get the token that identifies this device
    const tokenData = await Notifications.getExpoPushTokenAsync();
    const token = tokenData.data;

    await userActions.addRegisterDeviceForUser(userId, token);

    return token;
  };

  const login = (values, dispatch) => {
    dispatch(
      userActions.login({ ...values, deviceID: Constants.installationId })
    )
      .then(authenticate)
      .catch(handleAuthenticationError);
  };

  const ssoLogin = (accessToken, dispatch) => {
    dispatch(
      userActions.ssoLogin({
        accessToken,
        deviceID: Constants.installationId,
      })
    )
      .then(authenticate)
      .catch(handleAuthenticationError);
  };

  const { language } = props;
  if (loading)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  const SSOLoginLayout = () => (
    <View style={{ flexDirection: 'column', flex: 1 }}>
      <View style={{ flex: 0.8, height: Layout.window.height - 250 }}>
        <View
          style={styles.loginBox}
        >
          <Logo style={appStyles.loginLogo} />
        </View>
        <View
          style={styles.loginBox}
        >
          {props.isLoading ? (
            <Spinner color={Colors.secondary} />
          ) : (
            <AzureLogin
              style={{
                ...appStyles.btnSecontary,
                fontFamily: Styles.constant.FontFamily,
                marginTop: 15,
              }}
              onSSOLogin={ssoLogin}
            />
          )}
        </View>
      </View>
    </View>
  );

  const NormalLoginLayout = () => (
    <View style={{ flexDirection: 'column', flex: 1 }}>
      <View style={{ flex: 0.8, height: Layout.window.height - 250 }}>
        <View style={appStyles.rowXcenter}>
          <Logo style={appStyles.loginLogo} />
          <Text
            style={[
              Fonts.primary,
              { color: Colors.black },
              { fontSize: Fonts.size.normal },
            ]}
          ></Text>
        </View>

        <View
          style={styles.loginBox}
        >
          <LoginForm onSubmit={login} />
        </View>
      </View>
      <View
        style={{ flex: 0.2, height: 80 }}
      >
        {props.isLoading ? (
          <Spinner color={Colors.secondary} />
        ) : (
          <Button
            full
            primary
            style={[
              appStyles.btnSecontary,
              { fontFamily: Styles.constant.FontFamily },
            ]}
            onPress={() => props.pressLogin()}
          >
            <Text> {language.login} </Text>
          </Button>
        )}
      </View>
    </View>
  );

  return (
    <Container style={appStyles.container}>
      <ImageBackground
        source={imgs.bg}
        style={{ width: Layout.window.width, height: Layout.window.height }}
      >
        <Content enableResetScrollToCoords={false} enableOnAndroid>
          <FsButton
            onPress={() => setDisplayNormalLayout(!displayNormalLayout)}
            style={{
              backgroundColor: 'white',
              marginTop: 50,
              position: 'absolute',
              width: '100%',
              zIndex: 1,
            }}
          />
          {displayNormalLayout ? <NormalLoginLayout /> : <SSOLoginLayout />}
        </Content>
      </ImageBackground>
    </Container>
  );
};
// Map State To Props (Redux Store Passes State To Component)
const mapStateToProps = (state) => {
  // Redux Store --> Component
  return {
    isLoading: state.common.isLoading,
    user: state.auth.user,
    language: state.auth.language,
    languageSet: state.auth.languageSet || 0,
  };
};

// Map Dispatch To Props (Dispatch Actions To Reducers. Reducers Then Modify The Data And Assign It To Your Props)
const mapDispatchToProps = (dispatch) => {
  // Action
  return {
    pressLogin: () => dispatch(submit('loginForm')),
    setLanguage: () => dispatch(userActions.setLanguage({ id: 1, set: 1 })),
    navigate: (routeName, params) =>
      dispatch(NavigationActions.navigate({ routeName, params })),
    logout: () => dispatch(userActions.logoutUser()),
    fetchFullUserData: () => dispatch(userActions.fetchFullUserData()),
    autoLogin: () => dispatch(userActions.autoLogin()),
  };
};

// Exports
export default connect(mapStateToProps, mapDispatchToProps)(Login);
