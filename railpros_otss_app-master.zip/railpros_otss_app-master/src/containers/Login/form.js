import React from 'react';
import _ from 'lodash';
import { Field, reduxForm } from 'redux-form';
import { connect } from "react-redux";
import { Form } from 'native-base';
import { InputBox } from '../../components';
import styles from './styles';

class LoginForm extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { handleSubmit, onSubmit, language } = this.props;
    return (
      <Form onSubmit={handleSubmit(onSubmit)} style={styles.loginForm}>
        <Field
          name="email"
          component={InputBox}
          placeholder={language.email}
          keyboardType={'email-address'}
          icon='user'
          iconStyle={{ top: 5, paddingLeft: 0, marginLeft: 0, left: 0 }}
        />
        <Field
          name="password"
          type="password"
          component={InputBox}
          placeholder={language.password}
          secureTextEntry={true}
          icon='lock'
          iconStyle={{ top: 5, paddingLeft: 0 }}
        />
      </Form>
    )
  }
}


const loginform = reduxForm({
  form: 'loginForm',
})(LoginForm);

const mapStateToProps = (state) => {
  return {
    language: state.auth.language,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(loginform);
