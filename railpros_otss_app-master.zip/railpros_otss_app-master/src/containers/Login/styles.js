import { Colors, Layout } from '../../constants/';
export default {
  itemStyle: {
    marginLeft: 0
  },
  loginBox: {
    marginTop: 0,
    marginLeft: 0,
    marginRight: 0,
    flex: 1,
  },
  linkTextBtn: {
    marginTop: Layout.indent
  },
  linkText: {
    textTransform: 'capitalize',
    color: Colors.black,
    fontSize: 16,
    fontFamily: 'Font-Regular',
  },
  loginForm: {
    marginTop: Layout.doubleIndent,
  }
};