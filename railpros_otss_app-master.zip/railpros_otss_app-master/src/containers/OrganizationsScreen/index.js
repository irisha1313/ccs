import React, { useState, useEffect, useContext } from 'react';
import { FlatList, View } from 'react-native';
import { NavigationContext, NavigationActions } from 'react-navigation';
import { useDispatch, useSelector } from 'react-redux';
import _ from 'lodash';
import moment from 'moment-timezone';

import { Loader, Screen } from '../../components';
import { ScrollableScreen, FsText } from '../../components/CustomComponents';
import {
  getUserOrganizations,
  clearOrganizationData,
} from '../../actions/organizations';
import EntryButton from '../../components/EntryButton';
import { Fonts, Colors } from '../../constants';
import { USER_ROLES } from '../../utils/userRoles';

const OrganizationsScreen = (props) => {
  const dispatch = useDispatch();
  const [sortedOrganizations, setSortedOrganizations] = useState(null);
  const { userData, orgsData } = useSelector((state) => {
    return {
        userData: state.auth.user,
        orgsData: state.organizations.allOrganizations,
      };
    },
  );
  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();

  useEffect(() => {
    if (isNavigationFocus) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  useEffect(() => {
    if (orgsData && orgsData.length > 0 && isNavigationFocus) {
      const groupedByDirector = _.chain(groupBy(orgsData, 'directorName'))
        .toPairs() // turn the object into an array of [key, value] pairs
        .sortBy(0) // sort these pairs by index [0] which is [key]
        .fromPairs() // convert array of pairs back into an object {key: value}
        .value();

      const sortedDataByDirector = Object.values(groupedByDirector).reduce(
        (accumulator, currentValue, currentIndex) => ({
          ...accumulator,
          [Object.keys(groupedByDirector)[currentIndex] ||
          '']: currentValue.sort((a, b) => {
            if (a && b) return a.name > b.name;
            return false;
          }),
        }),
        {}
      );
      setSortedOrganizations(sortedDataByDirector);
    } else {
      setSortedOrganizations(null);
    }
  }, [orgsData]);

  const onRefresh = async () => {
    await getOrganizationsForUser();
    dispatch(clearOrganizationData);
  };

  const groupBy = (xs, key) => {
    return xs.reduce((rv, x) => {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };

  const getOrganizationsForUser = async () => {
    dispatch(getUserOrganizations());
  };

  const onPropertyPress = (orgId) => () => {
    props.navigation.navigate('OrganizationScreen', { orgId });

    // TODO: remove after more tests
    // if (userData.role_id === USER_ROLES.Supervisor) {
    //   props.navigation.navigate('FormTabScreen');
    // } else {
    //   props.navigation.navigate('OrganizationScreen', { orgId });
    // }
  };

  if (!sortedOrganizations) return <Loader />;

  return (
    <Screen title="Properties" hasBackButton={false}>
      <ScrollableScreen
        containerStyle={[{ paddingTop: 0 }]}
        refreshing={!sortedOrganizations}
        onRefresh={onRefresh}
      >
        <FlatList
          data={Object.entries(sortedOrganizations)}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => JSON.stringify(item)}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => {
            const [directorName, directorOrganizations] = rowData.item;
            return (
              <View
                style={{
                  borderWidth: 1,
                  borderColor: '#b0b0b0',
                  marginHorizontal: 5,
                  marginVertical: 5,
                  borderRadius: 10,
                }}
              >
                {directorName !== 'undefined' && directorName !== 'null' ? (
                  <FsText
                    style={{
                      paddingHorizontal: 5,
                      paddingTop: 10,
                      paddingBottom: 5,
                      fontSize: Fonts.size.big,
                      color: Colors.secondaryDark,
                      fontWeight: '600',
                    }}
                  >
                    {directorName}
                  </FsText>
                ) : (
                  <View
                    style={{
                      borderWidth: 0.5,
                      borderColor: Colors.divider,
                    }}
                  />
                )}
                <FlatList
                  data={directorOrganizations}
                  listKey={moment().valueOf().toString()}
                  keyExtractor={(item) => JSON.stringify(item)}
                  scrollEnabled={false}
                  showsVerticalScrollIndicator={false}
                  renderItem={(rowData) => (
                    <EntryButton
                      onPress={onPropertyPress(rowData.item.id)}
                      customIcon={rowData.item.logo_url}
                      icon="th-list"
                      badge={rowData.item.activeJobs}
                      badgeStatus="primary"
                      text={rowData.item.name}
                    />
                  )}
                  contentContainerStyle={[{ marginTop: 12 }]}
                />
              </View>
            );
          }}
          contentContainerStyle={[{ marginTop: 12 }]}
        />
      </ScrollableScreen>
    </Screen>
  );
};

// Exports
export default OrganizationsScreen;
