import React, { useState, useEffect } from 'react';
import { FlatList } from 'react-native';
import _ from 'lodash';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { NavigationActions } from 'react-navigation';
import { Spinner, View, Fab } from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment-timezone';

import { Colors, Icons } from '../../constants';
import { FsAlert } from '../../components/CustomComponents';

import { transferUser } from '../../actions/user';
import EntryButton from '../../components/EntryButton';
import { getAllOrganizations } from '../../actions/organizations';
import Screen from '../../components/Screen';

const UserOrgTransfer = (props) => {
  const dispatch = useDispatch();
  const [availableOrganizations, setAvailableOrganizations] = useState(null);
  const [selectedUserData, setSelectedUserData] = useState(null);
  const [selectedOrgId, setSelectedOrgId] = useState(null);

  const { currentOrganizationId } = useSelector((state) => ({
    currentOrganizationId: state.organizations.currentOrganization.settings.id,
  }));

  // on mount actions
  useEffect(() => {
    initialize();
  }, []);

  const initialize = async () => {
    const allOrgs = await getAllOrganizations();
    const currentUser = props.navigation.getParam('currentUser');
    setAvailableOrganizations(allOrgs);
    setSelectedUserData(currentUser);
    setSelectedOrgId(currentOrganizationId);
  };

  const handleSaveChanges = async () => {
    try {
      const selectedOrg = availableOrganizations.find(
        (orgData) => orgData.id === selectedOrgId
      );
      await FsAlert.alertYesCancel(
        `Transfer ${selectedUserData.name}`,
        `Are you sure about transfering ${selectedUserData.name} to ${selectedOrg.name}?`
      );
      dispatch(
        transferUser(selectedUserData.id, selectedOrgId, currentOrganizationId)
      );
      dispatch(
        NavigationActions.navigate({
          routeName: 'OrganizationScreen',
          action: {
            type: 'Navigation/NAVIGATE',
            routeName: 'OrganizationScreen',
            params: { orgId: currentOrganizationId },
          },
        })
      );
    } catch (error) {}
  };

  if (!availableOrganizations || !selectedUserData)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  const canSaveChanges = selectedOrgId !== currentOrganizationId;
  return (
    <Screen title={`Transfer ${selectedUserData.name}`}>
      <FlatList
        data={availableOrganizations}
        listKey={moment().valueOf().toString()}
        keyExtractor={(item) => JSON.stringify(item)}
        showsVerticalScrollIndicator={false}
        renderItem={(rowData) => (
          <EntryButton
            onPress={() => setSelectedOrgId(rowData.item.id)}
            customIcon={rowData.item.logo_url}
            icon="th-list"
            chevron={
              rowData.item.id === selectedOrgId ? 'check' : 'square-outline'
            }
            text={rowData.item.name}
          />
        )}
        contentContainerStyle={[{ marginTop: 12 }]}
      />
      {canSaveChanges && (
        <Fab
          style={{ backgroundColor: Colors.secondary }}
          onPress={handleSaveChanges}
        >
          <MaterialCommunityIcons
            name={'check'}
            size={Icons.size.normal}
            color={Colors.textLight}
            style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
          />
        </Fab>
      )}
    </Screen>
  );
};

// Exports
export default UserOrgTransfer;
