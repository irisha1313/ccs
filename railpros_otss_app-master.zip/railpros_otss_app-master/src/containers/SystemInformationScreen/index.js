import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import _ from 'lodash';
import { useSelector } from 'react-redux';
import * as Device from 'expo-device';
import NetInfo from '@react-native-community/netinfo';

import { Colors, Styles, Fonts } from '../../constants';
import { ScrollableScreen, FsText } from '../../components/CustomComponents';
import { Screen } from '../../components';

const SystemInformationScreen = ({ navigation }) => {
  const { location } = useSelector(({ auth, location }) => ({
    userData: auth.user,
    location,
  }));
  const [networkData, setNetworkData] = useState(null);

  const deviceData = {
    isDevice: Device.isDevice,
    brand: Device.brand,
    manufacturer: Device.manufacturer,
    modelName: Device.modelName,
    modelId: Device.modelId,
    designName: Device.designName,
    productName: Device.productName,
    deviceYearClass: Device.deviceYearClass,
    totalMemory: Device.totalMemory,
    supportedCpuArchitectures: Device.supportedCpuArchitectures,
    osName: Device.osName,
    osVersion: Device.osVersion,
    osBuildId: Device.osBuildId,
    osInternalBuildId: Device.osInternalBuildId,
    deviceName: Device.deviceName,
  };

  useEffect(() => {
    const getNetInfoListener = NetInfo.addEventListener(
      (fetchedNetworkData) => {
        setNetworkData(fetchedNetworkData);
      }
    );

    return () => {
      getNetInfoListener();
    };
  }, []);

  return (
    <Screen onBackPress={() => navigation.goBack()} title="System Information">
      <ScrollableScreen containerStyle={{ paddingTop: 0, paddingBottom: 240 }}>
        <View
          style={{
            marginHorizontal: 8,
            marginVertical: 10,
            borderRadius: Styles.constant.BorderRadius,
          }}
        >
          <FsText
            style={{
              paddingLeft: 10,
              paddingTop: 10,
              marginBottom: 5,
              alignItems: 'center',
              textAlign: 'left',
              fontSize: Fonts.size.small,
              color: Colors.textGrey,
              fontWeight: 'bold',
            }}
          >
            Network Data
          </FsText>
          <FsText
            style={{
              paddingTop: 5,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Network type: {networkData ? networkData.type : 'loading...'}
          </FsText>
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Network connection established:{' '}
            {networkData ? networkData.isConnected.toString() : 'loading...'}
          </FsText>
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Is internet reachable:{' '}
            {networkData && networkData.isInternetReachable !== null
              ? networkData.isInternetReachable.toString()
              : 'loading...'}
          </FsText>
          <FsText
            style={{
              paddingLeft: 10,
              paddingTop: 15,
              marginBottom: 5,
              alignItems: 'center',
              textAlign: 'left',
              fontSize: Fonts.size.small,
              color: Colors.textGrey,
              fontWeight: 'bold',
            }}
          >
            Device Data
          </FsText>
          <FsText
            style={{
              paddingTop: 5,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Location accuracy:{' '}
            {location ? `${location.accuracy.toFixed(2)} meters` : 'No data'}
          </FsText>
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Operating system: {deviceData.osName} {deviceData.osVersion}
          </FsText>
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
            }}
          >
            Total ram: {(deviceData.totalMemory / 1000000).toFixed(2)} MBs
          </FsText>
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

export default SystemInformationScreen;
