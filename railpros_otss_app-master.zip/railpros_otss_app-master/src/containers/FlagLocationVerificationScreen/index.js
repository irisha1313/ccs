import React from 'react';
import {
  Platform,
  View,
  Dimensions,
  Image,
  PixelRatio,
  Linking,
} from 'react-native';
import {
  Container,
  Button,
  Header,
  Body,
  Title,
  Spinner,
  Text,
} from 'native-base';
import MapView, { Marker, PROVIDER_GOOGLE, Callout } from 'react-native-maps';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { connect } from 'react-redux';
import _ from 'lodash';
import haversine from 'haversine';

import { Styles, Colors, Icons, GeoLocations } from '../../constants';
import { FsAlert, FsButton, FsText } from '../../components/CustomComponents';
import { FlagLabelMarker, HeaderMessageCallout } from '../../components';
import { getFlagIcon, getFlagCoordinate } from '../../sharedMethods/flags';
import {
  verifyLocationPermissions,
  getCurrentPosition,
} from '../../sharedMethods/location';
import { toggleFlagEstablishment } from '../../actions/flags';
import { getFlagType } from '../../sharedMethods/flags';

const iosEdgePadding = { top: 50, right: 30, bottom: 50, left: 30 };

const androidEdgePadding = {
  top: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.top),
  right: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.right),
  bottom: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.bottom),
  left: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.left),
};

const edgePadding =
  Platform.OS === 'android' ? androidEdgePadding : iosEdgePadding;

const HeaderMessageCalloutLocation = (props) => {
  return (
    <HeaderMessageCallout {...props}>
      <View
        style={{
          marginTop: 4,
          display: 'flex',
          flexDirection: 'row',
          alignSelf: 'center',
          justifyContent: 'center',
          alignItems: 'center',
          width: '90%',
        }}
      >
        <Image
          source={require('../../assets/images/ic_gps_indicator.png')}
          style={{ tintColor: '#6d6d6d', width: 40, height: 40 }}
        />
        <FsText
          style={{
            padding: 6,
            textAlign: 'center',
          }}
        >
          {props.text}
        </FsText>
      </View>
    </HeaderMessageCallout>
  );
};

class FlagLocationVerificationScreen extends React.Component {
  constructor(props) {
    super(props);
    const flag = props.navigation.getParam('flag', {});
    const flags = props.navigation.getParam('flags', []);
    this.state = {
      flag,
      flags,
      marginBottom: 1,
      loading: true,
      currentPosition: null,
      loadingLocation: false,
      mapRef: null,
      isCalloutVisible: true,
      calloutText:
        'Tap the target icon to get an accurate fix on your current position.',
    };
  }

  async componentDidMount() {
    await verifyLocationPermissions(Linking, this.props.navigation);
    this.setState({ loading: false });
  }

  fetchCurrentLocation = async () => {
    const currentPosition = await getCurrentPosition('BestForNavigation');
    return {
      ...currentPosition.coords,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  };

  redirectToCurrentLoc = async () => {
    const { isDerail, isFormB } = getFlagType(this.state.flag);
    this.setState({
      loadingLocation: true,
      isCalloutVisible: true,
      calloutText: `If the pin's location is correct, tap the ${
        this.state.flag.is_established ? 'Close' : 'Open'
      } button in the top right to ${
        this.state.flag.is_established ? 'close' : 'open'
      } your ${isDerail ? 'derail' : isFormB ? 'flag' : 'switch'}.`,
    });
    const currentPosition = await this.fetchCurrentLocation();
    this.setState({
      currentPosition,
      loadingLocation: false,
    });
    this.state.mapRef &&
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
  };

  handleFlagToggling = async () => {
    const { isDerail, isFormB } = getFlagType(this.state.flag);
    const currentPosition =
      this.state.currentPosition || this.props.currentLocation;
    const userCoords = {
      latitude: currentPosition.latitude,
      longitude: currentPosition.longitude,
    };
    const flagCoords = {
      latitude: this.state.flag.established_gps_lat,
      longitude: this.state.flag.established_gps_long,
    };
    const distanceBetweenUserAndFlag = haversine(userCoords, flagCoords, {
      unit: 'mile',
    });
    const numberOfOpenFlags = this.state.flags.filter(
      (flag) => flag.is_established
    ).length;
    if (distanceBetweenUserAndFlag > GeoLocations.MAX_DISTANCE_THRESHOLD) {
      FsAlert.alertOk(
        'Too Far Away',
        `You have to be within ${
          GeoLocations.MAX_DISTANCE_THRESHOLD
        } miles of your ${
          isDerail ? 'derail' : isFormB ? 'flag' : 'switch-lock'
        } and you are ${distanceBetweenUserAndFlag.toFixed(2)} miles away.`
      );
    } else if (
      this.state.flag.is_established &&
      this.state.flag.type === 'yellow-red' &&
      this.state.flag.paired &&
      this.state.flag.paired.find(
        (pairedFlag) =>
          pairedFlag.type === 'red' && pairedFlag.is_established
      )
    ) {
      FsAlert.alertOk(
        'Paired Red Flag Still Open',
        'Please make sure you close all of the red flags associated to this one before trying to close it.'
      );
    } else if (
      !this.state.flag.is_established &&
      this.state.flag.type === 'red' &&
      this.state.flag.paired &&
      this.state.flag.paired.find(
        (pairedFlag) =>
          pairedFlag.type === 'yellow-red' && !pairedFlag.is_established
      )
    ) {
      FsAlert.alertOk(
        'Paired Flags Inactive',
        'Please make sure all your paired yellow-red are open before opening this flag.'
      );
    } else if (
      !this.state.flag.is_established &&
      this.state.flag.type === 'red' &&
      this.state.flag.paired &&
      this.state.flag.paired.find(
        (pairedFlag) =>
          (pairedFlag.type === 'lh' && !pairedFlag.is_established) ||
          (pairedFlag.type === 'rh' && !pairedFlag.is_established)
      )
    ) {
      FsAlert.alertOk(
        'Paired Flags Inactive',
        'Please make sure all your paired derails are open before opening this flag.'
      );
    } else if (
      this.state.flag.is_established &&
      numberOfOpenFlags === 1 &&
      this.props.currentOrganization.settings.debrief_with_dispatch
    ) {
      try {
        await FsAlert.alertYesCancel(
          'Methods Removal Verification',
          `Have all applicable methods of protection (flags, derails, lock switches) been removed from the property and all persons and equipment clear for the night?`,
          'Yes',
          'No'
        );
        const toggledFlag = await this.props.toggleFlag(
          this.state.flag,
          this.props.userData.id,
          this.props.currentOrganization.settings.id
        );
        this.setState({ flag: toggledFlag });
        this.props.navigation.goBack();
      } catch (err) {}
    } else {
      const toggledFlag = await this.props.toggleFlag(
        this.state.flag,
        this.props.userData.id,
        this.props.currentOrganization.settings.id
      );
      this.setState({ flag: toggledFlag });
      this.props.navigation.goBack();
    }
    return;
  };

  render() {
    if (this.state.loading)
      return (
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <Spinner color={Colors.secondary} />
        </View>
      );

    return (
      <Container>
        <Header style={{ ...Styles.general.header, paddingTop: 0, height: 56 }}>
          <Button
            onPress={() => {
              this.props.navigation.goBack();
            }}
            style={{ ...Styles.general.headerButton }}
          >
            <MaterialCommunityIcons
              name={'arrow-left'}
              size={Icons.size.big}
              color={Colors.textLight}
              style={[{ top: 1 }, { maxWidth: 20 }, { textAlign: 'center' }]}
            />
          </Button>
          <Body style={{ paddingLeft: 40, alignItems: 'center' }}>
            <Title style={{ paddingLeft: 0 }}>
              {this.state.flag.type === 'red' ||
              this.state.flag.type === 'yellow-red'
                ? `Flag @ MP ${this.state.flag.mile_post}`
                : `${this.state.flag.type} ${this.state.flag.serial_number}`}
            </Title>
          </Body>
          <Button
            onPress={() => {
              this.handleFlagToggling();
            }}
            style={{ ...Styles.general.headerButton }}
          >
            <Text style={{ fontWeight: 'bold' }}>
              {this.state.flag.is_established ? 'Close' : 'Open'}
            </Text>
          </Button>
        </Header>
        <View style={{ flex: 1 }}>
          {!this.state.mapRef && (
            <View
              style={{
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Spinner color={Colors.secondary} />
            </View>
          )}
          <MapView
            {...Platform.select({
              ios: {
                provider: PROVIDER_GOOGLE,
              },
              android: {
                provider: PROVIDER_GOOGLE,
              },
            })}
            ref={(ref) => {
              if (!this.state.mapRef) {
                this.setState({ mapRef: ref });
              }
            }}
            style={[
              { width: Dimensions.get('window').width },
              {
                height:
                  Dimensions.get('window').height -
                  Styles.constant.StackNavigatorHeaderBarHeight,
              },
              { alignSelf: 'center' },
              { flex: 1 },
              { marginBottom: this.state.marginBottom },
            ]}
            mapType="hybrid"
            showsUserLocation={true}
            moveOnMarkerPress={false}
            onLayout={this.onLayoutMap}
            mapPadding={Styles.constant.MapViewEdgePaddingGoogleMaps}
          >
            <Marker
              key={'Marker' + this.state.flag.id}
              coordinate={getFlagCoordinate(this.state.flag)}
              pinColor={getFlagIcon(this.state.flag.type)}
            />
            <FlagLabelMarker
              {...getFlagType(this.state.flag)}
              key={'FlagLabelMarker' + this.state.flag.id}
              flag={this.state.flag}
            />
          </MapView>
          {this.state.mapRef && (
            <RedirectToCurrentLoc
              onPress={this.redirectToCurrentLoc}
              loading={this.state.loadingLocation}
            />
          )}
          {this.state.isCalloutVisible && (
            <HeaderMessageCalloutLocation
              text={this.state.calloutText}
              onPress={() => this.setState({ isCalloutVisible: false })}
            />
          )}
        </View>
      </Container>
    );
  }

  /**
   * We can't perform actions within the
   * componentDidMount method to manipulate <MapView>
   * as, it would most likely crash on Android devices.
   * Therefore, we need to provide any initializing methods
   * for it, over here.
   */
  onLayoutMap = async () => {
    const { flag } = this.state;

    const flagWithCoordinates = getFlagCoordinate(flag);
    this.state.mapRef &&
      this.state.mapRef.fitToCoordinates(_.cloneDeep([flagWithCoordinates]), {
        edgePadding,
        animated: true,
      });
  };
}

const RedirectToCurrentLoc = (props) => {
  return (
    <Callout
      style={[
        { alignSelf: 'flex-end' },
        { bottom: 30 },
        { zIndex: 99999999 },
        { right: 10 },
      ]}
    >
      <FsButton
        style={[
          { height: 60 },
          { width: 60 },
          { borderRadius: 30 },
          { backgroundColor: '#ffffff' },
          { alignSelf: 'center' },
          { alignItems: 'center' },
          { justifyContent: 'center' },
          Styles.general.shadowLightBorder,
          Styles.general.shadow,
        ]}
        onPress={props.onPress}
      >
        {props.loading ? (
          <Spinner color={Colors.secondary} />
        ) : (
          <Image
            source={require('../../assets/images/ic_gps_indicator.png')}
            style={{ tintColor: '#6d6d6d', width: 40, height: 40 }}
          />
        )}
      </FsButton>
    </Callout>
  );
};

const mapStateToProps = (state) => {
  return {
    currentLocation: state.location,
    userData: state.auth.user,
    currentOrganization: state.organizations.currentOrganization,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    toggleFlag: (flag, userId, orgId) =>
      dispatch(toggleFlagEstablishment(flag, userId, orgId)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(FlagLocationVerificationScreen);
