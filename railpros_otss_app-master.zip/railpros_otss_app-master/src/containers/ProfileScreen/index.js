import React, { useState, useEffect, useContext } from 'react';
import _ from 'lodash';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Content, View } from 'native-base';
import Constants from 'expo-constants';
import { NavigationActions, NavigationContext } from 'react-navigation';

import { Icons, Colors } from '../../constants';
import {
  ScrollableScreen,
  FsAlert,
  FsButtonActionIcon,
  FsText,
} from '../../components/CustomComponents';
import Screen from '../../components/Screen';
import { useDispatch, useSelector } from 'react-redux';
import { logoutAction } from '../../sharedMethods/users';
import EditProfileForm from './form';
import { updateUser, sendDownloadURLToPhone } from '../../actions/user';

const ProfileScreen = (props) => {
  const dispatch = useDispatch();
  const [user, setUser] = useState({});
  const [loading, setLoading] = useState(false);
  const { userData } = useSelector((state) => ({
    userData: state.auth.user,
  }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();
  // on mount actions
  useEffect(() => {
    if (isNavigationFocus) {
      initialize();
    }
  }, [isNavigationFocus]);

  useEffect(() => {
    initialize();
  }, [userData]);

  const onPressLogout = async () => {
    return dispatch(logoutAction(props.navigation));
  };

  const initialize = async () => {
    setLoading(true);
    setUser(userData);
    setLoading(false);
  };

  const onChange = (attribute, newValue) => {
    setUser({
      ...userData,
      [attribute]: newValue,
    });
  };

  const onPressSaveAndGoBack = () =>
    validateFormAndConfirmSave()
      .then(() => dispatch(NavigationActions.back()));

  const validateFormAndConfirmSave = () => {
    if (!validateForm()) {
      return Promise.reject(null);
    }

    return confirmSave().then(doUpdateUser);
  };

  const validateForm = () => {
    if (_.isEmpty(_.trim(user.name))) {
      FsAlert.alertOk('Name Missing', 'Please fill in your name.');
      return false;
    }

    return true;
  };

  const confirmSave = () => {
    return FsAlert.alertYesCancel(
      'Confirm Save',
      'Do you want to save your changes?',
      'Yes, Save'
    );
  };

  const userDataisEqualToStateData =
    userData.name === user.name && userData.phone === user.phone;

  const doUpdateUser = async () => {
    setLoading(true);

    if (!userDataisEqualToStateData) {
      await dispatch(updateUser(user));
    }
    dispatch(NavigationActions.back());
    setLoading(false);
  };

  const sendDownloadURL = async () => {
    if (!user.phone || user.phone.trim() === '') {
      return FsAlert.alertOk(
        'Unable to send download url',
        'Please make sure you have a phone number registered for your account'
      );
    }
    try {
      await sendDownloadURLToPhone();
      return FsAlert.alertOk(
        'Download URL Sent',
        'A link to the download site has been sent to the phone number on file with OTSS. Login using your RailPros credentials and follow all installation instructions'
      );
    } catch (error) {
      return FsAlert.alertOk(
        'Unable to send download url',
        'Please make sure you have set a valid phone number for your account'
      );
    }
  };

  const buttonBgColor = {};
  if (userDataisEqualToStateData) {
    buttonBgColor.backgroundColor = Colors.secondaryDark;
  }
  return (
    <Screen title="Settings">
      <Content enableOnAndroid enableResetScrollToCoords={false} scrollEnabled={true}>
        <ScrollableScreen
          containerStyle={[{ paddingTop: 0 }]}
          refreshing={loading}
          onRefresh={initialize}
        >
          <EditProfileForm userData={user} onChange={onChange} />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.secondarySharp,
            }}
            onPress={() =>
              dispatch(
                NavigationActions.navigate({
                  routeName: 'ReportBugScreen',
                })
              )
            }
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="bug"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  REPORT A BUG
                </FsText>
              </View>
            )}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.secondary,
            }}
            onPress={() =>
              dispatch(
                NavigationActions.navigate({
                  routeName: 'SystemInformationScreen',
                })
              )
            }
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="information"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  SYSTEM INFORMATION
                </FsText>
              </View>
            )}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.secondary,
            }}
            onPress={sendDownloadURL}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="download"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  INSTALL OTSS ON YOUR PHONE
                </FsText>
              </View>
            )}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 48,
              backgroundColor: Colors.secondary,
            }}
            onPress={onPressLogout}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="logout"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  LOGOUT
                </FsText>
              </View>
            )}
          />
          {!userDataisEqualToStateData ? (
            <FsButtonActionIcon
              title=""
              style={{
                alignItems: 'center',
                alignContent: 'center',
                marginHorizontal: 10,
                borderRadius: 10,
                marginTop: 20,
                backgroundColor: Colors.green,
              }}
              onPress={() => onPressSaveAndGoBack().catch((err) => console.log(err))}
              renderIcon={(color) => (
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <MaterialCommunityIcons
                    name="check"
                    color={color}
                    size={Icons.size.normal}
                  />
                  <FsText
                    style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                  >
                    SAVE CHANGES
                  </FsText>
                </View>
              )}
            />
          ) : null}
          <FsText
            style={{
              top: 40,
              textAlign: 'center',
              color: Colors.secondaryLight,
            }}
          >
            v{Constants.expoConfig.version}
          </FsText>
        </ScrollableScreen>
      </Content>
    </Screen>
  );
};

// Exports
export default ProfileScreen;
