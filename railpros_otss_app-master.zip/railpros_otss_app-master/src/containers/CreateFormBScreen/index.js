import React, { Component } from 'react';
import { Content, View, Fab } from 'native-base';
import { Spinner } from 'native-base';
import { connect } from 'react-redux';
import moment from 'moment-timezone';
import { FontAwesome, MaterialCommunityIcons } from '@expo/vector-icons';
import _ from 'lodash';
import MultiSelect from 'react-native-multiple-select';

import { Colors, Icons, Fonts } from '../../constants';
import {
  FsButtonActionIcon,
  FsAlert,
  ScrollableScreen,
  FsText,
} from '../../components/CustomComponents';
import { ActiveDatesCalendar, Screen } from '../../components';
import CreateFormBForm from './form';
import {
  updateFormB,
  createFormB,
  deleteFormB,
  getAllTags,
  addTag,
} from '../../actions/formbs';
import { updateFlags, createFlags, validateFlags } from '../../actions/flags';
import {
  getExcludedUsersFromFormBCallNotifications,
  updateIdsFromManagementExcludedFromNotifications,
} from '../../actions/notifications';
import FlagsForm from './flagsForm';
import { getFlagType } from '../../sharedMethods/flags';
import { USER_ROLES } from '../../utils/userRoles';

class CreateFormBScreen extends Component {
  constructor(props) {
    super(props);

    this.defaultGeneralState = {
      flags: [],
      removedFlags: [],
      addedFlags: [],
      excludedManagersIdsFromCalls: [],
      availableTags: [],
    };

    this.state = {
      formb: {
        subdivision: '',
        state: '',
        city: '',
        job_number: '',
        job_site_mile_post: '',
        tags: [],
        extra_data: {},
        open_time: moment().format('HH:00'),
        close_time: moment().add(1, 'hour').format('HH:00'),
        timezone: moment.tz.guess(),
        timezone_offset: moment().format('Z'),
        activeDates: [],
      },
      currentUserId: null,
      loading: true,
      ...this.defaultGeneralState,
    };

    this.flagInputRefs = [];
  }

  async componentDidMount() {
    const formB = this.props.navigation.getParam('formB');
    const flags = this.props.navigation.getParam('flags');
    const currentUserId = this.props.navigation.getParam('currentUserId');
    if (formB) {
      const excludedFromCallNotifications =
        await getExcludedUsersFromFormBCallNotifications(formB.id);
      const idsFromManagementExcludedFromNotifications =
        excludedFromCallNotifications.map((user) => user.id);
      const availableTags = await getAllTags();

      const formb = {
        ...formB,
        extra_data: JSON.parse(formB.extra_data),
      };

      if (flags) {
        this.setState({
          formb,
          flags,
          currentUserId,
          excludedManagersIdsFromCalls:
            idsFromManagementExcludedFromNotifications,
          availableTags,
          loading: false,
        });
      } else {
        this.setState({
          formb,
          currentUserId,
          excludedManagersIdsFromCalls:
            idsFromManagementExcludedFromNotifications,
          availableTags,
          loading: false,
        });
      }
    } else {
      this.setState({ currentUserId, loading: false });
    }
  }

  render() {
    if (this.state.loading)
      return (
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <Spinner color={Colors.secondary} />
        </View>
      );

    const isNewProtection = _.isNil(this.state.formb.id);
    const loggedInUserIsManagement =
      this.props.userData.role_id !== USER_ROLES.Flagmen;

    return (
      <Screen
        title={
          !isNewProtection
            ? `Editing ${this.props.currentOrganization.settings.form_verbiage}`
            : `Creating ${this.props.currentOrganization.settings.form_verbiage}`
        }
        onBackPress={this.checkIfChanged}
      >
        <Content enableOnAndroid enableResetScrollToCoords={false} style={{ paddingHorizontal: 5 }}>
          <ScrollableScreen>
            <View>
              <FsText
                style={[
                  {
                    alignItems: 'center',
                    textAlign: 'center',
                    fontSize: Fonts.size.xbig,
                    color: Colors.primaryLight,
                  },
                ]}
              >
                General Information
              </FsText>
              <CreateFormBForm
                loggedInUserIsManagement={loggedInUserIsManagement}
                currentOrganizationId={
                  this.props.currentOrganization.settings.id
                }
                formb={this.state.formb}
                onChangeText={this.onChangeTextFormBForm}
                onScheduleChange={this.onScheduleChange}
              />
              <ActiveDatesCalendar
                activeDatesInUTC={this.state.formb.activeDates.map(
                  ({ date }) => date
                )}
                onClickDay={this.onClickDay}
              />
            </View>

            <FlagsForm
              isFormB
              flags={this.state.flags.filter(
                (flag) => getFlagType(flag).isFormB
              )}
              onFlagUpdate={(...updateFlagData) =>
                this.onFlagUpdate(...updateFlagData, { isFormB: true })
              }
              onPressMinusFlag={() => this.onPressMinusFlag({ isFormB: true })}
              onPressPlusFlag={this.onPressPlusFlag}
              isActive={isNewProtection || loggedInUserIsManagement}
            />
            <FlagsForm
              isDerail
              flags={this.state.flags.filter(
                (flag) => getFlagType(flag).isDerail
              )}
              onFlagUpdate={(...updateFlagData) =>
                this.onFlagUpdate(...updateFlagData, { isDerail: true })
              }
              onPressMinusFlag={() => this.onPressMinusFlag({ isDerail: true })}
              // FLAG-732: a red flag should automatically
              // be created whenever a derail is created
              onPressPlusFlag={() => {
                const linkId = Math.floor((1 + Math.random()) * 0x10000)
                  .toString(16)
                  .substring(1);
                this.onPressPlusFlag('derail', linkId);
                return this.onPressPlusFlag('formB', linkId);
              }}
              isActive={isNewProtection || loggedInUserIsManagement}
            />
            <FlagsForm
              isSwitchLocks
              flags={this.state.flags.filter(
                (flag) => getFlagType(flag).isSwitchLocks
              )}
              onFlagUpdate={(...updateFlagData) =>
                this.onFlagUpdate(...updateFlagData, { isSwitchLocks: true })
              }
              onPressMinusFlag={() =>
                this.onPressMinusFlag({ isSwitchLocks: true })
              }
              onPressPlusFlag={() => this.onPressPlusFlag('switch')}
              isActive={isNewProtection || loggedInUserIsManagement}
            />

            {this.state.formb.id && loggedInUserIsManagement ? (
              <View
                style={{
                  marginTop: 24,
                  marginBottom: 24,
                  paddingHorizontal: 32,
                }}
              >
                <FsText
                  style={[
                    {
                      marginTop: 24,
                      alignItems: 'center',
                      textAlign: 'center',
                      fontSize: Fonts.size.xbig,
                      color: Colors.primaryLight,
                    },
                  ]}
                >
                  Tags
                </FsText>
                <MultiSelect
                  items={this.state.availableTags}
                  uniqueKey="id"
                  onSelectedItemsChange={async (newTagsArray) => {
                    const sanitizedTagsArray = await Promise.all(
                      newTagsArray.map(async (tagId) => {
                        if (typeof tagId !== 'number') {
                          const sanitizedNewTagName = tagId.replace(/-/g, ' ');
                          const newTagId = await addTag(sanitizedNewTagName);
                          return { id: newTagId, name: sanitizedNewTagName };
                        }
                        return this.state.availableTags.find(
                          ({ id }) => id === tagId
                        );
                      })
                    );
                    const availableTags = await getAllTags();
                    this.setState({
                      formb: {
                        ...this.state.formb,
                        tags: sanitizedTagsArray,
                      },
                      availableTags,
                    });
                  }}
                  canAddItems={true}
                  selectedItems={this.state.formb.tags.map(({ id }) => id)}
                  searchInputPlaceholderText="Search..."
                  tagRemoveIconColor="darkred"
                  tagBorderColor={Colors.secondary}
                  tagTextColor={Colors.secondary}
                  selectedItemTextColor={Colors.secondary}
                  selectedItemIconColor={Colors.secondary}
                  itemTextColor={Colors.textSecondary}
                  displayKey="name"
                  searchInputStyle={{ color: Colors.textSecondary }}
                  submitButtonColor={Colors.secondary}
                  submitButtonText="Submit"
                />
              </View>
            ) : null}

            {this.state.formb.id && loggedInUserIsManagement ? (
              <View
                style={{
                  marginTop: 24,
                  marginBottom: 24,
                  paddingHorizontal: 32,
                }}
              >
                <FsText
                  style={[
                    {
                      marginTop: 24,
                      alignItems: 'center',
                      textAlign: 'center',
                      fontSize: Fonts.size.xbig,
                      color: Colors.primaryLight,
                    },
                  ]}
                >
                  Notifications
                </FsText>
                <FsText style={{ marginTop: 24, marginBottom: 12 }}>
                  Excluded Management From Calls
                </FsText>
                <MultiSelect
                  items={this.props.currentOrganization.management.filter(
                    (user) => user.role_id > 2
                  )}
                  uniqueKey="id"
                  onSelectedItemsChange={(newExcludedFromCallsArray) =>
                    this.setState({
                      excludedManagersIdsFromCalls: newExcludedFromCallsArray,
                    })
                  }
                  selectedItems={this.state.excludedManagersIdsFromCalls}
                  searchInputPlaceholderText="Search..."
                  tagRemoveIconColor="darkred"
                  tagBorderColor={Colors.secondary}
                  tagTextColor={Colors.secondary}
                  selectedItemTextColor={Colors.secondary}
                  selectedItemIconColor={Colors.secondary}
                  itemTextColor={Colors.textSecondary}
                  displayKey="name"
                  searchInputStyle={{ color: Colors.textSecondary }}
                  submitButtonColor={Colors.secondary}
                  submitButtonText="Submit"
                />
              </View>
            ) : null}

            {this.state.formb.id && (
              <FsButtonActionIcon
                title="Delete"
                style={[{ alignSelf: 'center' }, { marginTop: 16 }]}
                textStyle={[]}
                onPress={() => this.onPressDeleteFormB()}
                renderIcon={(color) => (
                  <FontAwesome
                    name="trash"
                    color={color}
                    size={Icons.size.normal}
                  />
                )}
              />
            )}
          </ScrollableScreen>
        </Content>
        <Fab
          onPress={() => this.onPressSaveAndGoBack().catch(() => { })}
          style={{ backgroundColor: Colors.secondary }}
        >
          <MaterialCommunityIcons
            name={'check'}
            size={Icons.size.big}
            color={Colors.textLight}
            style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
          />
        </Fab>
      </Screen>
    );
  }

  onFlagUpdate = (
    attribute,
    newValue,
    flagPosition,
    { isFormB, isDerail, isSwitchLocks }
  ) => {
    // filtering all flags that matches the current
    // type
    const flagsByType = this.state.flags.filter(
      (flag) =>
        (isFormB && getFlagType(flag).isFormB) ||
        (isDerail && getFlagType(flag).isDerail) ||
        (isSwitchLocks && getFlagType(flag).isSwitchLocks)
    );
    // filtering all flags which doesn't match the
    // current type
    const restFlagsByType = this.state.flags.filter(
      (flag) =>
        (!isFormB && getFlagType(flag).isFormB) ||
        (!isDerail && getFlagType(flag).isDerail) ||
        (!isSwitchLocks && getFlagType(flag).isSwitchLocks)
    );
    const updatedFlagsByType = _.clone(flagsByType);
    updatedFlagsByType[flagPosition] = {
      ...updatedFlagsByType[flagPosition],
      [attribute]: newValue,
    };
    this.setState({
      flags: [...restFlagsByType, ...updatedFlagsByType],
    });
  };

  onScheduleChange = (attribute, newValue) => {
    if (attribute === 'timezone') {
      this.setState({
        formb: {
          ...this.state.formb,
          timezone: newValue,
          timezone_offset: moment.tz(newValue).format('Z'),
        },
      });
    } else {
      this.setState({
        formb: {
          ...this.state.formb,
          [attribute]: newValue,
        },
      });
    }
  };

  onChangeTextFormBForm = (attribute, newValue, isExtraData) => {
    if (isExtraData) {
      this.setState({
        formb: {
          ...this.state.formb,
          extra_data: {
            ...this.state.formb.extra_data,
            [attribute]: newValue,
          },
        },
      });
    } else {
      this.setState({
        formb: {
          ...this.state.formb,
          [attribute]: newValue,
        },
      });
    }
  };

  onClickDay = (value) => {
    if (!this.state.formb.activeDates || !this.state.formb.activeDates.length) {
      return this.setState({
        formb: {
          ...this.state.formb,
          activeDates: [{ date: value }],
        },
      });
    }
    const dateAddedToSchedule = this.state.formb.activeDates.find(
      ({ date }) => date === value
    );
    if (dateAddedToSchedule) {
      this.setState({
        formb: {
          ...this.state.formb,
          activeDates: this.state.formb.activeDates.filter(
            ({ date }) => date !== value
          ),
        },
      });
    } else {
      this.setState({
        formb: {
          ...this.state.formb,
          activeDates: [...this.state.formb.activeDates, { date: value }],
        },
      });
    }
  };

  onPressMinusFlag = ({ isDerail, isFormB, isSwitchLocks }) => {
    if (this.state.flags.length) {
      const openFlag = this.state.flags.find((flag) => flag.is_established);
      const lastInsertedFlag = this.state.flags[this.state.flags.length - 1];

      // we will only display this prompt if the last
      // inserted flag wasn't a recently pushed one within
      // this iteration
      if (openFlag && lastInsertedFlag.id) {
        return FsAlert.alertOk(
          `Unable to remove flag`,
          `Please close all of your flags before attempting to remove one from this protection.`
        );
      }

      // filtering all flags that matches the current
      // type
      const flagsByType = this.state.flags.filter(
        (flag) =>
          (isFormB && getFlagType(flag).isFormB) ||
          (isDerail && getFlagType(flag).isDerail) ||
          (isSwitchLocks && getFlagType(flag).isSwitchLocks)
      );

      if (flagsByType.length) {
        // filtering all flags which doesn't match the
        // current type
        const restFlagsByType = this.state.flags.filter(
          (flag) =>
            (!isFormB && getFlagType(flag).isFormB) ||
            (!isDerail && getFlagType(flag).isDerail) ||
            (!isSwitchLocks && getFlagType(flag).isSwitchLocks)
        );

        this.setState((prevState) => {
          const removedFlag = flagsByType.pop();

          // creating a new flags state based on the new
          // flags by type + the rest of the flags
          // which don't belong to that type
          const newFlagsState = [...restFlagsByType, ...flagsByType];
          // if a flag doesn't contains an id then, it means
          // that it was added and then removed at the same time
          // and therefore we won't need to remove it from our db
          // as it never existed
          if (!_.isNil(removedFlag.id)) {
            return {
              flags: newFlagsState,
              removedFlags: prevState.removedFlags.concat(removedFlag),
            };
          }

          return {
            flags: newFlagsState,
          };
        });
      }
    }
  };

  // FLAG-732: a red flag should automatically
  // be created whenever a derail is created
  // and linked together
  onPressPlusFlag = (flagType, linkId) => {
    this.setState((prevState) => {
      const currentFlags = prevState.flags;
      let newFlag = {
        protection_id: this.state.formb.id,
        track: 'Other',
      };

      if (flagType === 'derail') {
        newFlag = {
          ...newFlag,
          type: 'lh',
          serial_number: '',
          linkId,
        };
      } else if (flagType === 'switch') {
        newFlag = {
          ...newFlag,
          type: 'switch',
          mile_post: '',
        };
      } else {
        newFlag = {
          ...newFlag,
          type: 'red',
          mile_post: '',
          linkId,
          // QR-CODE
          // item_qr: '',
        };
      }

      return {
        flags: currentFlags.concat(newFlag),
        addedFlags: prevState.addedFlags.concat(newFlag),
      };
    });
  };

  checkIfChanged = () => {
    const formB = this.props.navigation.getParam('formB');
    const flags = this.props.navigation.getParam('flags');

    // locally, we do handle extra_data as an object but
    // in reality, it is a string coming from the DB so we
    // need to parse it within this comparison to get the proper
    // result from it
    const currentParsedFormB = formB && {
      ...formB,
      extra_data: JSON.parse(formB.extra_data),
    };

    if (
      _.isNil(formB) ||
      (_.isEqual(this.state.formb, currentParsedFormB) &&
        _.isEqual(this.state.flags, flags))
    ) {
      this.props.navigation.goBack();
    } else {
      this.confirmBack()
        .then(() => this.onPressSaveAndGoBack())
        .catch(() => this.props.navigation.goBack());
    }
  };

  confirmBack() {
    return FsAlert.alertYesCancel(
      'Pending Changes',
      'Do you want to save your changes?',
      'Yes',
      'No'
    );
  }

  /**
   * @return promise
   */
  onPressSaveAndGoBack() {
    return this.validateFormAndConfirmSave()
      .then(() => this.props.navigation.goBack())
      .catch(() => { });
  }

  /**
   * @return true if validated
   */
  validateForm = () => {
    if (
      _.isEmpty(_.trim(this.state.formb.subdivision)) &&
      this.props.currentOrganization.settings.id !== 10 // FLAG-342
    ) {
      FsAlert.alertOk(
        `${this.props.currentOrganization.settings.form_verbiage} Subdivision Missing`,
        `Please fill in the ${this.props.currentOrganization.settings.form_verbiage}'s Subdivision.`
      );
      return false;
    }

    if (_.isEmpty(_.trim(this.state.formb.state))) {
      FsAlert.alertOk(
        `${this.props.currentOrganization.settings.form_verbiage} State Missing`,
        `Please fill in the ${this.props.currentOrganization.settings.form_verbiage}'s State.`
      );
      return false;
    }

    if (_.isEmpty(_.trim(this.state.formb.city))) {
      FsAlert.alertOk(
        `${this.props.currentOrganization.settings.form_verbiage} City Missing`,
        `Please fill in the ${this.props.currentOrganization.settings.form_verbiage}'s City.`
      );
      return false;
    }

    if (_.isEmpty(_.trim(this.state.formb.close_time))) {
      FsAlert.alertOk(
        `${this.props.currentOrganization.settings.form_verbiage} Closing Time Missing`,
        `Please fill in the ${this.props.currentOrganization.settings.form_verbiage}'s Close Time.`
      );
      return false;
    }

    if (_.isEmpty(_.trim(this.state.formb.open_time))) {
      FsAlert.alertOk(
        `${this.props.currentOrganization.settings.form_verbiage} Open Time Missing`,
        `Please fill in the ${this.props.currentOrganization.settings.form_verbiage}'s Open Time.`
      );
      return false;
    }

    if (_.isEmpty(this.state.flags)) {
      FsAlert.alertOk(
        'Flag Data Missing',
        `There has to be at least one flag per ${this.props.currentOrganization.settings.form_verbiage}.`
      );
      return false;
    }
    if (
      _.some(this.state.flags, (flag) => {
        const flagType = getFlagType(flag);
        return (
          // QR-CODE
          // (!flagType.isDerail && !flagType.isSwitchLocks && !flag.item_qr) ||
          (flagType.isDerail && !flag.serial_number) ||
          (flagType.isFormB && !flag.mile_post) ||
          (flagType.isSwitchLocks &&
            (!flag.mile_post || !flag.serial_number))
        );
      })
    ) {
      FsAlert.alertOk(
        'Flag Data Missing',
        'Please complete the form for all flags.'
      );
      return false;
    }

    return true;
  };

  validateFormAndConfirmSave = async () => {
    if (!this.validateForm()) {
      return Promise.reject(null);
    }
    this.setState({ loading: true });
    /** QR-CODE */
    // const validation = await this.props.validateFlags(this.state.flags);
    // if (!validation?.isValid) {
    //   this.setState({ loading: false });
    //   FsAlert.alertOk(
    //     'Flag Data Error',
    //     validation.message
    //   );
    //   return Promise.reject(null);
    // }

    if (_.isNil(this.state.formb.id)) {
      return this.doCreateFormB();
    } else {
      return this.doUpdateFormB();
    }
  }

  doCreateFormB = async () => {
    const formB = {
      ...this.state.formb,
      tags: (this.state.formb.tags || []).map(({ id }) => id),
      activeDates: (this.state.formb.activeDates || []).map(({ date }) => date),
    };
    if (this.props.currentOrganization.settings.id === 10) {
      // FLAG-342
      formB.subdivision = 'FEC';
    }

    const newFormBId = await this.props.createFormB(
      formB,
      this.props.currentOrganization.settings.id,
      this.state.currentUserId
    );
    await this.props.createFlags(
      newFormBId,
      this.state.flags,
      this.state.currentUserId
    );
    this.setState({ loading: false });
  };

  doUpdateFormB = async () => {
    const originalFormB = this.props.navigation.getParam('formB');
    const originalFlags = this.props.navigation.getParam('flags');

    if (originalFormB) {
      // we aren't checking this array's value so for us to know
      // if it changed or not as that is being handled by the backend
      await updateIdsFromManagementExcludedFromNotifications({
        idsFromManagementExcludedFromNotifications:
          this.state.excludedManagersIdsFromCalls,
        protectionId: originalFormB.id,
      });
    }

    // updated flags includes new flags
    // and the way we differentiate one
    // from another, is by checking if they
    // have an id or not tied to them
    const flagsByType = {
      updated: this.state.flags,
      removed: this.state.removedFlags,
    };

    const currentFormB = {
      ...this.state.formb,
      tags: (this.state.formb.tags || []).map(({ id }) => id),
      activeDates: (this.state.formb.activeDates || []).map(({ date }) => date),
    };

    if (this.props.currentOrganization.settings.id === 10) {
      // FLAG-342
      currentFormB.subdivision = 'FEC';
    }

    if (
      !_.isEqual(originalFormB, currentFormB) &&
      !_.isEqual(originalFlags, this.state.flags)
    ) {
      await this.props.updateFormB(
        currentFormB,
        this.props.currentOrganization.settings.id
      );
      await this.props.updateFlags(
        this.state.currentUserId,
        flagsByType,
        currentFormB.id
      );
      this.setState({ loading: false });
    } else {
      if (!_.isEqual(originalFormB, currentFormB)) {
        await this.props.updateFormB(
          currentFormB,
          this.props.currentOrganization.settings.id
        );
      }
      if (!_.isEqual(originalFlags, this.state.flags)) {
        await this.props.updateFlags(
          this.state.currentUserId,
          flagsByType,
          currentFormB.id
        );
      }
      this.setState({ loading: false });
    }
  };

  onPressDeleteFormB = () => {
    const { formb } = this.state;
    return FsAlert.alertYesCancel(
      `Delete ${this.props.currentOrganization.settings.form_verbiage}`,
      'Are you sure you want to delete {}?'.format(
        `this ${this.props.currentOrganization.settings.form_verbiage}`
      ),
      'Yes, Delete'
    )
      .then(() => this.doDeleteFormB(formb.id))
      .catch(() => { });
  };

  doDeleteFormB = async (formBId) => {
    this.setState({ loading: true });
    await this.props.deleteFormB(
      formBId,
      this.props.currentOrganization.settings.id
    );
    this.setState({ loading: false });
    this.props.navigation.goBack();
  };
}

const mapStateToProps = (state) => {
  return {
    userData: state.auth.user,
    currentOrganization: state.organizations.currentOrganization,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    createFormB: (formB, organization_id, currentUserId) =>
      dispatch(createFormB({ ...formB, organization_id }, currentUserId)),
    deleteFormB: (id, orgId) => dispatch(deleteFormB(id, orgId)),
    createFlags: (formBId, flags, currentUserId) =>
      dispatch(createFlags({ formBId, flags, currentUserId })),
    updateFormB: (formB) => dispatch(updateFormB(formB)),
    updateFlags: (currentUserId, flagsByType, formBId) =>
      dispatch(updateFlags({ currentUserId, flagsByType, formBId })),
    validateFlags: (flags) =>
      dispatch(validateFlags({ flags })),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateFormBScreen);
