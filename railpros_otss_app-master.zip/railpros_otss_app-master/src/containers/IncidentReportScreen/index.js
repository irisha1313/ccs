import React, { Component } from 'react';
import { View, TextInput, FlatList, Alert } from 'react-native';
import { Container, Spinner, Fab } from 'native-base';
import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import _ from 'lodash';
import moment from 'moment-timezone';
import { connect } from 'react-redux';
import { Colors, Fonts, Icons, Styles } from '../../constants';
import {
  FsText,
  FsButton,
  FsAlert,
  ScrollableScreen,
} from '../../components/CustomComponents';
import FormBEntry from '../../components/FormBEntry';
import { getIncidents, createIncidentReport } from '../../actions/incidents';
import { onPressCall } from '../../sharedMethods/users';
import { Screen } from '../../components';

const MaxDescriptionLength = 5000;

class IncidentReportScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      description: '',
      incidents: [],
      formb: null,
    };
  }

  componentDidMount() {
    this.fetchIncidents();
  }

  render() {
    if (this.state.loading) {
      return (
        <Container
          style={{
            alignItems: 'center',
            flex: 1,
            justifyContent: 'center',
          }}
        >
          <Spinner color={Colors.secondary} />
        </Container>
      );
    }

    const descriptionIsEmpty = this.state.description === '';

    return (
      <Screen onBackPress={this.checkIfChanged} title="Notes">
        <ScrollableScreen
          containerStyle={[{ paddingTop: 0 }, { paddingBottom: 240 }]}
          refreshing={this.state.loading}
          onRefresh={this.fetchIncidents}
        >
          <View
            style={[
              { marginHorizontal: 8, marginVertical: 10 },
              { borderTopLeftRadius: Styles.constant.BorderRadius },
              { borderTopRightRadius: Styles.constant.BorderRadius },
              { borderBottomLeftRadius: Styles.constant.BorderRadius },
              { borderBottomRightRadius: Styles.constant.BorderRadius },
            ]}
          >
            <TextInput
              ref={(ref) => {
                this.refInputDescription = ref;
              }}
              placeholderTextColor={Colors.textSecondary}
              placeholder="Tap here to begin typing a note."
              autoCorrect={true}
              autoCapitalize="sentences"
              multiline={true}
              maxLength={MaxDescriptionLength}
              style={[
                Styles.general.fsInputStyle,
                Styles.general.fsInputStyleMultiline,
                { fontSize: Fonts.size.small },
                { borderTopWidth: 1 },
                { borderBottomWidth: 1 },
                { borderLeftWidth: 1 },
                { borderRightWidth: 1 },
                { borderColor: Colors.divider },
                { borderBottomLeftRadius: Styles.constant.BorderRadius },
                { borderBottomRightRadius: Styles.constant.BorderRadius },
                { height: 200 },
                { paddingTop: 25 },
                { backgroundColor: Colors.CardBackground },
              ]}
              value={this.state.description}
              onChangeText={(text) => this.setState({ description: text })}
            />

            <FsText
              style={[
                { color: Colors.textSecondary },
                { fontSize: Fonts.size.small },
                { textAlign: 'right' },
                { marginTop: 4 },
              ]}
            >
              {MaxDescriptionLength -
                _.defaultTo(this.state.description, '').length}{' '}
              characters left
            </FsText>
          </View>

          {this.renderIncidents()}
        </ScrollableScreen>
        <Fab
          onPress={
            descriptionIsEmpty
              ? () => undefined
              : () => this.onPressSaveAndGoBack().catch(() => {})
          }
          style={{
            backgroundColor: descriptionIsEmpty
              ? Colors.secondaryDark
              : Colors.secondary,
          }}
        >
          <MaterialCommunityIcons
            name={'check'}
            size={Icons.size.big}
            style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
          />
        </Fab>
      </Screen>
    );
  }

  renderIncidents = () => {
    if (_.isEmpty(this.state.incidents)) {
      return null;
    }

    return (
      <View style={[{ marginTop: 64 }, { marginHorizontal: 12 }]}>
        <FsText style={[{ color: Colors.textSecondary }]}>
          Previous Notes
        </FsText>
        <FlatList
          data={this.state.incidents}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => item.id.toString()}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => (
            <IncidentView
              userData={this.props.userData}
              incident={rowData.item}
              containerStyle={[{ paddingVertical: 24 }]}
              onPressCall={onPressCall}
            />
          )}
          ItemSeparatorComponent={() => (
            <View
              style={{ borderBottomWidth: 1, borderColor: Colors.divider }}
            ></View>
          )}
          ListHeaderComponent={() => (
            <View
              style={{ borderBottomWidth: 1, borderColor: Colors.divider }}
            ></View>
          )}
          contentContainerStyle={[{ marginTop: 8 }]}
        />
      </View>
    );
  };

  checkIfChanged = () => {
    if (this.state.description === '') {
      this.props.navigation.goBack();
    } else {
      this.confirmBack(
        () => this.onPressSaveAndGoBack(),
        () => this.props.navigation.goBack()
      );
    }
  };

  confirmBack(onYes, onNo) {
    Alert.alert(
      'Save Note?',
      '',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'No, Discard',
          onPress: onNo,
          style: 'destructive',
        },
        {
          text: 'Yes, SAVE',
          onPress: onYes,
          style: 'default',
        },
      ],
      { cancelable: false }
    );
  }

  /**
   * @return promise
   */
  onPressSaveAndGoBack() {
    return this.confirmSave()
      .then(this.doCreateIncidentReport)
      .then(() => this.props.navigation.goBack())
      .catch(() => {});
  }

  confirmSave = () => {
    return FsAlert.alertYesCancel(
      'Confirm Save',
      'Please make sure this note is complete.' +
        '\n\nOnce you save this note, you will not be able to change it.' +
        '\n\nAre you sure you want to save?',
      'Yes, Save'
    );
  };

  /**
   * Note: assumes we're automatically navigating back to the prev screen
   *
   * @return promise, rejected on failure
   */
  doCreateIncidentReport = async () => {
    this.setState({ loading: true });
    const newIncident = { description: this.state.description };
    await createIncidentReport(this.state.formb.id, newIncident);
  };

  fetchIncidents = async () => {
    const formB = this.props.navigation.getParam('formB');
    if (formB) {
      const incidents = await getIncidents(formB.id);
      this.setState({
        formb: formB,
        incidents,
        loading: false,
      });
    } else {
      this.setState({ loading: false });
    }
  };
}

/**
 *
 * @prop onPressCall
 */
const IncidentView = (props) => {
  const { incident, userData } = props;
  const incidentCreatedByLoggedInUser = incident.created_by === userData.id;
  return (
    <View style={[props.containerStyle]}>
      <View style={[{ flexDirection: 'row', alignItems: 'center' }]}>
        <View style={[{ flex: 1 }]}>
          <FsText>
            <FsText style={Styles.general.inlineSubText}>CREATED ON</FsText>
            {'  '}
            {moment(incident.created_at).format('ddd MMM D')}
          </FsText>

          <FsText>
            <FsText style={Styles.general.inlineSubText}>CREATED BY</FsText>
            {'  '}
            {incidentCreatedByLoggedInUser
              ? 'Me'
              : incident.createdBy.name}
          </FsText>
        </View>
        {!incidentCreatedByLoggedInUser && (
          <FsButton
            onPress={() => {
              try {
                props.onPressCall(
                  incident.createdBy.name,
                  incident.createdBy.phone
                );
              } catch (err) {}
            }}
          >
            <FontAwesome5
              name={'phone'}
              size={Icons.size.small}
              color={Colors.accent}
            />
          </FsButton>
        )}
      </View>

      <FsText style={[{ marginTop: 12 }, { fontSize: Fonts.size.small }]}>
        {_.trim(incident.description)}
      </FsText>
    </View>
  );
};

const mapStateToProps = (state) => {
  return {
    userData: state.auth.user,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(IncidentReportScreen);
