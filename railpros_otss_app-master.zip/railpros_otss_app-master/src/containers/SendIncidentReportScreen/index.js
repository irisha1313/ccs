import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import _ from 'lodash';
import { Spinner } from 'native-base';
import moment from 'moment-timezone';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Appearance } from 'react-native';

import { Colors, Icons } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsButtonActionIcon,
  FsInputWithLabel,
  FsAlert,
} from '../../components/CustomComponents';
import Screen from '../../components/Screen';
import { sendIncidentReport } from '../../actions/reports';

const SendIncidentReportScreen = (props) => {
  const [loading, setLoading] = useState(false);
  const [currentUserData, setCurrentUserData] = useState({});
  const [date, setDate] = useState(moment().format());
  const [datePickerCurrentVisibility, setDatePickerVisibility] =
    useState(false);

  // on mount actions
  useEffect(() => {
    initialize();
  }, []);

  const initialize = async () => {
    const currentUser = props.navigation.getParam('currentUser');
    setCurrentUserData(currentUser);
  };

  const confirmValidateForm = async () => {
    setLoading(true);
    try {
      await FsAlert.alertYesCancel(
        'Generate Audit Report',
        `This Report will only be emailed to you.`,
        'Send Report',
        'No'
      );
      await onPressIncidentReport();
      setLoading(false);
      // we aren't catching a thing within this method
      // as it is used to handle the "No" selection
      // within FsAlert.alertYesCancel
    } catch (error) {
      setLoading(false);
    }
  };

  const onPressIncidentReport = async () => {
    await sendIncidentReport(currentUserData.id, date);
    return props.navigation.goBack();
  };

  const toggleDatePicker = () =>
    setDatePickerVisibility(!datePickerCurrentVisibility);

  const theme = Appearance.getColorScheme();

  if (loading)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  return (
    <Screen title="Audit Report">
      <ScrollableScreen containerStyle={[{ paddingBottom: 240 }]}>
        <View style={[{ paddingHorizontal: 16 }]}>
          <FsInputWithLabel
            label={'SELECTED DATE'}
            value={moment(date).format('MM/DD/YYYY')}
            editable={false}
            containerStyle={[{ marginTop: 24 }]}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.secondary,
            }}
            onPress={toggleDatePicker}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="calendar"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  SELECT A DIFFERENT DATE
                </FsText>
              </View>
            )}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.green,
            }}
            onPress={confirmValidateForm}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="send"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  SEND
                </FsText>
              </View>
            )}
          />
          <DateTimePickerModal
            isDarkModeEnabled={theme === 'dark'}
            isVisible={datePickerCurrentVisibility}
            mode="date"
            onConfirm={(date) => {
              setDate(date);
              toggleDatePicker();
            }}
            onCancel={toggleDatePicker}
          />
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

// Exports
export default SendIncidentReportScreen;
