import React, { useState, useEffect, useContext } from 'react';
import { FlatList } from 'react-native';
import _ from 'lodash';
import { NavigationActions, NavigationContext } from 'react-navigation';
import { useDispatch, useSelector } from 'react-redux';
import { Dropdown } from 'react-native-material-dropdown-v2';
import { View } from 'react-native';
import moment from 'moment';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { Appearance } from 'react-native';

import { Colors, Fonts, Styles } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
  FsButton,
  FsInputWithLabel,
} from '../../components/CustomComponents';
import { getFormbsRaw, unarchiveFormB } from '../../actions/formbs';
import FormBEntry from '../../components/FormBEntry';
import Screen from '../../components/Screen';

const ArchivedFormBsScreen = (props) => {
  const [currentUserData, setCurrentUserData] = useState({});
  const [deletedFormBs, setDeletedFormBs] = useState(null);
  const [filterBy, setFilterBy] = useState('Last 5');
  const [fromDate, setFromDate] = useState(
    moment
      .utc()
      .subtract(1, 'day')
      .hours(0)
      .minute(0)
      .seconds(0)
      .format('YYYY-MM-DDTHH:mm:ss.000[Z]')
  );
  const [toDate, setToDate] = useState(
    moment.utc().endOf('day').format('YYYY-MM-DDTHH:mm:ss.000[Z]')
  );
  const [searchedJobNumber, setSearchedJobNumber] = useState('');

  const dispatch = useDispatch();

  const { userData, currentOrganization } = useSelector((state) => ({
    userData: state.auth.user,
    currentOrganization: state.organizations.currentOrganization,
  }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();
  // on mount actions
  useEffect(() => {
    if (isNavigationFocus) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  // on mount actions
  useEffect(() => {
    onRefresh();
  }, []);

  const onRefresh = () => {
    setDeletedFormBs([]);
    const receivedUserData = props.navigation.getParam('currentUserData');
    setCurrentUserData(receivedUserData);
    getFormBsForUserId(receivedUserData.id);
  };

  const getFormBsForUserId = async (user) => {
    const deletedFormBs = await getFormbsRaw({
      user,
      isDeleted: true,
      ...(filterBy === 'Last 5' && { limit: 5 }),
      ...(filterBy === 'Date Range' && {
        deletedFromDate: fromDate,
        deletedToDate: toDate,
      }),
      ...(filterBy === 'Job Number' &&
        searchedJobNumber && { jobNumber: searchedJobNumber }),
    });
    if (!deletedFormBs || deletedFormBs.length === 0) {
      setDeletedFormBs(null);
    } else {
      setDeletedFormBs(deletedFormBs);
    }
  };

  const handleUnarchive = async (formB) => {
    try {
      const selectedOption = await FsAlert.alertYesCancel(
        `Unarchive ${formB.subdivision} Sub`,
        'Are you sure you want to unarchive this protection?'
      );
      await unarchiveFormB(formB.id, {
        resetFlagsLocation: selectedOption === 'Yes',
      });
      dispatch(NavigationActions.back());
    } catch (error) {}
  };

  const DatePickers = ({ setStartDate, setEndDate }) => {
    const [dateTypeBeingEdited, setDateTypeBeingEdited] = useState(null);
    const theme = Appearance.getColorScheme();

    return (
      <View style={{ flex: 1, flexDirection: 'row', justifyContent: 'center' }}>
        <FsButton
          onPress={() => setDateTypeBeingEdited('startDate')}
          style={{
            heigth: '100',
            marginRight: 7,
            marginLeft: 7,
          }}
        >
          <FsText
            style={{
              color: Colors.black,
              fontSize: Fonts.size.normal,
              padding: 0,
              textAlign: 'center',
              minWidth: 45,
              textDecorationLine: 'underline',
              textDecorationStyle: 'solid',
            }}
          >
            From: {moment(fromDate).format('MM/DD/YY')}
          </FsText>
        </FsButton>
        <FsButton
          onPress={() => setDateTypeBeingEdited('endDate')}
          style={{
            heigth: '100',
            marginRight: 7,
            marginLeft: 7,
          }}
        >
          <FsText
            style={{
              color: Colors.black,
              fontSize: Fonts.size.normal,
              padding: 0,
              textAlign: 'center',
              minWidth: 45,
              textDecorationLine: 'underline',
              textDecorationStyle: 'solid',
            }}
          >
            To: {moment(toDate).utc().format('MM/DD/YY')}
          </FsText>
        </FsButton>
        <DateTimePickerModal
          isDarkModeEnabled={theme === 'dark'}
          isVisible={!_.isNil(dateTypeBeingEdited)}
          mode="date"
          onConfirm={(rawDate) => {
            const date = moment.utc(rawDate);
            if (dateTypeBeingEdited === 'startDate' && setStartDate) {
              setStartDate(
                date
                  .hours(0)
                  .minute(0)
                  .seconds(0)
                  .format('YYYY-MM-DDTHH:mm:ss.000[Z]')
              );
            } else if (setEndDate) {
              setEndDate(
                date.endOf('day').format('YYYY-MM-DDTHH:mm:ss.000[Z]')
              );
            }
            setDateTypeBeingEdited(null);
          }}
          onCancel={() => setDateTypeBeingEdited(null)}
        />
      </View>
    );
  };

  const loggedUserIsCurrentUser = currentUserData.id === userData.id;

  return (
    <Screen
      title={
        loggedUserIsCurrentUser
          ? `My Archived ${currentOrganization.settings.form_verbiage}s`
          : `Archived ${currentOrganization.settings.form_verbiage}s`
      }
    >
      <ScrollableScreen
        containerStyle={[{ paddingTop: 10 }]}
        refreshing={deletedFormBs && deletedFormBs.length === 0 ? true : false}
        onRefresh={onRefresh}
      >
        <View
          style={{ flex: 1, flexDirection: 'column', justifyContent: 'center' }}
        >
          <View
            style={{ flex: 1, flexDirection: 'row', justifyContent: 'center' }}
          >
            <FsText
              style={{
                paddingTop: 10,
                color: Colors.secondaryDark,
                fontSize: Fonts.size.small,
                textAlign: 'center',
              }}
            >
              Filter by
            </FsText>
            <Dropdown
              labelFontSize={0}
              dropdownOffset={{ top: 5, left: 5 }}
              fontSize={Fonts.size.normal}
              style={{
                fontFamily: Styles.constant.FontFamily,
                color: Colors.text,
                marginTop: 0,
                backgroundColor: 'transparent',
              }}
              containerStyle={{
                paddingHorizontal: 5,
                width: '50%',
                alignSelf: 'center',
              }}
              value={filterBy}
              data={[
                {
                  value: 'Last 5',
                },
                {
                  value: 'Date Range',
                },
                {
                  value: 'Job Number',
                },
              ]}
              onChangeText={(selectedType) => setFilterBy(selectedType)}
            />
          </View>
          {filterBy === 'Date Range' && (
            <DatePickers setStartDate={setFromDate} setEndDate={setToDate} />
          )}
          {filterBy === 'Job Number' && (
            <FsInputWithLabel
              label="JOB NUMBER"
              autoCorrect={false}
              autoCapitalize="none"
              returnKeyType="next"
              containerStyle={{
                width: 200,
                alignSelf: 'center',
                marginBottom: 10,
              }}
              onChangeText={(text) => {
                setSearchedJobNumber(text);
              }}
              value={searchedJobNumber}
              placeholder={searchedJobNumber}
            />
          )}
        </View>
        <FsButton
          onPress={onRefresh}
          style={{
            alignSelf: 'center',
            borderRadius: 10,
            backgroundColor: Colors.secondary,
          }}
        >
          <FsText
            style={{
              color: Colors.white,
              fontSize: Fonts.size.small,
              paddingHorizontal: 15,
              textAlign: 'center',
            }}
          >
            Filter
          </FsText>
        </FsButton>
        {deletedFormBs && deletedFormBs.length > 0 ? (
          <FlatList
            data={deletedFormBs}
            listKey={moment().valueOf().toString()}
            keyExtractor={(item) => item.id.toString()}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            renderItem={(rowData) => (
              <FormBEntry
                formB={rowData.item}
                flags={rowData.item.items}
                isArchived={true}
                handleUnarchive={handleUnarchive}
              />
            )}
            contentContainerStyle={[
              {
                marginTop: loggedUserIsCurrentUser ? 12 : 0,
              },
            ]}
          />
        ) : (
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              textAlign: 'center',
            }}
          >
            {!deletedFormBs &&
              `There are currently no Archived ${currentOrganization.settings.form_verbiage}s`}
          </FsText>
        )}
      </ScrollableScreen>
    </Screen>
  );
};

// Exports
export default ArchivedFormBsScreen;
