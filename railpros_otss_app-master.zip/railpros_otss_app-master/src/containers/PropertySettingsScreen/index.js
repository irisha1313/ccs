import React, { useState, useEffect, useContext } from 'react';
import _ from 'lodash';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { NavigationActions, NavigationContext } from 'react-navigation';
import { View, Fab, Spinner } from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import isEqual from 'lodash/isEqual';
import { Linking } from 'react-native';

import { Colors, Icons, Fonts } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
  FsInputWithLabel,
  FsButtonActionIcon,
} from '../../components/CustomComponents';
import Screen from '../../components/Screen';
import OptionEntry from '../../components/OptionEntry';
import SwitchOptionEntry from '../../components/SwitchOptionEntry';
import { updateOrganization } from '../../actions/organizations';
import { timeSelectionSanitizer } from '../../sharedMethods/formBs';

const PropertySettingsScreen = (props) => {
  const [editedOrganizationSettings, setEditedOrganizationSettings] = useState(
    {}
  );
  const [saving, setSaving] = useState(false);

  const dispatch = useDispatch();
  const { currentOrganization } = useSelector((state) => ({
    currentOrganization: state.organizations.currentOrganization,
  }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();

  // on mount action
  useEffect(() => {
    setEditedOrganizationSettings(currentOrganization.settings);
  }, []);

  const onSave = async () => {
    try {
      await FsAlert.alertYesCancel(
        `Save Changes`,
        `Are you sure you want to save this property's settings?`
      );
      setSaving(true);
      await updateOrganization(currentOrganization.settings.id, editedOrganizationSettings);
      dispatch(NavigationActions.back());
    } catch (error) {}
  };

  if (saving) {
    return (
      <Screen
        style={{ backgroundColor: Colors.lightGreyBackground }}
        title={
          editedOrganizationSettings
            ? `${editedOrganizationSettings.name} settings`
            : 'Settings'
        }
      >
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <Spinner color={Colors.secondary} />
        </View>
      </Screen>
    );
  }

  const composeFlagmenEmail = async () => {
    const usersWithinOrganization = [
      ...currentOrganization.flagmen,
      ...currentOrganization.management,
    ];

    if (!usersWithinOrganization || usersWithinOrganization.length === 0) {
      FsAlert.alertOk(
        'Unable to compose email',
        'Please make sure that there is at least one RWIC within this organization before composing an email.'
      );
    }

    const flagmenEmails = usersWithinOrganization.map(
      ({ email }) => email
    );

    try {
      await FsAlert.alertYesCancel(
        'Compose email',
        `This email will be sent to all property RWICs, managers, and directors. Do you wish to continue?`
      );
      Linking.openURL(`mailto:${flagmenEmails}`);
    } catch (error) {}
  };

  return (
    <Screen
      style={{ backgroundColor: Colors.lightGreyBackground }}
      title={
        editedOrganizationSettings
          ? `${editedOrganizationSettings.name} Settings`
          : 'Settings'
      }
    >
      <ScrollableScreen
        containerStyle={{
          paddingTop: 0,
          backgroundColor: Colors.lightGreyBackground,
        }}
      >
        <FsButtonActionIcon
          title=""
          style={{
            alignItems: 'center',
            alignContent: 'center',
            marginHorizontal: 10,
            borderRadius: 10,
            marginTop: 20,
            backgroundColor: Colors.secondarySharp,
          }}
          onPress={composeFlagmenEmail}
          renderIcon={(color) => (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <MaterialCommunityIcons
                name="email"
                color={color}
                size={Icons.size.normal}
              />
              <FsText style={{ color: Colors.textLight, paddingHorizontal: 8 }}>
                COMPOSE EMAIL
              </FsText>
            </View>
          )}
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 15,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.xxxbig,
            color: Colors.black,
          }}
        >
          General
        </FsText>
        <SwitchOptionEntry
          title="End of Day Debrief"
          hint="At the close of the last flag/derail/switch lock, a popup will confirm with the RWIC that all methods of protection been removed from the property or released back to dispatch, and are all men and equipment clear of the track for the night."
          offValue={0}
          currentValue={editedOrganizationSettings.debrief_with_dispatch}
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              debrief_with_dispatch: newValue === true ? 1 : 0,
            })
          }
        />
        <SwitchOptionEntry
          title="Enable Form C"
          hint="Gives a fourth protection option (UP properties only)."
          offValue={0}
          currentValue={editedOrganizationSettings.is_form_c_enabled}
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              is_form_c_enabled: newValue === true ? 1 : 0,
            })
          }
        />
        <SwitchOptionEntry
          title='"Form B" Verbiage Replacement'
          hint='Will replace "Form B" throughout the app with whatever verbiage you choose.'
          offValue="Form B"
          currentValue={editedOrganizationSettings.form_verbiage}
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              form_verbiage: newValue === false ? 'Form B' : '',
            })
          }
          style={
            editedOrganizationSettings.form_verbiage === 'Form B'
              ? {
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 10,
                  borderBottomWidth: 1,
                  borderColor: Colors.borderLightGrey,
                  backgroundColor: 'white',
                  justifyContent: 'space-between',
                }
              : {
                  flex: 1,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 10,
                  backgroundColor: 'white',
                  justifyContent: 'space-between',
                }
          }
        />
        {editedOrganizationSettings.form_verbiage !== 'Form B' ? (
          <FsInputWithLabel
            name="form_verbiage"
            keyboardType={Platform.select({
              ios: 'numbers-and-punctuation',
              android: 'default',
            })}
            selectTextOnFocus={true}
            returnKeyType="next"
            autoCapitalize="words"
            containerStyle={{
              flex: 1,
              borderBottomWidth: 1,
              borderColor: Colors.borderLightGrey,
              backgroundColor: 'white',
            }}
            onChangeText={(text) => {
              setEditedOrganizationSettings({
                ...editedOrganizationSettings,
                form_verbiage: text,
              });
            }}
            value={editedOrganizationSettings.form_verbiage}
            placeholder="eg. Protection, 1102"
          />
        ) : null}
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          NON-REPORT FOR DUTY CALLS
        </FsText>
        <SwitchOptionEntry
          title="Form B"
          hint="Locked. Cannot be turned off."
          offValue={0}
          currentValue={true}
          disabled={true}
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 15,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.xxxbig,
            color: Colors.black,
          }}
        >
          Management
        </FsText>
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          CALL NOTIFICATIONS
        </FsText>
        <OptionEntry
          title="Protection Expired (Open Yellow-Red Flags)"
          hint="If any yellow-red flags are still open, how many minutes after a protection has expired should a call go out to management."
          currentValue={
            editedOrganizationSettings.management_call_notification_expired_yr_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_call_notification_expired_yr_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes after a protection expires should a call go out to management."
          shouldPreventTurningOff
          currentValue={
            editedOrganizationSettings.management_call_notification_expired_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_call_notification_expired_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expiring Soon (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes before a protection expires should a call go out to management."
          currentValue={
            editedOrganizationSettings.management_call_notification_expiring_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_call_notification_expiring_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Failed to Report for Duty"
          hint="If an RWIC fails to report for duty, how many minutes before a protection goes into effect should a call go out to management."
          currentValue={
            editedOrganizationSettings.management_call_notification_failed_report_for_duty
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_call_notification_failed_report_for_duty:
                timeSelectionSanitizer(newValue),
            })
          }
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          PUSH NOTIFICATIONS
        </FsText>
        <OptionEntry
          title="Protection Red flags, Derails, and Switchlocks Not Open"
          hint="If all red flags, derails, and switchlocks are not open, how many minutes after a protection goes into effect should a push notification be sent to management."
          currentValue={
            editedOrganizationSettings.management_push_notification_form_b_unopened_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_form_b_unopened_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={['10 minutes', '20 minutes', '30 minutes', '1 hour']}
        />
        <OptionEntry
          title="Protection Expiring Soon (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes before a protection expires should a push notification be sent to management."
          currentValue={
            editedOrganizationSettings.management_push_notification_expiring_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_expiring_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Yellow-Red Flags)"
          hint="If any yellow-red flags are still open, how many minutes after a protection has expired should a reminder notification be sent to management."
          currentValue={
            editedOrganizationSettings.management_push_notification_expired_yr_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_expired_yr_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes after a protection expires should a push notification go out to management."
          shouldPreventTurningOff
          currentValue={
            editedOrganizationSettings.management_push_notification_expired_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_expired_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <SwitchOptionEntry
          title="Early Cancel Process Initiated"
          hint="Notify management when an RWIC initiates the Early Cancel process"
          offValue={0}
          currentValue={
            editedOrganizationSettings.management_push_notification_early_cancel_initiated
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_early_cancel_initiated:
                newValue === true ? 1 : 0,
            })
          }
        />
        <SwitchOptionEntry
          title="Early Cancel Process Stopped"
          hint="Notify management when an RWIC stops the Early Cancel process. (This will revert the expiration of their protection to its original time.)"
          offValue={0}
          currentValue={
            editedOrganizationSettings.management_push_notification_early_cancel_stopped
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              management_push_notification_early_cancel_stopped:
                newValue === true ? 1 : 0,
            })
          }
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 15,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.xxxbig,
            color: Colors.black,
          }}
        >
          RWIC
        </FsText>
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          CALL NOTIFICATIONS
        </FsText>
        <OptionEntry
          title="Protection Expiring Soon (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes before a protection expires should a call go out to the RWIC."
          currentValue={
            editedOrganizationSettings.flagmen_call_notification_expiring_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_call_notification_expiring_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '10 minutes',
            '20 minutes',
            '30 minutes',
            '40 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Yellow-Red Flags)"
          hint="If any yellow-red flags are still open, how many minutes after a protection has expired should a call go out to the RWIC."
          currentValue={
            editedOrganizationSettings.flagmen_call_notification_expired_yr_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_call_notification_expired_yr_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes after a protection expires should a call go out to the RWIC."
          shouldPreventTurningOff
          currentValue={
            editedOrganizationSettings.flagmen_call_notification_expired_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_call_notification_expired_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Failed to Report for Duty"
          hint="If an RWIC fails to report for duty, how many minutes before a protection goes into effect should a reminder call go out to the RWIC."
          currentValue={
            editedOrganizationSettings.flagmen_call_notification_failed_report_for_duty
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_call_notification_failed_report_for_duty:
                timeSelectionSanitizer(newValue),
            })
          }
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          PUSH NOTIFICATIONS
        </FsText>
        <OptionEntry
          title="Protection Expiring Soon (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes before a protection expires should a reminder notification be sent to the RWIC."
          currentValue={
            editedOrganizationSettings.flagmen_push_notification_expiring_open_red_flags_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_push_notification_expiring_open_red_flags_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '10 minutes',
            '20 minutes',
            '30 minutes',
            '40 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Yellow-Red Flags)"
          hint="If any yellow-red flags are still open, how many minutes after a protection has expired should a reminder notification be sent to the RWIC."
          currentValue={
            editedOrganizationSettings.flagmen_push_notification_expired_open_yr_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_push_notification_expired_open_yr_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <OptionEntry
          title="Protection Expired (Open Red flags, Derails, and Switchlocks)"
          hint="If any red flags, derails, and switchlocks are still open, how many minutes after a protection expires should a push notification go out to the RWIC."
          shouldPreventTurningOff
          currentValue={
            editedOrganizationSettings.flagmen_push_notification_expired_open_flags_form_b_threshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_push_notification_expired_open_flags_form_b_threshold:
                timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '5 minutes',
            '10 minutes',
            '15 minutes',
            '20 minutes',
            '25 minutes',
            '30 minutes',
            '35 minutes',
            '40 minutes',
            '45 minutes',
            '50 minutes',
            '55 minutes',
            '1 hour',
          ]}
        />
        <FsText
          style={{
            paddingLeft: 10,
            paddingTop: 10,
            marginBottom: 5,
            alignItems: 'center',
            textAlign: 'left',
            fontSize: Fonts.size.small,
            color: Colors.textGrey,
            fontWeight: 'bold',
          }}
        >
          Early Cancel
        </FsText>
        <OptionEntry
          title="Item Pickup Time"
          hint="How much time do you want to give an RWIC to pick up their red flags, derails, and switchlocks once they initiate the Early Cancel process?"
          currentValue={
            editedOrganizationSettings.flagmen_early_cancel_theshold
          }
          onChange={(newValue) =>
            setEditedOrganizationSettings({
              ...editedOrganizationSettings,
              flagmen_early_cancel_theshold: timeSelectionSanitizer(newValue),
            })
          }
          options={[
            '30 minutes',
            '45 minutes',
            '1 hour',
            '1:15 hours',
            '1:30 hours',
            '2 hours',
          ]}
        />
      </ScrollableScreen>
      {!isEqual(currentOrganization.settings, editedOrganizationSettings) ? (
        <Fab style={{ backgroundColor: Colors.secondary }} onPress={onSave}>
          <MaterialCommunityIcons
            name={'check'}
            size={Icons.size.big}
            color={Colors.textLight}
            style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
          />
        </Fab>
      ) : null}
    </Screen>
  );
};

// Exports
export default PropertySettingsScreen;
