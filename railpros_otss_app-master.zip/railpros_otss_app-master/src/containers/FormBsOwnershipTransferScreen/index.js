import React, { useState, useEffect } from 'react';
import { FlatList } from 'react-native';
import { NavigationActions } from 'react-navigation';
import { Spinner, View } from 'native-base';
import { useDispatch } from 'react-redux';
import moment from 'moment-timezone';

import { Colors } from '../../constants';
import { ScrollableScreen, FsAlert } from '../../components/CustomComponents';
import { unarchiveAndTransferFormB } from '../../actions/formbs';
import { getExistingUsersSync } from '../../actions/user';
import Screen from '../../components/Screen';
import EntryButton from '../../components/EntryButton';

const FormBsOwnershipTransferScreen = (props) => {
  const [loading, setLoading] = useState(false);
  const [isUnarchived, setIsUnarchived] = useState(false);
  const [sortedAvailableUsers, setSortedAvailableUsers] = useState([]);

  const dispatch = useDispatch();

  // on mount actions
  useEffect(() => {
    onRefresh();
  }, []);

  const sortUsers = (a, b) => {
    if (a.name < b.name) return -1;
    if (a.name > b.name) return 1;
    return 0;
  };

  const onRefresh = async () => {
    const isUnarchived = props.navigation.getParam('isUnarchived');
    setIsUnarchived(isUnarchived || false);

    const formB = props.navigation.getParam('formB');
    const usersData = await getExistingUsersSync(formB.organization_id)
    const users = usersData.filter(({ id, deleted_at }) => id !== formB.created_by && deleted_at === null).sort(sortUsers)

    setSortedAvailableUsers(users);
  };

  const handleUnarchiveAndTransfer = async (transferToUserId, userName) => {
    const formB = props.navigation.getParam('formB');

    try {
      await FsAlert.alertYesCancel(
        `Transfer to ${userName}`,
        `Are you sure you want to transfer this protection to ${userName}?`
      );
      setLoading(true);
      const selectedOption = await unarchiveAndTransferFormB(formB.id, {
        userId: transferToUserId,
        resetFlagsLocation: selectedOption === 'Yes',
        isUnarchived,
      });
      dispatch(NavigationActions.back());
    } catch (error) {
      console.log({ error });
    }
  };

  if (!sortedAvailableUsers || loading)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  return (
    <Screen title={isUnarchived ? 'Transfer to' : 'Unarchive And Transfer To'}>
      <ScrollableScreen
        containerStyle={[{ paddingTop: 0 }]}
        refreshing={
          sortedAvailableUsers && sortedAvailableUsers.length === 0
            ? true
            : false
        }
        onRefresh={onRefresh}
      >
        <FlatList
          data={sortedAvailableUsers}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => item.id.toString()}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => (
            <EntryButton
              onPress={() =>
                handleUnarchiveAndTransfer(rowData.item.id, rowData.item.name)
              }
              icon="user"
              text={rowData.item.name}
            />
          )}
        />
      </ScrollableScreen>
    </Screen>
  );
};

// Exports
export default FormBsOwnershipTransferScreen;
