import React from 'react';
import { Platform, View, Dimensions, Image, Linking } from 'react-native';
import {
  Container,
  Button,
  Header,
  Body,
  Title,
  Spinner,
  Icon,
} from 'native-base';
import MapView, { Marker, PROVIDER_GOOGLE, Callout } from 'react-native-maps';
import { connect } from 'react-redux';
import _ from 'lodash';
import moment from 'moment-timezone';
import haversine from 'haversine';

import { Styles, Colors, Icons, Fonts, GeoLocations } from '../../constants';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { establishFlag } from '../../actions/flags';
import { FsAlert, FsButton, FsText } from '../../components/CustomComponents';
import { FlagLabelMarker, HeaderMessageCallout } from '../../components';
import {
  getFlagIcon,
  getFlagCoordinate,
  buildFlagMarkerLabel,
  getFlagType,
} from '../../sharedMethods/flags';
import {
  verifyLocationPermissions,
  getCurrentPosition,
} from '../../sharedMethods/location';

const HeaderMessageCalloutLocation = (props) => {
  return (
    <HeaderMessageCallout {...props}>
      <View
        style={{
          marginTop: 4,
          display: 'flex',
          flexDirection: 'row',
          alignSelf: 'center',
          justifyContent: 'center',
          alignItems: 'center',
          width: '90%',
        }}
      >
        <Image
          source={require('../../assets/images/ic_gps_indicator.png')}
          style={{ tintColor: '#6d6d6d', width: 40, height: 40 }}
        />
        <FsText
          style={{
            padding: 6,
            textAlign: 'center',
          }}
        >
          {props.text}
        </FsText>
      </View>
    </HeaderMessageCallout>
  );
};

class EstablishFlagMapScreen extends React.Component {
  constructor(props) {
    super(props);
    const flag = props.navigation.getParam('flag');
    this.state = {
      flag,
      marginBottom: 1,
      gps: undefined,
      loading: true,
      flagsWithLocationsForFormB: [],
      formB: {},
      loadingLocationAsync: false,
      isCalloutVisible: true,
      calloutText:
        'Tap the target icon to get an accurate fix on your current position.',
    };
  }

  async componentDidMount() {
    await verifyLocationPermissions(Linking, this.props.navigation);
    const { openFlagsForFormB, formB } = this.extractFormBData();
    this.setState({ openFlagsForFormB, formB, loading: false });
  }

  extractFormBData() {
    let flagsWithLocationsForFormB = _.cloneDeep(
      this.props.flagsByFormB[this.state.flag.protection_id]
    );

    if (Array.isArray(flagsWithLocationsForFormB)) {
      flagsWithLocationsForFormB = flagsWithLocationsForFormB.filter(
        (flag) => flag.established_gps_lat
      );
    }

    const formB =
      this.props.formbs.length > 0
        ? this.props.formbs.find(
            (formB) => formB.id === this.state.flag.protection_id
          )
        : undefined;
    return {
      flagsWithLocationsForFormB,
      formB,
    };
  }

  fetchCurrentLocationAsync = async () => {
    const currentPosition = await getCurrentPosition();
    return {
      latitude: currentPosition.coords.latitude,
      longitude: currentPosition.coords.longitude,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  };

  moveCameraToCurrentPositionAsync = async () => {
    this.setState({
      loadingLocationAsync: true,
      isCalloutVisible: true,
      calloutText: `If the pin's location is correct, tap the checkmark in the top right to set your flag.`,
    });
    const currentPosition = await this.fetchCurrentLocationAsync();
    this.state.mapRef &&
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
    this.setState({ loadingLocationAsync: false });
  };

  fetchCurrentLocation() {
    return {
      ...this.props.currentLocation,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  }

  moveCameraToCurrentPosition = () => {
    this.moveCameraToCurrentPositionAsync();
    const currentPosition = this.fetchCurrentLocation();
    this.state.mapRef &&
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
  };

  render() {
    if (this.state.loading)
      return (
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <Spinner color={Colors.secondary} />
        </View>
      );
    const { isDerail, isFormB } = getFlagType(this.state.flag);
    return (
      <Container>
        <Header style={{ ...Styles.general.header, paddingTop: 0, height: 56 }}>
          <Button
            onPress={() => {
              this.props.navigation.goBack();
            }}
            style={{ ...Styles.general.headerButton }}
          >
            <MaterialCommunityIcons
              name={'arrow-left'}
              size={Icons.size.big}
              color={Colors.textLight}
              style={[{ top: 1 }, { maxWidth: 20 }, { textAlign: 'center' }]}
            />
          </Button>
          <Body
            style={{ paddingRight: 0, alignItems: 'center', paddingLeft: 0 }}
          >
            <Title style={{ paddingLeft: 0 }}>
              {isDerail ? 'Place Derail' : `Set ${isFormB ? 'Flag' : 'Switch'}`}
            </Title>
          </Body>
          <Button
            onPress={this.saveChanges}
            style={{ ...Styles.general.headerButton }}
          >
            <MaterialCommunityIcons
              name={'check'}
              size={Icons.size.big}
              color={Colors.textLight}
              style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
            />
          </Button>
        </Header>
        <View
          style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
        >
          {!this.state.mapRef && (
            <View
              style={{
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Spinner color={Colors.secondary} />
            </View>
          )}
          <MapView
            {...Platform.select({
              ios: {
                provider: PROVIDER_GOOGLE,
              },
              android: {
                provider: PROVIDER_GOOGLE,
              },
            })}
            ref={(ref) => {
              if (!this.state.mapRef) {
                this.setState({ mapRef: ref });
              }
            }}
            style={[
              { width: Dimensions.get('window').width },
              {
                height:
                  Dimensions.get('window').height -
                  Styles.constant.StackNavigatorHeaderBarHeight,
              },
              { alignSelf: 'center' },
              { flex: 1 },
              { marginBottom: this.state.marginBottom },
            ]}
            mapType="hybrid"
            initialRegion={{
              ...this.props.currentLocation,
              latitudeDelta: 0.001,
              longitudeDelta: 0.001,
            }}
            moveOnMarkerPress={false}
            onRegionChangeComplete={this.onRegionChangeComplete}
            mapPadding={Styles.constant.MapViewEdgePaddingGoogleMaps}
          >
            {Array.isArray(this.state.flagsWithLocationsForFormB) &&
              this.state.flagsWithLocationsForFormB.map((flag) => (
                <Marker
                  key={'Marker' + flag.id}
                  coordinate={getFlagCoordinate(flag)}
                  pinColor={getFlagIcon(flag.type)}
                />
              ))}
            {Array.isArray(this.state.flagsWithLocationsForFormB) &&
              this.state.flagsWithLocationsForFormB.map((flag) => (
                <FlagLabelMarker
                  {...getFlagType(this.state.flag)}
                  key={'FlagLabelMarker' + flag.id}
                  flag={flag}
                />
              ))}
          </MapView>
          {this.state.gps && this.state.mapRef && (
            <RedirectToCurrentLoc
              onPress={this.moveCameraToCurrentPosition}
              loading={this.state.loadingLocationAsync}
            />
          )}
          <View style={{ position: 'absolute', flex: 1, alignItems: 'center' }}>
            <Icon
              name="map-marker"
              type="MaterialCommunityIcons"
              style={{
                fontSize: 50,
                color: getFlagIcon(this.state.flag.type),
              }}
            />
            <FsText
              style={[
                {
                  color: this.state.flag.is_established
                    ? Colors.red
                    : Colors.text,
                },
                { borderRadius: 12 },
                { paddingHorizontal: 8, paddingVertical: 2 },
                { backgroundColor: Colors.offwhite + 'bb' },
                { fontSize: Fonts.size.xxxxsmall },
                { textAlign: 'center' },
                { fontWeight: 'bold' },
              ]}
            >
              {buildFlagMarkerLabel(this.state.flag, isDerail, isFormB)}
            </FsText>
          </View>
          {this.state.isCalloutVisible && (
            <HeaderMessageCalloutLocation
              text={this.state.calloutText}
              onPress={() => this.setState({ isCalloutVisible: false })}
            />
          )}
        </View>
      </Container>
    );
  }

  saveChanges = async () => {
    this.setState({ loading: true });
    const { isDerail, isFormB } = getFlagType(this.state.flag);
    const userCoords = this.props.currentLocation;
    const flagCoords = {
      latitude: this.state.gps?.latitude,
      longitude: this.state.gps?.longitude,
    };
    const distanceBetweenUserAndFlag = haversine(userCoords, flagCoords, {
      unit: 'mile',
    });
    if (
      distanceBetweenUserAndFlag > GeoLocations.MAX_DISTANCE_THRESHOLD &&
      this.props.userData.role_name === 'Flagman'
    ) {
      FsAlert.alertOk(
        'Too Far Away',
        `You have to be within ${
          GeoLocations.MAX_DISTANCE_THRESHOLD
        } miles of your ${
          isDerail ? 'derail' : isFormB ? 'flag' : 'switch-lock'
        } and you are ${distanceBetweenUserAndFlag.toFixed(2)} miles away.`
      );
    } else {
      try {
        await this.confirmSave();
        await this.props.establishFlag({
          orgId: this.props.currentOrganization.settings.id,
          formBId: this.state.flag.protection_id,
          flagId: this.state.flag.id,
          flagPayload: {
            // established_at_utc: moment().utc().format('YYYY-MM-DDTHH:mm:ssZ'),
            established_gps_long: this.state.gps.longitude,
            established_gps_lat: this.state.gps.latitude,
          },
        });
        this.props.navigation.goBack();
      } catch (err) {}
    }
    this.setState({ loading: false });
    return;
  };

  confirmSave = () => {
    return FsAlert.alertYesCancel(
      'Confirm Save',
      'Please make sure that your flag is being established properly.',
      'Yes, Save'
    );
  };

  onRegionChangeComplete = (region) => {
    this.setState({ gps: region });
  };
}
const RedirectToCurrentLoc = (props) => {
  return (
    <Callout
      style={[
        { alignSelf: 'flex-end' },
        { bottom: 30 },
        { zIndex: 99999999 },
        { right: 10 },
      ]}
    >
      <FsButton
        style={[
          { height: 60 },
          { width: 60 },
          { borderRadius: 30 },
          { backgroundColor: '#ffffff' },
          { alignSelf: 'center' },
          { alignItems: 'center' },
          { justifyContent: 'center' },
          Styles.general.shadowLightBorder,
          Styles.general.shadow,
        ]}
        onPress={props.onPress}
      >
        {props.loading ? (
          <Spinner color={Colors.secondary} />
        ) : (
          <Image
            source={require('../../assets/images/ic_gps_indicator.png')}
            style={{ tintColor: '#6d6d6d', width: 40, height: 40 }}
          />
        )}
      </FsButton>
    </Callout>
  );
};

const mapStateToProps = (state) => {
  return {
    currentLocation: state.location,
    userData: state.auth.user,
    flagsByFormB: state.flagsByFormB.data,
    formbs: state.formbs.data,
    currentOrganization: state.organizations.currentOrganization,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    establishFlag: (payload) => dispatch(establishFlag(payload)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(EstablishFlagMapScreen);
