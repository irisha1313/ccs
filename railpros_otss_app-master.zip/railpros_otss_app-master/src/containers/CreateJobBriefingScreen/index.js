import React, { useState, useEffect } from 'react';
import { View } from 'native-base';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSelector, useDispatch } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import QRCode from 'qrcode';
import { SvgXml } from 'react-native-svg';
import CheckBox from 'react-native-check-box';
import moment from 'moment-timezone';
import { TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

import { actionButtonStyle } from './styles';
import { Colors, Styles, Icons, Fonts } from '../../constants';
import {
  FsButtonActionIcon,
  ScrollableScreen,
  FsText,
  FsAlert,
  FsInputWithLabel,
} from '../../components/CustomComponents';
import { Screen, PreviewModal } from '../../components';
import { createJobBriefing } from '../../actions/jobBriefings';
import TimePicker from '../../components/TimePicker';

const CreateJobBriefingScreen = (props) => {
  const dispatch = useDispatch();

  const [loading, setLoading] = useState(false);
  const [previewConsentQRCode, setPreviewConsentQRCode] = useState('');
  const [formB, setFormB] = useState(undefined);
  const [trackWarrantAuthNumber, setTrackWarrantAuthNumber] = useState('');
  const [formBFromMP, setFormBFromMP] = useState('');
  const [formBToMP, setFormBToMP] = useState('');
  const [trackAndTimeNumber, setTrackAndTimeNumber] = useState('');
  const [fromCP, setFromCP] = useState('');
  const [toCP, setToCP] = useState('');
  const [fromSwitch, setFromSwitch] = useState(false);
  const [toSwitch, setToSwitch] = useState(false);
  const [trackWarrantUntil, setTrackWarrantUntil] = useState(null);
  const [trackWarrantOkdAt, setTrackWarrantOkdAt] = useState(null);
  const [trackWarrantDispatcherInitials, setTrackWarrantDispatcherInitials] =
    useState('');
  const [sightDistance, setSightDistance] = useState('');
  const [formBJobSiteMP, setFormBJobSiteMP] = useState('');
  const [bulletinNumber, setBulletinNumber] = useState('');
  const [formBJobNumber, setFormBJobNumber] = useState('');
  const [subdivision, setSubdivision] = useState('');
  const [fromTime, setFromTime] = useState(null);
  const [toTime, setToTime] = useState(null);
  const [trackWarrantJobNumber, setTrackWarrantJobNumber] = useState('');
  const [trackWarrantJobsiteMP, setTrackWarrantJobsiteMP] = useState('');
  const [trackWarrantFromMP, setTrackWarrantFromMP] = useState('');
  const [trackWarrantToMP, setTrackWarrantToMP] = useState('');
  const [trackAndTimeJobNumber, setTrackAndTimeJobNumber] = useState('');
  const [trackAndTimeJobsiteMP, setTrackAndTimeJobsiteMP] = useState('');
  const [isMainTrack, setIsMainTrack] = useState(false);
  const [hasControlledSiding, setHasControlledSiding] = useState(false);
  const [trackAndTimeUntil, setTrackAndTimeUntil] = useState(null);
  const [trackAndTimeOkdAt, setTrackAndTimeOkdAt] = useState(null);
  const [trackAndTimeDispatcherInitials, setTrackAndTimeDispatcherInitials] =
    useState('');
  const [watchmanLookoutJobsiteMP, setWatchmanLookoutJobsiteMP] = useState('');
  const [watchmanLookoutJobNumber, setWatchmanLookoutJobNumber] = useState('');
  const [methodOfWarning, setMethodOfWarning] = useState('');

  const [isFormBSectionVisible, setIsFormBSectionVisible] = useState(false);
  const [isTrackWarrantVisible, setIsTrackWarrantVisible] = useState(false);
  const [isTrackAndTimeVisible, setIsTrackAndTimeVisible] = useState(false);
  const [isWatchmanLookoutVisible, setIsWatchmanLookoutVisible] =
    useState(false);

  const { userData, location } = useSelector(({ auth, location }) => ({
    userData: auth.user,
    location,
  }));

  const updateFromAndformBToMPs = (flags) => {
    if (!flags || flags.length === 0) {
      return;
    }

    const redFlags = flags.filter(({ type }) => type === 'red');

    if (redFlags.length === 0) {
      return;
    }

    setFormBFromMP(redFlags[0].mile_post);

    const lastRedFlagPosition = redFlags.length - 1;

    if (lastRedFlagPosition > 0) {
      setFormBToMP(redFlags[lastRedFlagPosition].mile_post);
    }
  };

  const syncFromReceivedInformation = ({
    job_site_mile_post,
    job_number,
    subdivision,
    open_time,
    close_time,
    original_close_time,
  }) => {
    if (!isNaN(Number(job_site_mile_post)) && job_site_mile_post !== null) {
      setFormBJobSiteMP(job_site_mile_post);
    }
    setFormBJobNumber(job_number || '');
    setSubdivision(subdivision);
    setFromTime(open_time);
    setToTime(original_close_time || close_time);
  };

  const initialize = () => {
    const receivedFormB = props.navigation.getParam('formB');
    const receivedFlags = props.navigation.getParam('flags');

    if (!receivedFormB) {
      return;
    }

    if (
      !isNaN(Number(receivedFormB.mile_post)) &&
      job_site_mile_post !== null
    ) {
      setFormBJobSiteMP(receivedFormB.mile_post);
    }

    syncFromReceivedInformation(receivedFormB);

    updateFromAndformBToMPs(receivedFlags);
    setFormB(receivedFormB);
  };

  useEffect(() => {
    initialize();
  }, []);

  const handleCreateJobBriefing = async () => {
    setLoading(true);

    const { latitude, longitude } = location;

    const jobBriefingPayload = {
      protection_id: formB ? formB.id : null,
      track_warrant_auth_number: trackWarrantAuthNumber,
      protection_from_mp: formBFromMP,
      protection_to_mp: formBToMP,
      track_and_time_number: trackAndTimeNumber,
      from_cp: fromCP,
      from_switch: fromSwitch,
      to_cp: toCP,
      to_switch: toSwitch,
      track_warrant_until: trackWarrantUntil,
      track_warrant_okd_at: trackWarrantOkdAt,
      track_warrant_dispatcher_initials: trackWarrantDispatcherInitials,
      sight_distance: sightDistance,
      protection_jobsite_mp: formBJobSiteMP,
      bulletin_number: bulletinNumber,
      protection_job_number: formBJobNumber,
      subdivision,
      from_time: fromTime,
      to_time: toTime,
      track_warrant_job_number: trackWarrantJobNumber,
      track_warrant_jobsite_mp: trackWarrantJobsiteMP,
      track_warrant_from_mp: trackWarrantFromMP,
      track_warrant_to_mp: trackWarrantToMP,
      track_and_time_job_number: trackAndTimeJobNumber,
      track_and_time_jobsite_mp: trackAndTimeJobsiteMP,
      is_main_track: isMainTrack,
      has_controlled_siding: hasControlledSiding,
      track_and_time_until: trackAndTimeUntil,
      track_and_time_okd_at: trackAndTimeOkdAt,
      track_and_time_dispatcher_initials: trackAndTimeDispatcherInitials,
      watchman_lookout_jobsite_mp: watchmanLookoutJobsiteMP,
      watchman_lookout_job_number: watchmanLookoutJobNumber,
      method_of_warning: methodOfWarning,
      latitude,
      longitude,
    };

    const jobBriefingCreationResult = await createJobBriefing(
      jobBriefingPayload
    );

    await FsAlert.alertOk(
      'Job Briefing Created Succesfully',
      `Success! Here is your custom QR code. Have each contractor open up their camera app and scan the code. Once scanned, they will be taken to a custom webpage where they will enter their name and phone number to acknowledge the briefing. This form is intended for individual use only and does not allow group sign in. Additionally, a copy of this QR code has been emailed to you at ${userData.email} for reference or additional job briefings.`
    );

    const jobBriefingUrl = `${Constants.expoConfig.extra.job_briefing_site}/${jobBriefingCreationResult.uuid}`;
    const qrCodeImageURL= await QRCode.toString(jobBriefingUrl, {
      type: 'svg',
    });

    setPreviewConsentQRCode(qrCodeImageURL);
  };

  const previewModalVisibility = previewConsentQRCode !== '';

  return (
    <Screen
      onBackPress={() => dispatch(NavigationActions.back())}
      title={
        formB ? `Job Briefing for ${formB.subdivision} Sub` : 'New Job Briefing'
      }
    >
      {previewModalVisibility && (
        <PreviewModal
          visible={previewModalVisibility}
          backButtonColor="black"
          containerStyle={{ backgroundColor: 'white' }}
          toggleModal={() => {
            setPreviewConsentQRCode('');
            dispatch(NavigationActions.back());
          }}
        >
          <SvgXml
            xml={previewConsentQRCode}
            width="80%"
            height="80%"
            style={{ alignSelf: 'center' }}
          />
        </PreviewModal>
      )}
      <ScrollableScreen
        containerStyle={{ paddingTop: 0, paddingBottom: 240 }}
        refreshing={loading || !formB}
      >
        <TouchableOpacity
          onPress={() => setIsFormBSectionVisible(!isFormBSectionVisible)}
        >
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <FsText
              style={{
                paddingLeft: 10,
                paddingTop: 20,
                marginBottom: 5,
                alignItems: 'center',
                textAlign: 'left',
                justifyContent: 'center',
                fontSize: Fonts.size.normal,
                color: Colors.textGrey,
                fontWeight: 'bold',
              }}
            >
              FORM B/C/DERAILS/LOCKS
            </FsText>
            <MaterialCommunityIcons
              name={isFormBSectionVisible ? 'chevron-up' : 'chevron-down'}
              color={Colors.secondaryTextGrey}
              size={20}
              style={{ paddingTop: 15 }}
            />
          </View>
        </TouchableOpacity>
        {isFormBSectionVisible && (
          <>
            <FsInputWithLabel
              name="bulletinNumber"
              label="Bulletin Number"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setBulletinNumber}
              value={bulletinNumber}
            />
            <FsInputWithLabel
              name="formBJobNumber"
              label="Job #"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setFormBJobNumber}
              value={formBJobNumber}
            />
            <FsInputWithLabel
              name="formBJobSiteMP"
              label="Jobsite MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={(text) => {
                if (isNaN(text)) {
                  FsAlert.alertOk(
                    'Invalid Input',
                    'Please make sure your jobsite MP is written as a decimal value.'
                  );
                } else {
                  setFormBJobSiteMP(text);
                }
              }}
              value={formBJobSiteMP}
            />
            <FsInputWithLabel
              name="subdivision"
              label="Subdivision"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setSubdivision}
              value={subdivision}
            />
            <View
              style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <FsText
                style={{
                  flex: 1,
                  paddingLeft: 20,
                  paddingTop: 10,
                  marginBottom: 5,
                  alignItems: 'center',
                  textAlign: 'left',
                  fontSize: Fonts.size.small,
                  color: Colors.textGrey,
                  fontWeight: 'bold',
                }}
              >
                Times
              </FsText>
              <TimePicker
                title="From"
                labelStyle={{
                  fontFamily: 'RobotoCondensed-Regular',
                  fontSize: Fonts.size.normal,
                  color: 'black',
                }}
                value={fromTime}
                onChange={(time) => {
                  const newTime = moment(time)
                    .seconds(0)
                    .milliseconds(0)
                    .format('HH:mm');
                  setFromTime(newTime);
                }}
                containerStyle={{ flex: 3, marginTop: 24, marginLeft: 15 }}
                buttonLabelStyle={{
                  width: '100%',
                  padding: 0,
                  paddingHorizontal: 8,
                  borderBottomWidth: 1,
                  borderColor: '#BDBDBD',
                }}
              />
              <TimePicker
                title="To"
                labelStyle={{
                  fontFamily: 'RobotoCondensed-Regular',
                  fontSize: Fonts.size.normal,
                  color: 'black',
                }}
                value={toTime}
                onChange={(time) => {
                  const newTime = moment(time)
                    .seconds(0)
                    .milliseconds(0)
                    .format('HH:mm');
                  setToTime(newTime);
                }}
                containerStyle={{ flex: 3, marginTop: 24, marginLeft: 15 }}
                buttonLabelStyle={{
                  width: '100%',
                  padding: 0,
                  paddingHorizontal: 8,
                  borderBottomWidth: 1,
                  borderColor: '#BDBDBD',
                }}
              />
            </View>
            <FsInputWithLabel
              name="formBFromMP"
              label="From MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setFormBFromMP}
              value={formBFromMP}
            />
            <FsInputWithLabel
              name="formBToMP"
              label="To MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setFormBToMP}
              value={formBToMP}
            />
          </>
        )}
        <TouchableOpacity
          onPress={() => setIsTrackWarrantVisible(!isTrackWarrantVisible)}
        >
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <FsText
              style={{
                paddingLeft: 10,
                paddingTop: 20,
                marginBottom: 5,
                alignItems: 'center',
                textAlign: 'left',
                justifyContent: 'center',
                fontSize: Fonts.size.normal,
                color: Colors.textGrey,
                fontWeight: 'bold',
              }}
            >
              TRACK WARRANT
            </FsText>
            <MaterialCommunityIcons
              name={isTrackWarrantVisible ? 'chevron-up' : 'chevron-down'}
              color={Colors.secondaryTextGrey}
              size={20}
              style={{ paddingTop: 15 }}
            />
          </View>
        </TouchableOpacity>
        {isTrackWarrantVisible && (
          <>
            <FsInputWithLabel
              name="trackWarrantAuthNumber"
              label="Track Warrant #"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantAuthNumber}
              value={trackWarrantAuthNumber}
            />
            <FsInputWithLabel
              name="trackWarrantJobNumber"
              label="Job #"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantJobNumber}
              value={trackWarrantJobNumber}
            />
            <FsInputWithLabel
              name="trackWarrantJobNumber"
              label="Jobsite MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantJobsiteMP}
              value={trackWarrantJobsiteMP}
            />
            <FsInputWithLabel
              name="trackWarrantFromMP"
              label="From MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantFromMP}
              value={trackWarrantFromMP}
            />
            <FsInputWithLabel
              name="trackWarrantToMP"
              label="To MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantToMP}
              value={trackWarrantToMP}
            />
            <TimePicker
              title="Until"
              labelStyle={{
                fontFamily: 'RobotoCondensed-Regular',
                fontSize: Fonts.size.normal,
                color: 'black',
              }}
              value={trackWarrantUntil}
              onChange={(time) => {
                const newTime = moment(time)
                  .seconds(0)
                  .milliseconds(0)
                  .format('HH:mm');
                setTrackWarrantUntil(newTime);
              }}
              containerStyle={{ marginTop: 24, marginLeft: 15 }}
              buttonLabelStyle={{
                width: '100%',
                padding: 0,
                paddingHorizontal: 8,
                borderBottomWidth: 1,
                borderColor: '#BDBDBD',
              }}
            />
            <TimePicker
              title="Ok'd at"
              labelStyle={{
                fontFamily: 'RobotoCondensed-Regular',
                fontSize: Fonts.size.normal,
                color: 'black',
              }}
              value={trackWarrantOkdAt}
              onChange={(time) => {
                const newTime = moment(time)
                  .seconds(0)
                  .milliseconds(0)
                  .format('HH:mm');
                setTrackWarrantOkdAt(newTime);
              }}
              containerStyle={{ marginTop: 24, marginLeft: 15 }}
              buttonLabelStyle={{
                width: '100%',
                padding: 0,
                paddingHorizontal: 8,
                borderBottomWidth: 1,
                borderColor: '#BDBDBD',
              }}
            />
            <FsInputWithLabel
              name="trackWarrantDispatcherInitials"
              label="Dispatcher Initials"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackWarrantDispatcherInitials}
              value={trackWarrantDispatcherInitials}
            />
          </>
        )}
        <TouchableOpacity
          onPress={() => setIsTrackAndTimeVisible(!isTrackAndTimeVisible)}
        >
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <FsText
              style={{
                paddingLeft: 10,
                paddingTop: 20,
                marginBottom: 5,
                alignItems: 'center',
                textAlign: 'left',
                justifyContent: 'center',
                fontSize: Fonts.size.normal,
                color: Colors.textGrey,
                fontWeight: 'bold',
              }}
            >
              TRACK &amp; TIME
            </FsText>
            <MaterialCommunityIcons
              name={isTrackAndTimeVisible ? 'chevron-up' : 'chevron-down'}
              color={Colors.secondaryTextGrey}
              size={20}
              style={{ paddingTop: 15 }}
            />
          </View>
        </TouchableOpacity>
        {isTrackAndTimeVisible && (
          <>
            <FsInputWithLabel
              name="trackAndTime#"
              label={`Track & Time #`}
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackAndTimeNumber}
              value={trackAndTimeNumber}
            />
            <FsInputWithLabel
              name="trackAndTimeJobNumber"
              label="Job #"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackAndTimeJobNumber}
              value={trackAndTimeJobNumber}
            />
            <FsInputWithLabel
              name="trackAndTimeJobNumber"
              label="Jobsite MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackAndTimeJobsiteMP}
              value={trackAndTimeJobsiteMP}
            />
            <View style={{ display: 'flex', flexDirection: 'row' }}>
              <FsInputWithLabel
                name="fromCP"
                label="From CP"
                returnKeyType="next"
                autoCorrect={false}
                autoCapitalize="none"
                selectTextOnFocus={true}
                containerStyle={{
                  flex: 6,
                  marginLeft: 12,
                  marginTop: 10,
                }}
                onChangeText={setFromCP}
                value={fromCP}
              />
              <CheckBox
                style={{ paddingVertical: 10, paddingHorizontal: 15, flex: 6 }}
                rightTextStyle={{
                  ...Styles.general.fontFamily,
                  color: Colors.textSecondary,
                }}
                checkBoxColor={Colors.secondary}
                checkedCheckBoxColor={Colors.secondarySharp}
                onClick={() => setFromSwitch(!fromSwitch)}
                isChecked={fromSwitch}
                rightText="Has Switch"
              />
            </View>
            <View style={{ display: 'flex', flexDirection: 'row' }}>
              <FsInputWithLabel
                name="toCP"
                label="To CP"
                returnKeyType="next"
                autoCorrect={false}
                autoCapitalize="none"
                selectTextOnFocus={true}
                containerStyle={{ flex: 6, marginLeft: 12, marginTop: 10 }}
                onChangeText={setToCP}
                value={toCP}
              />
              <CheckBox
                style={{ paddingVertical: 10, paddingHorizontal: 15, flex: 6 }}
                rightTextStyle={{
                  ...Styles.general.fontFamily,
                  color: Colors.textSecondary,
                }}
                checkBoxColor={Colors.secondary}
                checkedCheckBoxColor={Colors.secondarySharp}
                onClick={() => setToSwitch(!toSwitch)}
                isChecked={toSwitch}
                rightText="Has Switch"
              />
            </View>
            <CheckBox
              style={{
                marginTop: 15,
                paddingVertical: 10,
                paddingHorizontal: 15,
              }}
              rightTextStyle={{
                ...Styles.general.fontFamily,
                color: Colors.textSecondary,
              }}
              checkBoxColor={Colors.secondary}
              checkedCheckBoxColor={Colors.secondarySharp}
              onClick={() => setIsMainTrack(!isMainTrack)}
              isChecked={isMainTrack}
              rightText="Main Track"
            />
            <CheckBox
              style={{ paddingVertical: 10, paddingHorizontal: 15 }}
              rightTextStyle={{
                ...Styles.general.fontFamily,
                color: Colors.textSecondary,
              }}
              checkBoxColor={Colors.secondary}
              checkedCheckBoxColor={Colors.secondarySharp}
              onClick={() => setHasControlledSiding(!hasControlledSiding)}
              isChecked={hasControlledSiding}
              rightText="Controlled Siding"
            />
            <TimePicker
              title="Until"
              labelStyle={{
                fontFamily: 'RobotoCondensed-Regular',
                fontSize: Fonts.size.normal,
                color: 'black',
              }}
              value={trackAndTimeUntil}
              onChange={(time) => {
                const newTime = moment(time)
                  .seconds(0)
                  .milliseconds(0)
                  .format('HH:mm');
                setTrackAndTimeUntil(newTime);
              }}
              containerStyle={{ marginTop: 24, marginLeft: 15 }}
              buttonLabelStyle={{
                width: '100%',
                padding: 0,
                paddingHorizontal: 8,
                borderBottomWidth: 1,
                borderColor: '#BDBDBD',
              }}
            />
            <TimePicker
              title="Ok'd at"
              labelStyle={{
                fontFamily: 'RobotoCondensed-Regular',
                fontSize: Fonts.size.normal,
                color: 'black',
              }}
              value={trackAndTimeOkdAt}
              onChange={(time) => {
                const newTime = moment(time)
                  .seconds(0)
                  .milliseconds(0)
                  .format('HH:mm');
                setTrackAndTimeOkdAt(newTime);
              }}
              containerStyle={{ marginTop: 24, marginLeft: 15 }}
              buttonLabelStyle={{
                width: '100%',
                padding: 0,
                paddingHorizontal: 8,
                borderBottomWidth: 1,
                borderColor: '#BDBDBD',
              }}
            />
            <FsInputWithLabel
              name="trackAndTimeDispatcherInitials"
              label="Dispatcher Initials"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setTrackAndTimeDispatcherInitials}
              value={trackAndTimeDispatcherInitials}
            />
          </>
        )}
        <TouchableOpacity
          onPress={() => setIsWatchmanLookoutVisible(!isWatchmanLookoutVisible)}
        >
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
            }}
          >
            <FsText
              style={{
                paddingLeft: 10,
                paddingTop: 20,
                marginBottom: 5,
                alignItems: 'center',
                textAlign: 'left',
                justifyContent: 'center',
                fontSize: Fonts.size.normal,
                color: Colors.textGrey,
                fontWeight: 'bold',
              }}
            >
              WATCHMAN/LOOKOUT
            </FsText>
            <MaterialCommunityIcons
              name={isWatchmanLookoutVisible ? 'chevron-up' : 'chevron-down'}
              color={Colors.secondaryTextGrey}
              size={20}
              style={{ paddingTop: 15 }}
            />
          </View>
        </TouchableOpacity>
        {isWatchmanLookoutVisible && (
          <>
            <FsInputWithLabel
              name="sightDistance"
              label="Sight Distance"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={(text) => {
                if (isNaN(text)) {
                  FsAlert.alertOk(
                    'Invalid Input',
                    'Please make sure your sight distance is written as a decimal value.'
                  );
                } else {
                  setSightDistance(text);
                }
              }}
              value={sightDistance}
            />
            <FsInputWithLabel
              name="watchmanLookoutJobsiteMP"
              label="Jobsite MP"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={(text) => {
                if (isNaN(text)) {
                  FsAlert.alertOk(
                    'Invalid Input',
                    'Please make sure your jobsite MP is written as a decimal value.'
                  );
                } else {
                  setWatchmanLookoutJobsiteMP(text);
                }
              }}
              value={watchmanLookoutJobsiteMP}
            />
            <FsInputWithLabel
              name="watchmanLookoutJobNumber"
              label="Job #"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setWatchmanLookoutJobNumber}
              value={watchmanLookoutJobNumber}
            />
            <FsInputWithLabel
              name="methodOfWarning"
              label="Method of Warning"
              returnKeyType="next"
              autoCorrect={false}
              autoCapitalize="none"
              selectTextOnFocus={true}
              containerStyle={{ flex: 1, marginLeft: 12, marginTop: 10 }}
              onChangeText={setMethodOfWarning}
              value={methodOfWarning}
            />
          </>
        )}
        <FsButtonActionIcon
          title=""
          style={actionButtonStyle}
          onPress={handleCreateJobBriefing}
          renderIcon={(color) => (
            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
              <MaterialCommunityIcons
                name="qrcode"
                color={color}
                size={Icons.size.normal}
              />
              <FsText style={{ color: Colors.textLight, paddingHorizontal: 8 }}>
                GENERATE QR CODE
              </FsText>
            </View>
          )}
        />
      </ScrollableScreen>
    </Screen>
  );
};

export default CreateJobBriefingScreen;
