import { Styles, Colors, Fonts } from '../../constants/';

export const inputStyle = {
  ...Styles.general.fsInputStyle,
  ...Styles.general.fsInputStyleMultiline,
  fontSize: Fonts.size.small,
  borderTopWidth: 1,
  borderBottomWidth: 1,
  borderLeftWidth: 1,
  borderRightWidth: 1,
  borderColor: Colors.divider,
  borderBottomLeftRadius: Styles.constant.BorderRadius,
  borderBottomRightRadius: Styles.constant.BorderRadius,
  height: 80,
  paddingTop: 25,
  backgroundColor: Colors.CardBackground,
};

export const descriptionStyle = {
  color: Colors.textSecondary,
  fontSize: Fonts.size.small,
  textAlign: 'right',
  marginTop: 4,
};

export const actionButtonStyle = {
  alignItems: 'center',
  alignContent: 'center',
  marginHorizontal: 10,
  borderRadius: 10,
  marginTop: 20,
  backgroundColor: Colors.secondarySharpDark,
};
