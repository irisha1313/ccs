import React, { useState, useEffect, useContext } from 'react';
import { FlatList, NavigationContext } from 'react-navigation';
import { Image } from 'react-native';
import isNil from 'lodash/isNil';
import clone from 'lodash/clone';
import {
  MaterialCommunityIcons,
  FontAwesome5,
  FontAwesome,
  MaterialIcons,
} from '@expo/vector-icons';
import { View, Button } from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment-timezone';

import { Colors, Icons, Styles } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsButton,
  FsAlert,
} from '../../components/CustomComponents';
import Screen from '../../components/Screen';
import {
  getRoleName,
  onPressCall,
  onSendEmail,
  getHasAlreadyReportedToDuty,
} from '../../sharedMethods/users';
import {
  getOrganizationDataById,
  getUserOrganization,
} from '../../actions/organizations';
import { sendPastDutyReminder, forcedDebrief } from '../../actions/user';
import ReportForDutyButton from '../../components/ReportForDutyButton';
import { USER_ROLES } from '../../utils/userRoles';

const OrganizationScreen = (props) => {
  const [loading, setLoading] = useState(false);
  const dispatch = useDispatch();
  const { userData, currentOrganizationData } = useSelector((state) => ({
    userData: state.auth.user,
    currentOrganizationData: state.organizations.currentOrganization,
  }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();
  // on mount actions
  useEffect(() => {
    if (isNavigationFocus) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  const onRefresh = async () => {
    setLoading(true);
    await getOrgData();
    setLoading(false);
  };

  const getOrgData = async () => {
    const orgId = props.navigation.getParam('orgId');
    if (orgId) {
      await dispatch(getOrganizationDataById(orgId));
    } else {
      await dispatch(getUserOrganization());
    }
  };

  const onFlagmanPress = (selectedUserData) => {
    props.navigation.navigate('OthersFormBSScreen', {
      currentUserData: selectedUserData,
    });
  };

  const onPressAddUser = () => {
    props.navigation.navigate('CreateNewUserScreen');
  };

  const onPressConfiguration = () => {
    props.navigation.navigate('PropertySettingsScreen');
  };

  const sortFlagmen = (a, b) => (a.name > b.name ? 1 : -1);

  const canGoBack = [USER_ROLES.Director, USER_ROLES.SeniorVP, USER_ROLES.OrgManager, USER_ROLES.Supervisor].includes(
    userData.role_id,
  );

  let sortedFlagmen = []; // the final list used by the component.
  let orderedFlagmenList = clone(currentOrganizationData.flagmen) || [];

  const isCurrentUserFlagmen = userData.role_id === USER_ROLES.Flagmen;

  const currentUserInFlagmenList = orderedFlagmenList.find(
    (flagman) => flagman.id === userData.id
  );

  if (!isCurrentUserFlagmen) {
    if (!isNil(currentUserInFlagmenList)) {
      orderedFlagmenList = orderedFlagmenList.filter(
        (flagman) => flagman.id !== userData.id
      );
    }

    const flagmenWithOpenFlagsAndOnShift = orderedFlagmenList
      .filter(
        (flagman) =>
          (flagman.open_flags > 0 ||
            flagman.open_derails > 0 ||
            flagman.open_switches > 0) &&
          flagman.isOnShift
      )
      .sort(sortFlagmen);
    const flagmenWithOpenFlagsAndOutOfShift = orderedFlagmenList
      .filter(
        (flagman) =>
          (flagman.open_flags > 0 ||
            flagman.open_derails > 0 ||
            flagman.open_switches > 0) &&
          !flagman.isOnShift
      )
      .sort(sortFlagmen);
    const flagmenOnShiftWithoutOpenFlags = orderedFlagmenList
      .filter(
        (flagman) =>
          flagman.isOnShift &&
          flagman.open_flags === 0 &&
          flagman.open_derails === 0 &&
          flagman.open_switches === 0
      )
      .sort(sortFlagmen);
    const flagmenOutOfShiftWithoutOpenFlags = orderedFlagmenList
      .filter(
        (flagman) =>
          !flagman.isOnShift &&
          flagman.open_flags === 0 &&
          flagman.open_derails === 0 &&
          flagman.open_switches === 0
      )
      .sort(sortFlagmen);

    sortedFlagmen = [
      ...flagmenWithOpenFlagsAndOnShift,
      ...flagmenOnShiftWithoutOpenFlags,
      ...flagmenWithOpenFlagsAndOutOfShift,
      ...flagmenOutOfShiftWithoutOpenFlags,
    ];
  }

  if (currentUserInFlagmenList) {
    sortedFlagmen = [{ ...currentUserInFlagmenList, ...userData }].concat(
      sortedFlagmen
    );
  }

  return (
    <Screen
      title={currentOrganizationData.settings.name || ''}
      hasBackButton={canGoBack}
      headerActionButton={
        !isCurrentUserFlagmen && (
          <>
            <Button
              onPress={onPressConfiguration}
              style={Styles.general.headerButton}
            >
              <MaterialIcons
                name="settings"
                size={Icons.size.normal}
                color={Colors.textLight}
                style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
              />
            </Button>
            <Button
              onPress={onPressAddUser}
              style={Styles.general.headerButton}
            >
              <FontAwesome5
                name={'user-plus'}
                size={Icons.size.normal}
                color={Colors.textLight}
                style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
              />
            </Button>
          </>
        )
      }
    >
      {isCurrentUserFlagmen ? (
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 10,
            marginHorizontal: 12,
          }}
        >
          <ReportForDutyButton
            style={{
              width: '100%',
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 4,
              borderRadius: 10,
            }}
            callback={onRefresh}
          />
        </View>
      ) : null}
      <ScrollableScreen
        containerStyle={[{ paddingTop: 0 }]}
        refreshing={loading}
        onRefresh={onRefresh}
      >
        <FlatList
          data={currentOrganizationData.management}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => item.id.toString()}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => (
            <ManagementEntry
              containerStyle={[
                {
                  paddingVertical: 5,
                },
              ]}
              onFormBsPress={onFlagmanPress}
              onSendEmail={onSendEmail}
              userData={rowData.item}
              isSameAsLoggedIn={rowData.item.id === userData.id}
            />
          )}
          contentContainerStyle={[
            {
              marginTop: 12,
              borderBottomWidth: 1,
              borderColor: Colors.divider,
            },
          ]}
        />
        <FlatList
          data={sortedFlagmen}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => item.id.toString()}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => (
            <FlagmanEntry
              containerStyle={[
                {
                  paddingVertical: 10,
                  borderBottomWidth: 1,
                  borderColor: '#dedede',
                },
              ]}
              onPress={onFlagmanPress}
              userData={rowData.item}
              isSameAsLoggedIn={rowData.item.id === userData.id}
              onRefresh={onRefresh}
            />
          )}
        />
      </ScrollableScreen>
    </Screen>
  );
};

const ManagementEntry = (props) => {
  const { userData, isSameAsLoggedIn, onFormBsPress } = props;
  return (
    <View style={[props.containerStyle]}>
      <View style={[{ flexDirection: 'row', alignItems: 'center' }]}>
        <FontAwesome
          name={'user-secret'}
          size={Icons.size.normal}
          color={Colors.primary}
          style={[{ minWidth: 40 }, { textAlign: 'center' }]}
        />
        <View style={[{ flex: 1 }]}>
          <FsText>{!isSameAsLoggedIn ? userData.name : 'Me'}</FsText>

          <FsText>
            <FsText style={Styles.general.inlineSubText}>
              {getRoleName(userData.role_id)}
            </FsText>
          </FsText>
        </View>
        {!isSameAsLoggedIn && (
          <FsButton
            onPress={() => {
              onFormBsPress(userData);
            }}
          >
            <FontAwesome
              name={'align-justify'}
              size={Icons.size.small}
              color={Colors.accent}
            />
          </FsButton>
        )}
        <FsButton
          onPress={() => {
            try {
              props.onSendEmail(userData.name, userData.email);
            } catch (err) {}
          }}
        >
          <FontAwesome5
            name={'envelope'}
            size={Icons.size.small}
            color={Colors.accent}
          />
        </FsButton>
        <FsButton
          onPress={() => {
            try {
              onPressCall(userData.name, userData.phone);
            } catch (err) {}
          }}
        >
          <FontAwesome5
            name={'phone'}
            size={Icons.size.small}
            color={Colors.accent}
          />
        </FsButton>
      </View>
    </View>
  );
};

const FlagmanEntry = (props) => {
  const { userData, isSameAsLoggedIn, onRefresh } = props;

  const isOnDuty = getHasAlreadyReportedToDuty(userData);
  const {
    name,
    isOnShift,
    open_flags,
    open_derails,
    open_switches,
    phone,
    last_reported_to_duty_at_utc,
    last_reported_to_duty_timezone,
  } = userData;
  const formattedLastReportedToDuty =
    !isNil(last_reported_to_duty_at_utc) &&
    !isNil(last_reported_to_duty_timezone) &&
    last_reported_to_duty_timezone !== 'null'
      ? moment
          .utc(last_reported_to_duty_at_utc)
          .tz(last_reported_to_duty_timezone)
          .format('ddd MMM DD HH:mm z')
      : !isNil(last_reported_to_duty_at_utc)
      ? moment.utc(last_reported_to_duty_at_utc).format('ddd MMM DD HH:mm')
      : 'N/A';
  const currentlyOpenFlags = !isNaN(open_flags) && open_flags !== 0;
  const currentlyOpenDerails = !isNaN(open_derails) && open_derails !== 0;
  const currentlyOpenSwitches = !isNaN(open_switches) && open_switches !== 0;
  const hasValidPhone = !isNil(phone) && phone.trim() !== '';

  const sendReminder = async () => {
    if (!phone) {
      return FsAlert.alertOk(
        'Invalid Phone Number',
        `Unable to send reminder as ${name} hasn't still set a valid phone number.`
      );
    }

    await FsAlert.alertYesCancel(
      'End Duty Reminder',
      `Are you sure you want to remind ${name} to end duty?`
    );
    await sendPastDutyReminder(userData.id);
    FsAlert.alertOk(
      'Reminder Sent',
      `${name} has been reminded to debrief for the day.`
    );
  };

  const forceEndDuty = async () => {
    await FsAlert.alertYesCancel(
      'Force End Duty',
      'Have all applicable protections been released back to dispatch or appropriate person?'
    );

    await forcedDebrief(userData.id, {
      last_debriefed_at_utc: moment().utc().format('YYYY-MM-DDTHH:mm:ssZ'),
      last_debriefed_timezone: moment.tz.guess(),
    });

    onRefresh();
  };

  const onReminderPress = async () => {
    try {
      if (isOnDuty) {
        const selectedOption = await FsAlert.alertOptionsCancel(
          `End Duty`,
          `Would you like to remind this user to end duty, or end duty on their behalf?`,
          ['Remind', 'Force End Duty']
        );
        if (selectedOption === 'Remind') {
          await sendReminder();
        } else {
          await forceEndDuty();
        }
      } else {
        await sendReminder();
      }
    } catch (err) {}
  };

  return (
    <View style={[props.containerStyle]}>
      <FsButton
        style={{ padding: 0 }}
        onPress={() => {
          try {
            props.onPress(userData);
          } catch (err) {}
        }}
      >
        <View style={[{ flexDirection: 'row', alignItems: 'center' }]}>
          <FontAwesome
            name={isOnShift ? 'user' : 'user-o'}
            size={Icons.size.normal}
            color={isOnShift ? Colors.green : Colors.secondaryLight}
            style={[{ minWidth: 40 }, { textAlign: 'center' }]}
          />
          <View style={[{ flex: 1 }]}>
            <View style={[{ flexDirection: 'row' }]}>
              <FsText>{!isSameAsLoggedIn ? name : 'Me'}</FsText>
              {isOnDuty && (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    borderRadius: 20,
                    marginLeft: 5,
                    backgroundColor: Colors.redDark,
                  }}
                >
                  <FsText
                    style={{
                      fontSize: 9,
                      padding: 5,
                      color: 'white',
                    }}
                  >
                    On Duty
                  </FsText>
                </View>
              )}
            </View>

            <FsText>
              <FsText style={Styles.general.inlineSubText}>
                {`Last Reported: ${formattedLastReportedToDuty}`}
              </FsText>
              {currentlyOpenFlags || currentlyOpenDerails ? ' | ' : ''}
              {currentlyOpenFlags && (
                <FsText
                  style={{ ...Styles.general.inlineSubText, color: Colors.red }}
                >
                  <MaterialIcons
                    name="flag"
                    size={Icons.size.small}
                    color={Colors.red}
                  />
                  {open_flags}
                </FsText>
              )}{' '}
              {currentlyOpenDerails && (
                <FsText
                  style={{ ...Styles.general.inlineSubText, color: Colors.red }}
                >
                  <Image
                    source={require('../../assets/images/turn-left-red.png')}
                    style={{
                      width: Icons.size.xxsmall,
                      height: Icons.size.xxsmall,
                    }}
                  />{' '}
                  {open_derails}
                </FsText>
              )}{' '}
              {currentlyOpenSwitches && (
                <FsText
                  style={{ ...Styles.general.inlineSubText, color: Colors.red }}
                >
                  <MaterialIcons
                    name="lock"
                    size={Icons.size.small}
                    color={Colors.red}
                  />
                  {open_switches}
                </FsText>
              )}
            </FsText>
          </View>
          {userData.role_id === USER_ROLES.Flagmen &&
            !isSameAsLoggedIn &&
            isOnDuty && (
              <FsButton onPress={onReminderPress}>
                <MaterialCommunityIcons
                  name="cellphone-message"
                  size={Icons.size.xbig}
                  color={Colors.warning}
                />
              </FsButton>
            )}
          {!isSameAsLoggedIn && (
            <FsButton
              onPress={() => {
                try {
                  onPressCall(name, phone);
                } catch (err) {}
              }}
            >
              <FontAwesome5
                name={'phone'}
                size={Icons.size.small}
                color={hasValidPhone ? Colors.green : Colors.redDark}
              />
            </FsButton>
          )}

          <MaterialCommunityIcons
            name="chevron-right"
            size={Icons.size.xbig}
            color={Colors.primary}
          />
        </View>
      </FsButton>
    </View>
  );
};

// Exports
export default OrganizationScreen;
