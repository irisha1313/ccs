import React, { Component } from 'react';
import { View, Linking, FlatList } from 'react-native';
import { Container, Spinner } from 'native-base';
import { NavigationActions } from 'react-navigation';
import {
  FontAwesome,
  FontAwesome5,
  MaterialIcons,
  Ionicons,
} from '@expo/vector-icons';
import _ from 'lodash';
import moment from 'moment-timezone';
import { connect } from 'react-redux';
import haversine from 'haversine';

import { Colors, Fonts, Icons, Styles, GeoLocations } from '../../constants';
import {
  FsButtonActionIcon,
  FsText,
  FsButton,
  ScrollableScreen,
  FsAlert,
} from '../../components/CustomComponents';
import FlagEntry from '../../components/FlagEntry';
import FormBEntry from '../../components/FormBEntry';
import {
  toggleFlagEstablishment,
  pairFlags,
  unpairFlags,
} from '../../actions/flags';
import {
  getFlagIcon,
  formBIsActive,
  timeUntilFormbOpening,
} from '../../sharedMethods/flags';
import { navigateToCoords } from '../../sharedMethods/location';
import {
  verifyLocationPermissions,
  getCurrentPosition,
} from '../../sharedMethods/location';
import { onPressCall } from '../../sharedMethods/users';
import { Screen } from '../../components';
import { getFlagType } from '../../sharedMethods/flags';
import { USER_ROLES } from '../../utils/userRoles';
// import ConfirmFlagByQrCode from '../../components/ConfirmFlagByQrCode';

class FlagDetailsScreen extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      description: '',
      formb: null,
      currentFlag: null,
      flags: null,
      isScanningQRCode: false,
    };
  }

  componentDidMount() {
    this.initializeData();
  }

  componentDidUpdate() {
    const { formbsData } = this.props;
    const currentFormbData = formbsData.find(
      ({ id }) => id === this.state.currentFlag.protection_id
    );
    if (!currentFormbData) return;
    const currentFlagData = currentFormbData.items.find(
      ({ id }) => id === this.state.currentFlag.id
    );
    if (!currentFlagData) return;

    if (!_.isEqual(currentFlagData, this.state.currentFlag)) {
      this.setState({ currentFlag: currentFlagData });
    }
  }

  onPressDirections = async () => {
    navigateToCoords(this.state.currentFlag);
  }

  canEdit = () => {
    const { role_id, id } = this.props.userData;
    const { created_by } = this.state.formb;

    if (role_id === USER_ROLES.Flagmen) {
      if (created_by === id) {
        return true;
      }
      return false;
    }
    return true;
  };

  render() {
    if (this.state.loading) {
      return (
        <Container
          style={{
            alignItems: 'center',
            flex: 1,
            justifyContent: 'center',
          }}
        >
          <Spinner color={Colors.secondary} />
        </Container>
      );
    }

    const { isDerail, isFormB, isSwitchLocks } = getFlagType(
      this.state.currentFlag
    );

    return (
      <Screen
        title={
          isDerail && this.state.currentFlag.type !== 'red'
            ? `SN ${this.state.currentFlag.serial_number}`
            : isFormB || (isDerail && this.state.currentFlag.type === 'red')
              ? `Flag @ MP ${this.state.currentFlag.mile_post}`
              : `${this.state.currentFlag.mile_post} - ${this.state.currentFlag.serial_number}`
        }
      >
        {/* {this.state.isScanningQRCode && (
          <ConfirmFlagByQrCode
            onConfirm={this.handleConfirmByQRCode}
            onCancel={() => this.setState({ isScanningQRCode: false })}
          />
        )} */}
        <ScrollableScreen
          containerStyle={[{ paddingTop: 0 }, { paddingBottom: 240 }]}
          refreshing={this.state.loading}
          onRefresh={this.initializeData}
        >
          <FormBEntry
            formB={this.state.formb}
            flags={this.state.formb.items}
            hideFlags={true}
            hiddenOptions={['delete', 'edit', 'jobBriefing']}
            currentUserData={this.props.userData}
          />
          <View
            style={[
              {
                flexDirection: 'row',
                justifyContent: 'space-evenly',
                alignItems: 'center',
              },
              { marginHorizontal: 8 },
              { paddingTop: 40 },
              { paddingBottom: 56 },
              { borderLeftWidth: 1, borderRightWidth: 1, borderBottomWidth: 1 },
              { borderColor: Colors.divider },
              { borderBottomRightRadius: Styles.constant.BorderRadius },
              { borderBottomLeftRadius: Styles.constant.BorderRadius },
              { backgroundColor: Colors.CardBackground },
            ]}
          >
            <View style={[{ alignItems: 'center' }]}>
              {isFormB ||
                (isDerail && this.state.currentFlag.type === 'red') ? (
                <FontAwesome
                  name={'flag'}
                  size={48}
                  color={getFlagIcon(this.state.currentFlag.type)}
                />
              ) : isSwitchLocks ? (
                <FontAwesome
                  name={'lock'}
                  size={48}
                  color={getFlagIcon(this.state.currentFlag.type)}
                />
              ) : null}
              <FsText
                style={[
                  {
                    fontSize:
                      isDerail && this.state.currentFlag.type !== 'red'
                        ? Fonts.size.xxxbig
                        : Fonts.size.small,
                    color: isDerail
                      ? getFlagIcon(this.state.currentFlag.type)
                      : 'black',
                  },
                  { fontWeight: 'bold' },
                ]}
              >
                {this.state.currentFlag.type.toUpperCase()}
              </FsText>
              <FsText
                style={[{ fontSize: Fonts.size.small }, { fontWeight: 'bold' }]}
              >
                {isDerail && this.state.currentFlag.type !== 'red'
                  ? `SN ${this.state.currentFlag.serial_number}`
                  : isFormB ||
                    (isDerail && this.state.currentFlag.type === 'red')
                    ? `Flag @ MP ${this.state.currentFlag.mile_post}`
                    : `${this.state.currentFlag.mile_post} - ${this.state.currentFlag.serial_number}`}
              </FsText>
              <FsText
                style={[
                  { fontSize: Fonts.size.small },
                  {
                    color: this.state.currentFlag.is_established
                      ? Colors.red
                      : Colors.textSecondary,
                  },
                  {
                    fontWeight: this.state.currentFlag.is_established
                      ? 'bold'
                      : 'normal',
                  },
                ]}
              >
                {this.state.currentFlag.is_established ? 'Open' : 'Closed'}
              </FsText>
            </View>

            <View>
              {this.canEdit() && (
                <FsButtonActionIcon
                  title={this.getOpenActionTitle(
                    this.state.currentFlag,
                    isDerail || isSwitchLocks
                  )}
                  onPress={this.onPressMap}
                  renderIcon={(color) => (
                    <MaterialIcons
                      name={
                        _.isNil(this.state.currentFlag.established_gps_lat)
                          ? 'gps-fixed'
                          : 'swap-vert'
                      }
                      color={color}
                      size={Icons.size.normal}
                    />
                  )}
                />
              )}

              <FsButtonActionIcon
                title="DIRECTIONS"
                style={{ marginTop: 16 }}
                onPress={this.onPressDirections}
                renderIcon={(color) => (
                  <MaterialIcons
                    name="directions"
                    color={color}
                    size={Icons.size.normal}
                  />
                )}
              />
            </View>
          </View>
          {this.canEdit() && !isSwitchLocks && (
            <PairedFlags
              customVerbiage={
                this.props.currentOrganization.settings.form_verbiage
              }
              availableFlags={
                this.state.flags && this.state.currentFlag
                  ? this.state.flags.filter(
                    (flag) => flag.id !== this.state.currentFlag.id
                  )
                  : []
              }
              currentFlag={this.state.currentFlag}
              pairedFlags={this.state.currentFlag.paired}
              pairFlags={async (sourceFlag, targetFlag) => {
                this.setState({ loading: true });
                await this.props.pairFlags({
                  sourceFlag,
                  targetFlag,
                  orgId: this.props.currentOrganization.settings.id,
                });
                this.setState({ loading: false });
              }}
              unpairFlags={async (sourceFlag, targetFlag) => {
                this.setState({ loading: true });
                await this.props.unpairFlags({
                  sourceFlag,
                  targetFlag,
                  orgId: this.props.currentOrganization.settings.id,
                });
                this.setState({ loading: false });
              }}
            />
          )}
          {!_.isNil(this.state.currentFlag.disestablished_at) && (
            <DetailEntry
              action="Last Closed"
              date={this.state.currentFlag.disestablished_at}
              userId={this.state.currentFlag.disestablishedBy.id}
              userName={this.state.currentFlag.disestablishedBy.name}
              userPhone={this.state.currentFlag.disestablishedBy.phone}
              currentUserData={this.props.userData}
              onPressCall={onPressCall}
            />
          )}
          {!_.isNil(this.state.currentFlag.established_at) && (
            <DetailEntry
              action="Last Open"
              date={this.state.currentFlag.established_at}
              userId={this.state.currentFlag.establishedBy.id}
              userName={this.state.currentFlag.establishedBy.name}
              userPhone={this.state.currentFlag.establishedBy.phone}
              currentUserData={this.props.userData}
              onPressCall={onPressCall}
            />
          )}
          {!_.isNil(this.state.currentFlag.set_at) && (
            <DetailEntry
              action="Set"
              date={this.state.currentFlag.set_at}
              userId={this.state.currentFlag.setBy.id}
              userName={this.state.currentFlag.setBy.name}
              userPhone={this.state.currentFlag.setBy.phone}
              currentUserData={this.props.userData}
              onPressCall={onPressCall}
            />
          )}
          <DetailEntry
            action="Created"
            date={this.state.currentFlag.originally_created_at}
            userId={this.state.currentFlag.originallyCreatedBy.id}
            userName={this.state.currentFlag.originallyCreatedBy.name}
            userPhone={this.state.currentFlag.originallyCreatedBy.phone}
            currentUserData={this.props.userData}
            onPressCall={onPressCall}
          />
        </ScrollableScreen>
      </Screen>
    );
  }

  handleFlagToggling = async () => {
    const { isDerail, isFormB } = getFlagType(this.state.currentFlag);
    const currentPosition = await getCurrentPosition();
    const userCoords = {
      latitude: currentPosition.coords.latitude,
      longitude: currentPosition.coords.longitude,
    };
    const flagCoords = {
      latitude: this.state.currentFlag.established_gps_lat,
      longitude: this.state.currentFlag.established_gps_long,
    };
    const distanceBetweenUserAndFlag = haversine(userCoords, flagCoords, {
      unit: 'mile',
    });
    const isFormbActive = formBIsActive(this.state.formb);
    const timeForOpening = timeUntilFormbOpening(this.state.formb);
    const has24HoursTagAndIsBeingClosed =
      this.state.formb.tags.length > 0
        ? this.state.formb.tags.map(({ name }) => name).includes('24 hours') &&
        this.state.currentFlag.is_established
        : false;
    const numberOfOpenFlags = this.state.flags.filter(
      (flag) => flag.is_established
    ).length;
    if (!isFormbActive && !this.state.currentFlag.is_established) {
      FsAlert.alertOk(
        `Inactive ${this.props.currentOrganization.settings.form_verbiage}`,
        `Please check your active days of the week. You cannot open a flag on an inactive day. Edit your ${this.props.currentOrganization.settings.form_verbiage} and try again.`
      );
    } else if (
      distanceBetweenUserAndFlag > GeoLocations.MAX_DISTANCE_THRESHOLD &&
      this.props.userData.role_id === USER_ROLES.Flagmen &&
      !has24HoursTagAndIsBeingClosed // FLAG-366
    ) {
      try {
        await FsAlert.alertOptions(
          `Too Far Away`,
          `You have to be within ${GeoLocations.MAX_DISTANCE_THRESHOLD
          } miles of your ${isDerail ? 'derail' : isFormB ? 'flag' : 'switch-lock'
          } and you are ${distanceBetweenUserAndFlag.toFixed(
            2
          )} miles away. Press continue to manually update your location.`,
          ['Continue']
        );
        this.props.navigateToLocationVerification(
          this.state.currentFlag,
          this.state.flags
        );
      } catch (error) { }
    } else if (
      !this.state.currentFlag.is_established &&
      this.state.currentFlag.type === 'red' &&
      !_.isNil(timeForOpening) &&
      timeForOpening !== 0 &&
      this.props.userData.role_id === USER_ROLES.Flagmen &&
      this.props.currentOrganization.settings.id !== 7 && // FLAG-349
      this.props.currentOrganization.settings.id !== 10 && // FLAG-341
      this.props.currentOrganization.settings.id !== 12 // Chad request on July 23rd
    ) {
      FsAlert.alertOk(
        `Your ${this.props.currentOrganization.settings.form_verbiage} is not yet active`,
        `Please wait ${timeForOpening} before opening a red flag.`
      );
    } else if (
      this.state.currentFlag.is_established &&
      this.state.currentFlag.type === 'yellow-red' &&
      this.state.currentFlag.paired &&
      this.state.currentFlag.paired.find(
        (pairedFlag) => pairedFlag.type === 'red' && pairedFlag.is_established
      )
    ) {
      FsAlert.alertOk(
        'Paired Red Flag Still Open',
        'Please make sure you close all of the red flags associated to this one before trying to close it..'
      );
    } else if (
      !this.state.currentFlag.is_established &&
      this.state.currentFlag.type === 'red' &&
      this.state.currentFlag.paired &&
      this.state.currentFlag.paired.find(
        (pairedFlag) =>
          pairedFlag.type === 'yellow-red' && !pairedFlag.is_established
      )
    ) {
      FsAlert.alertOk(
        'Paired Flags Inactive',
        'Please make sure all your paired yellow-red are open before opening this flag.'
      );
    } else if (
      !this.state.currentFlag.is_established &&
      this.state.currentFlag.type === 'red' &&
      this.state.currentFlag.paired &&
      this.state.currentFlag.paired.find(
        (pairedFlag) =>
          (pairedFlag.type === 'lh' && !pairedFlag.is_established) ||
          (pairedFlag.type === 'rh' && !pairedFlag.is_established)
      )
    ) {
      FsAlert.alertOk(
        'Paired Flags Inactive',
        'Please make sure all your paired derails are open before opening this flag.'
      );
    } else if (
      this.state.currentFlag.is_established &&
      numberOfOpenFlags === 1 &&
      this.props.currentOrganization.settings.debrief_with_dispatch
    ) {
      try {
        await FsAlert.alertYesCancel(
          'Methods Removal Verification',
          `Have all applicable methods of protection (flags, derails, lock switches) been removed from the property and all persons and equipment clear for the night?`,
          'Yes',
          'No'
        );
        const toggledFlag = await this.props.toggleFlag(
          this.state.currentFlag,
          this.props.userData.id,
          this.props.currentOrganization.settings.id
        );
        this.setState({ currentFlag: toggledFlag });
      } catch (err) { }
    } else {
      const toggledFlag = await this.props.toggleFlag(
        this.state.currentFlag,
        this.props.userData.id,
        this.props.currentOrganization.settings.id
      );
      this.setState({ currentFlag: toggledFlag });
    }
    return;
  };

  // handleConfirmByQRCode = (flagIdFromQrCode) => {
  //   this.setState({ isScanningQRCode: false });
  //   const flag = this.state.currentFlag;
  //   if (flag.item_qr && Number(flagIdFromQrCode) !== Number(flag.item_qr)) {
  //     FsAlert.alertOk(
  //       "Invalid Flag",
  //       "The QR code you scanned does not match the flag you are trying to open/close."
  //     );
  //     return;
  //   }

  //   requestAnimationFrame(() => {
  //     this.toggleFlag();
  //   });
  // };

  onPressMap = async () => {
    const { isDerail, isFormB, isSwitchLocks } = getFlagType(
      this.state.currentFlag
    );
    const title = _.isNil(this.state.currentFlag.established_gps_lat)
      ? `${`Set ${isFormB ? 'Flag' : isDerail ? 'Derail' : 'Switch'}`}`
      : this.state.currentFlag.is_established
        ? `${isFormB ? 'Close Flag' : isDerail ? 'Close Derail' : 'Turn Switch Off'
        }`
        : `${!isFormB ? `Turn ${isDerail ? 'Derail' : 'Switch'} On` : 'Open Flag'
        }`;
    const description = _.isNil(this.state.currentFlag.established_gps_lat)
      ? `You are about to set this ${isDerail ? "derail's" : isFormB ? "flag's" : "switch's"
      } location. This cannot be changed. Are you sure?`
      : `Are you sure that you want to ${this.state.currentFlag.is_established && isDerail && isSwitchLocks
        ? 'turn off'
        : this.state.currentFlag.is_established &&
          !isDerail &&
          !isSwitchLocks
          ? 'close'
          : !this.state.currentFlag.is_established &&
            isDerail &&
            isSwitchLocks
            ? 'turn on'
            : 'open'
      } this ${isDerail ? 'derail' : isFormB ? 'flag' : 'switch'}?`;

    try {
      await FsAlert.alertYesCancel(title, description, 'Yes', 'No');
    } catch (error) {
      this.setState({ loading: false });
      return;
    }

    // QR-CODE
    // const isFlagmen = this.props.userData?.role_id === USER_ROLES.Flagmen;
    // const flag = this.state.currentFlag;
    // if (isFlagmen && !_.isNil(flag.established_gps_lat) && flag.item_qr) {
    //   this.setState({ isScanningQRCode: true });
    // } else {
    //   this.toggleFlag();
    // }
    this.toggleFlag();
  };

  toggleFlag = async () => {
    this.setState({ loading: true });

    if (_.isNil(this.state.currentFlag.established_gps_lat)) {
      this.props.establishFlag(this.state.currentFlag);
    } else {
      const locationGranted = await verifyLocationPermissions(
        Linking,
        this.props.navigation
      );
      if (locationGranted) {
        await this.handleFlagToggling();
      }
    }

    this.setState({ loading: false });
  }

  getOpenActionTitle = (flag, displayOnOff) => {
    {
      this.state.currentFlag.is_established
        ? displayOnOff
        : 'ON'
          ? 'OPEN'
          : displayOnOff
            ? 'OFF'
            : 'CLOSE';
    }
    if (_.isNil(flag.established_gps_lat)) return 'SET LOCATION';
    else if (!flag.is_established && !displayOnOff) return 'OPEN';
    else if (!flag.is_established && displayOnOff) return 'TURN ON';
    else if (flag.is_established && !displayOnOff) return 'CLOSE';
    return 'TURN OFF';
  };

  goBack = () => {
    this.props.navigation.goBack();
  };

  initializeData = async () => {
    const formB = this.props.navigation.getParam('formB');
    const currentFlag = this.props.navigation.getParam('currentFlag');
    const flags = this.props.navigation.getParam('flags');
    this.setState({
      formb: formB,
      currentFlag,
      flags,
      loading: false,
    });
  };
}

const PairedFlags = (props) => {
  const {
    availableFlags,
    currentFlag,
    pairedFlags,
    pairFlags,
    unpairFlags,
    customVerbiage,
  } = props;

  const handlePairToggling = async (
    selectedFlag,
    isFlaggedPairedWithCurrentOne
  ) => {
    if (isFlaggedPairedWithCurrentOne) {
      unpairFlags(currentFlag, selectedFlag);
    } else {
      pairFlags(currentFlag, selectedFlag);
    }
  };

  return (
    <View style={{ paddingHorizontal: 7 }}>
      <FsText
        style={{
          marginTop: 24,
          marginBottom: 12,
          alignItems: 'center',
          textAlign: 'center',
          fontSize: Fonts.size.xbig,
          color: Colors.primaryLight,
        }}
      >
        Paired Flags
      </FsText>
      {availableFlags.length > 0 ? (
        <FlatList
          data={availableFlags}
          listKey={moment().valueOf().toString()}
          keyExtractor={(item) => Math.random().toString(36).slice(-5)}
          scrollEnabled={false}
          showsVerticalScrollIndicator={false}
          renderItem={(rowData) => {
            const flag = rowData.item;
            const isFlaggedPairedWithCurrentOne =
              pairedFlags &&
              pairedFlags.find((pairedFlag) => pairedFlag.id === flag.id);
            return (
              <FlagEntry
                onPress={() =>
                  handlePairToggling(flag, isFlaggedPairedWithCurrentOne)
                }
                showDirections={false}
                flag={flag}
                canEdit={false}
                additionalIcon={
                  isFlaggedPairedWithCurrentOne ? (
                    <Ionicons
                      onPress={() =>
                        handlePairToggling(flag, isFlaggedPairedWithCurrentOne)
                      }
                      name="ios-checkbox"
                      color={Colors.primary}
                      size={Icons.size.normal + 2}
                      style={{ paddingRight: 30 }}
                    />
                  ) : (
                    <FontAwesome
                      onPress={() =>
                        handlePairToggling(flag, isFlaggedPairedWithCurrentOne)
                      }
                      name="square-o"
                      color={Colors.primary}
                      size={Icons.size.normal + 2}
                      style={{ paddingRight: 30 }}
                    />
                  )
                }
              />
            );
          }}
          ItemSeparatorComponent={() => (
            <View
              style={{ borderBottomWidth: 1, borderColor: Colors.divider }}
            ></View>
          )}
          style={[
            {
              backgroundColor: Colors.CardBackground,
              borderWidth: 1,
              borderColor: Colors.divider,
            },
          ]}
        />
      ) : (
        <FsText
          style={{
            marginTop: 0,
            marginBottom: 12,
            alignItems: 'center',
            textAlign: 'center',
            fontSize: Fonts.size.big,
            color: Colors.primaryLight,
          }}
        >
          There are no flags to pair this flag with. Please add more flags to
          this {customVerbiage} and try again.
        </FsText>
      )}
    </View>
  );
};

const DetailEntry = (props) => {
  const {
    action,
    date,
    userId,
    userName,
    userPhone,
    currentUserData,
    onPressCall,
  } = props;

  const detailCreatedByLoggedInUser = userId === currentUserData.id;
  return (
    <View
      style={[
        { paddingVertical: 24 },
        { borderBottomColor: Colors.secondaryLight },
        { marginHorizontal: 8 },
        { borderBottomWidth: 1 },
      ]}
    >
      <View style={[{ flexDirection: 'row', alignItems: 'center' }]}>
        <View style={[{ flex: 1 }]}>
          <FsText>
            <FsText
              style={{
                fontSize: Fonts.size.normal,
                color: Colors.textSecondary,
              }}
            >
              {action.toUpperCase()}
            </FsText>
            {'  '}
            {moment(date).format('ddd MMM D @ HH:mm')}
          </FsText>

          <FsText>
            <FsText
              style={{
                fontSize: Fonts.size.normal,
                color: Colors.textSecondary,
              }}
            >
              BY
            </FsText>
            {'  '}
            {detailCreatedByLoggedInUser ? 'Me' : userName}
          </FsText>
        </View>
        {!detailCreatedByLoggedInUser && (
          <FsButton
            onPress={() => {
              try {
                onPressCall(userName, userPhone);
              } catch (err) { }
            }}
          >
            <FontAwesome5
              name={'phone'}
              size={Icons.size.small}
              color={Colors.accent}
            />
          </FsButton>
        )}
      </View>
    </View>
  );
};

const mapStateToProps = (state) => {
  return {
    userData: state.auth.user,
    currentOrganization: state.organizations.currentOrganization,
    formbsData: state.formbs.data,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    toggleFlag: (flag, userId, orgId) =>
      dispatch(toggleFlagEstablishment(flag, userId, orgId)),
    establishFlag: (flag) =>
      dispatch(
        NavigationActions.navigate({
          routeName: 'EstablishFlagMapScreen',
          params: { flag },
        })
      ),
    navigateToLocationVerification: (flag, flags) =>
      dispatch(
        NavigationActions.navigate({
          routeName: 'FlagLocationVerificationScreen',
          params: { flag, flags },
        })
      ),
    pairFlags: (payload) => dispatch(pairFlags(payload)),
    unpairFlags: (payload) => dispatch(unpairFlags(payload)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(FlagDetailsScreen);
