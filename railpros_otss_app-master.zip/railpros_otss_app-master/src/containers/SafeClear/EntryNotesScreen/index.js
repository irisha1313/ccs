import React, { useState } from 'react';
import { View } from 'native-base';
import { FAB } from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { NavigationActions } from 'react-navigation';

import { Colors, Fonts } from '../../../constants';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
} from '../../../components/CustomComponents';
import { createNote } from '../../../actions/SafeClear/currentLog';
import Screen from '../../../components/Screen';
import Note from '../../../components/SafeClear/Note';
import NewNote from '../../../components/SafeClear/NewNote';

const EntryNotesScreen = (props) => {
  const notes = props.navigation.getParam('notes');
  const entryId = props.navigation.getParam('entryId');
  const submitted = props.navigation.getParam('submitted');

  const [addingNote, setAddingNote] = useState(false);
  const [newNote, setNewNote] = useState('');

  const dispatch = useDispatch();

  const handleFabAction = async () => {
    if (addingNote) {
      try {
        await FsAlert.alertYesCancel(
          'Add Note',
          'Are you sure you want to add this note?'
        );
        dispatch(createNote({ entryId, note: newNote }));
        dispatch(NavigationActions.back());
      } catch (error) {}
    } else {
      setAddingNote(true);
    }
  };

  return (
    <Screen title="Notes" lockToLandscape>
      <ScrollableScreen>
        <View>
          {notes.map(({ id, note, created_at }) => (
            <Note key={id} createdAt={created_at} note={note} />
          ))}
          {!notes.length ? (
            <FsText
              style={{
                paddingTop: 50,
                color: Colors.textGrey,
                fontSize: Fonts.size.big,
                textAlign: 'center',
                fontWeight: 'bold',
              }}
            >
              No notes to display.
            </FsText>
          ) : null}
        </View>
        {addingNote ? (
          <NewNote
            placeholder="Tap here to begin typing a note."
            value={newNote}
            onChange={setNewNote}
          />
        ) : null}
      </ScrollableScreen>
      {!submitted ? (
        <View style={{ position: 'absolute', bottom: 0, right: 0 }}>
          <FAB
            style={{
              backgroundColor: Colors.secondary,
              marginHorizontal: 20,
              marginBottom: 15,
            }}
            icon={addingNote ? 'check' : 'plus'}
            onPress={handleFabAction}
          />
        </View>
      ) : null}
    </Screen>
  );
};

export default EntryNotesScreen;
