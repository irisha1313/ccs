import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { View } from 'react-native';
import { Dropdown } from 'react-native-material-dropdown-v2';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { Appearance } from 'react-native';
import { TouchableOpacity } from 'react-native';
import moment from 'moment-timezone';

import InputWithLabel from './InputWithLabel';
import TimeAndTimezonePicker from '../../../../components/TimeAndTimezonePicker';
import NewNote from '../../../../components/SafeClear/NewNote';
import {
  FsText,
  FsInputWithLabel,
} from '../../../../components/CustomComponents';
import { getFormbIdsByUserIdSync } from '../../../../actions/formbs';
import { Colors, Styles, Fonts } from '../../../../constants';
import { Formats } from '../../../../constants/SafeClear';
import { useIsOnline } from '../../../../context/netStateContext';

const CreateLogForm = ({ log, onChange }) => {
  const {
    protection_id,
    date,
    start_time,
    timezone,
    end_time,
    authorized_time,
    jobNumber,
    dispatcher,
    from_north_milepost,
    to_south_milepost,
    notes,
  } = log;

  const isOnline = useIsOnline();

  const { safeClearUserData } = useSelector((state) => ({
    safeClearUserData: state.safeClear.user,
  }));

  const [datePickerCurrentVisibility, setDatePickerVisibility] =
    useState(false);
  const [protectionIds, setProtectionIds] = useState([]);

  const getProtectionIds = async () => {
    const protectionIds = await getFormbIdsByUserIdSync(safeClearUserData.id);
    const formattedProtectionIds = protectionIds.map((id) => ({
      value: id,
    }));
    setProtectionIds(formattedProtectionIds);
  };

  const toggleDatePicker = () =>
    setDatePickerVisibility(!datePickerCurrentVisibility);

  useEffect(() => {
    if (isOnline) {
      // getting fresh data for the following
      getProtectionIds();
    }
  }, []);

  const theme = Appearance.getColorScheme();

  return (
    <View>
      {!isOnline ? (
        <InputWithLabel
          name="protection_id"
          label="PROTECTION ID"
          value={`${protection_id}`}
          keyboardType="number-pad"
          onChange={onChange}
        />
      ) : (
        <View
          style={{
            paddingHorizontal: 8,
          }}
        >
          <Dropdown
            disabled={!protectionIds.length}
            labelFontSize={0}
            style={{
              fontFamily: Styles.constant.FontFamily,
              color: Colors.black,
              marginTop: 0,
              backgroundColor: 'transparent',
            }}
            containerStyle={{
              width: '100%',
              alignSelf: 'center',
            }}
            value={protection_id}
            fontSize={Fonts.size.small}
            data={protectionIds}
            onChangeText={(newValue) => onChange('protection_id', newValue)}
          />
          <FsText
            style={{
              fontSize: Fonts.size.xxsmall,
              color: Colors.textSecondary,
            }}
          >
            PROTECTION ID
          </FsText>
        </View>
      )}
      <TouchableOpacity onPress={toggleDatePicker}>
        <FsInputWithLabel
          label="SELECTED DATE"
          editable={false}
          pointerEvents="none"
          containerStyle={{ marginTop: 24 }}
          value={moment(date, Formats.receivedDateFormat).format(
            Formats.displayDateFormat
          )}
        />
      </TouchableOpacity>
      <TimeAndTimezonePicker
        title="START TIME (HH:MM)"
        value={start_time}
        valueName="start_time"
        timezone={timezone}
        onChange={onChange}
      />
      <TimeAndTimezonePicker
        title="END TIME (HH:MM)"
        value={end_time}
        valueName="end_time"
        timezone={timezone}
        onChange={onChange}
      />
      <InputWithLabel
        name="authorized_time"
        label="Authorized Time"
        value={authorized_time}
        onChange={onChange}
      />
      <InputWithLabel
        name="jobNumber"
        label="Job Number"
        value={jobNumber}
        onChange={onChange}
      />
      <InputWithLabel
        name="dispatcher"
        label="Dispatcher"
        value={dispatcher}
        onChange={onChange}
      />
      <InputWithLabel
        name="from_north_milepost"
        label="From North Milepost"
        value={from_north_milepost}
        onChange={onChange}
      />
      <InputWithLabel
        name="to_south_milepost"
        label="To South Milepost"
        value={to_south_milepost}
        onChange={onChange}
      />
      <DateTimePickerModal
        isDarkModeEnabled={theme === 'dark'}
        isVisible={datePickerCurrentVisibility}
        mode="date"
        onConfirm={(selectedDate) => {
          onChange(
            'date',
            moment(selectedDate).format(Formats.receivedDateFormat)
          );
          toggleDatePicker();
        }}
        onCancel={toggleDatePicker}
      />
      <NewNote
        placeholder="Tap here to begin typing a note."
        value={notes}
        onChange={(newValue) => onChange('notes', newValue)}
      />
    </View>
  );
};

export default CreateLogForm;
