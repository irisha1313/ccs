import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { View, Fab, Spinner } from 'native-base';
import { NavigationActions } from 'react-navigation';
import moment from 'moment-timezone';
import omit from 'lodash/omit';

import CreateLogForm from './components/form';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
} from '../../../components/CustomComponents';
import { createLog, updateLog } from '../../../actions/SafeClear/logs';
import Screen from '../../../components/Screen';
import { Icons, Colors, Fonts } from '../../../constants';
import { Formats } from '../../../constants/SafeClear';

const CreateLogScreen = (props) => {
  const receivedLog = props.navigation.getParam('log');

  const [protection_id, setProtectionId] = useState(
    receivedLog ? receivedLog.protection_id : ''
  );
  const [date, setPhone] = useState(
    receivedLog ? receivedLog.date : moment().format(Formats.receivedDateFormat)
  );
  const [start_time, setStartTime] = useState(
    receivedLog ? receivedLog.start_time : ''
  );
  const [end_time, setEndTime] = useState(
    receivedLog ? receivedLog.end_time : ''
  );
  const [timezone, setTimezone] = useState(
    receivedLog ? receivedLog.timezone : moment.tz.guess()
  );
  const [authorized_time, setAuthorizedTime] = useState(
    receivedLog ? receivedLog.authorized_time : ''
  );
  const [jobNumber, setJobNumber] = useState(
    receivedLog ? receivedLog.job_number : ''
  );
  const [dispatcher, setDispatcher] = useState(
    receivedLog ? receivedLog.dispatcher : ''
  );
  const [from_north_milepost, setfrom_north_milepost] = useState(
    receivedLog ? receivedLog.from_north_milepost : ''
  );
  const [to_south_milepost, setto_south_milepost] = useState(
    receivedLog ? receivedLog.to_south_milepost : ''
  );

  const [notes, setNotes] = useState(receivedLog ? receivedLog.notes : '');

  const currentLog = {
    id: receivedLog && receivedLog.id,
    protection_id,
    date,
    start_time,
    end_time,
    timezone,
    authorized_time,
    jobNumber,
    dispatcher,
    from_north_milepost,
    to_south_milepost,
    notes,
  };

  const { safeClearUserData, editingLog } = useSelector((state) => ({
    safeClearUserData: state.safeClear.user,
    editingLog: state.safeClear.logs.editingLog,
  }));

  const dispatch = useDispatch();

  const onChange = (stateName, newValue) => {
    switch (stateName) {
      case 'protection_id':
        setProtectionId(newValue);
        break;
      case 'date':
        setPhone(newValue);
        break;
      case 'start_time':
        setStartTime(newValue);
        break;
      case 'end_time':
        setEndTime(newValue);
        break;
      case 'timezone':
        setTimezone(newValue);
        break;
      case 'authorized_time':
        setAuthorizedTime(newValue);
        break;
      case 'jobNumber':
        setJobNumber(newValue);
        break;
      case 'dispatcher':
        setDispatcher(newValue);
        break;
      case 'from_north_milepost':
        setfrom_north_milepost(newValue);
        break;
      case 'to_south_milepost':
        setto_south_milepost(newValue);
        break;
      case 'notes':
        setNotes(newValue);
        break;
      default:
        break;
    }
  };

  const handleSaveButton = async () => {
    // we do ignore id as this one shouldn't
    // be present when creating a new log
    const optionalFields = ['id', 'jobNumber', 'notes'];
    const logMissingData = Object.values(omit(currentLog, optionalFields)).some(
      (value) => !value
    );

    if (logMissingData) {
      return FsAlert.alertOk(
        'Incomplete Log Data',
        "Please make sure you fill in all of this log's data."
      );
    }

    if (currentLog.id) {
      await dispatch(updateLog(currentLog));
    } else {
      await dispatch(
        createLog({ log: currentLog, userId: safeClearUserData.id })
      );
    }
    dispatch(NavigationActions.back());
  };

  const logIsUpdated = () => {
    return JSON.stringify(receivedLog) !== JSON.stringify(currentLog);
  };
  const displaySaveButton = (receivedLog && logIsUpdated()) || !receivedLog;

  if (editingLog) {
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );
  }

  return (
    <Screen
      title={currentLog.id ? 'Editing Log' : 'Creating Log'}
      lockToLandscape
    >
      <ScrollableScreen containerStyle={{ paddingTop: 0 }}>
        <FsText
          style={{
            color: Colors.secondary,
            fontSize: Fonts.size.xbig,
            textAlign: 'center',
            fontWeight: 'bold',
            paddingTop: 50,
          }}
        >
          General Information
        </FsText>
        <CreateLogForm log={currentLog} onChange={onChange} />
      </ScrollableScreen>
      {displaySaveButton ? (
        <Fab
          onPress={handleSaveButton}
          style={{ backgroundColor: Colors.secondary }}
        >
          <MaterialCommunityIcons
            name="check"
            size={Icons.size.big}
            color={Colors.textLight}
            style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
          />
        </Fab>
      ) : null}
    </Screen>
  );
};

export default CreateLogScreen;
