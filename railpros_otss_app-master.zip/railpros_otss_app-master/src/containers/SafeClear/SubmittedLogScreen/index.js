import React, { useEffect, useContext } from 'react';
import { NavigationContext } from 'react-navigation';
import { useDispatch, useSelector } from 'react-redux';
import { NavigationActions } from 'react-navigation';
import { View, Button } from 'native-base';
import moment from 'moment-timezone';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import { Colors, Fonts, Styles, Icons } from '../../../constants';
import { Formats } from '../../../constants/SafeClear';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
} from '../../../components/CustomComponents';
import {
  getCurrentLog,
  submitLog,
} from '../../../actions/SafeClear/currentLog';
import Screen from '../../../components/Screen';
import IndividualOptionEntry from '../../../components/IndividualOptionEntry';
import LandscapeLogEntry from '../../../components/SafeClear/LandscapeLogEntry';

const SubmittedLogScreen = (props) => {
  const logId = props.navigation.getParam('id');
  const date = props.navigation.getParam('date');
  const protection_id = props.navigation.getParam('protection_id');
  const underReview = props.navigation.getParam('underReview');

  const { currentLog, loadingCurrentLog } = useSelector((state) => ({
    currentLog: state.safeClear.currentLog.data,
    loadingCurrentLog: state.safeClear.currentLog.loading,
  }));

  const dispatch = useDispatch();

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();

  useEffect(() => {
    if (isNavigationFocus) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  const onRefresh = () => {
    dispatch(getCurrentLog({ logId, underReview }));
  };

  const LogMetaDataEntry = ({ children }) => (
    <FsText
      style={{
        color: Colors.textGrey,
        fontSize: Fonts.size.small,
        textAlign: 'left',
        fontWeight: 'bold',
        paddingTop: 20,
        paddingLeft: 15,
      }}
    >
      {children}
    </FsText>
  );

  const LogMetaData = () => (
    <View>
      <LogMetaDataEntry>
        Date: {moment.parseZone(date).format(Formats.displayDateFormat)}
      </LogMetaDataEntry>
      <LogMetaDataEntry>Timezone: {currentLog.timezone}</LogMetaDataEntry>
      <LogMetaDataEntry>Start Time: {currentLog.start_time}</LogMetaDataEntry>
      <LogMetaDataEntry>End Time: {currentLog.end_time}</LogMetaDataEntry>
      <LogMetaDataEntry>
        Authorized Time: {currentLog.authorized_time}
      </LogMetaDataEntry>
      <LogMetaDataEntry>Job Number: {currentLog.job_number}</LogMetaDataEntry>
      <LogMetaDataEntry>Dispatcher: {currentLog.dispatcher}</LogMetaDataEntry>
      <LogMetaDataEntry>
        From North Milepost: {currentLog.from_north_milepost}
      </LogMetaDataEntry>
      <LogMetaDataEntry>
        To South Milepost: {currentLog.to_south_milepost}
      </LogMetaDataEntry>
      <LogMetaDataEntry>Notes: {currentLog.notes}</LogMetaDataEntry>
    </View>
  );

  const handleLogSubmission = async () => {
    await FsAlert.alertYesCancel(
      'Submit Log',
      `Are you sure you want to save this log?`
    );
    await submitLog(currentLog.id);
    await dispatch(getCurrentLog({ logId })).unwrap();
    dispatch(
      NavigationActions.navigate({
        routeName: 'SafeClearHomeScreen',
      })
    );
  };

  return (
    <Screen
      title={`Protection ${protection_id}`}
      headerActionButton={
        underReview ? (
          <Button
            onPress={handleLogSubmission}
            style={{ ...Styles.general.headerButton }}
          >
            <FsText style={{ color: Colors.textLight }}>Submit</FsText>
            <MaterialCommunityIcons
              name="chevron-right"
              size={Icons.size.normal}
              color={Colors.textLight}
              style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
            />
          </Button>
        ) : null
      }
      lockToLandscape
    >
      <ScrollableScreen
        containerStyle={{ paddingTop: 0 }}
        refreshing={loadingCurrentLog}
        onRefresh={onRefresh}
      >
        <FsText
          style={{
            color: Colors.secondary,
            fontSize: Fonts.size.xbig,
            textAlign: 'center',
            fontWeight: 'bold',
            paddingTop: 25,
          }}
        >
          General Information
        </FsText>
        <LogMetaData />
        <View style={{ paddingTop: 25 }}>
          <FsText
            style={{
              color: Colors.secondary,
              fontSize: Fonts.size.xbig,
              textAlign: 'center',
              fontWeight: 'bold',
              paddingBottom: 10,
            }}
          >
            Members
          </FsText>
          {currentLog.signedOut.map((user) => (
            <IndividualOptionEntry
              key={user.id}
              value={`${user.name} - MP: ${user.milepost}`}
              onPress={() =>
                dispatch(
                  NavigationActions.navigate({
                    routeName: 'SafeClearSubmittedUserStatusScreen',
                    params: { user },
                  })
                )
              }
            />
          ))}
          {!currentLog.signedOut.length && !loadingCurrentLog ? (
            <FsText
              style={{
                color: Colors.textGrey,
                fontSize: Fonts.size.big,
                textAlign: 'center',
                fontWeight: 'bold',
              }}
            >
              No members to display.
            </FsText>
          ) : null}
        </View>
        <View style={{ paddingTop: 25 }}>
          <FsText
            style={{
              color: Colors.secondary,
              fontSize: Fonts.size.xbig,
              textAlign: 'center',
              fontWeight: 'bold',
              paddingTop: 25,
              paddingBottom: 10,
            }}
          >
            Entries
          </FsText>
          {currentLog.entries?.map((entry) => (
            <LandscapeLogEntry
              key={entry.id}
              entry={entry}
              formBId={currentLog.protection_id}
              submitted
            />
          ))}
          {!currentLog.entries?.length && !loadingCurrentLog ? (
            <FsText
              style={{
                color: Colors.textGrey,
                fontSize: Fonts.size.big,
                textAlign: 'center',
                fontWeight: 'bold',
              }}
            >
              No entries to display.
            </FsText>
          ) : null}
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

export default SubmittedLogScreen;
