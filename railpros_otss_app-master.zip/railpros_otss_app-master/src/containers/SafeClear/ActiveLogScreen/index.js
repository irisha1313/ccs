import React, { useEffect, useContext } from 'react';
import { NavigationActions, NavigationContext } from 'react-navigation';
import { Button } from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import { MaterialCommunityIcons, MaterialIcons } from '@expo/vector-icons';

import { Colors, Styles, Icons } from '../../../constants';
import {
  ScrollableScreen,
  FsAlert,
  FsText,
} from '../../../components/CustomComponents';
import { getCurrentLog } from '../../../actions/SafeClear/currentLog';
import Screen from '../../../components/Screen';
import LandscapeUserStatus from './components/LandscapeUserStatus';
import LandscapeEntries from './components/LandscapeEntries';

const ActiveLogScreen = (props) => {
  const logId = props.navigation.getParam('id');

  const { currentLog, loadingCurrentLog } = useSelector((state) => ({
    currentLog: state.safeClear.currentLog.data,
    loadingCurrentLog: state.safeClear.currentLog.loading,
  }));

  const dispatch = useDispatch();

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();

  useEffect(() => {
    if (isNavigationFocus && currentLog.id !== logId) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  const onRefresh = () => {
    dispatch(getCurrentLog({ logId }));
  };

  const logCanBeSubmitted =
    !currentLog.signedIn?.length &&
    !currentLog.excepted?.length &&
    currentLog.entries?.length;

  const handleLogReview = async () => {
    const errorTitle = "Can't review log";
    if (!currentLog.entries.length) {
      return FsAlert.alertOk(
        errorTitle,
        "Please make sure to add at least one entry before attempting to review this log's submission."
      );
    } else if (!logCanBeSubmitted) {
      return FsAlert.alertOk(
        errorTitle,
        "Please make sure to sign everybody out before attempting to review this log's submission."
      );
    }

    try {
      dispatch(
        NavigationActions.navigate({
          routeName: 'SafeClearSubmittedLogScreen',
          params: {
            id: currentLog.id,
            date: currentLog.date,
            protection_id: currentLog.protection_id,
            underReview: true,
          },
        })
      );
    } catch (e) {}
  };

  const handleEditLog = () => {
    dispatch(
      NavigationActions.navigate({
        routeName: 'SafeClearCreateLogScreen',
        params: { log: currentLog },
      })
    );
  };

  const renderLandscapeTopBarButtons = () => {
    const submitButtonColor = !logCanBeSubmitted
      ? Colors.textGrey
      : Colors.textLight;
    return (
      <>
        <Button
          onPress={handleEditLog}
          style={[{ ...Styles.general.headerButton }, { marginLeft: -95 }]}
        >
          <FsText style={{ color: Colors.textLight }}>Edit</FsText>
          <MaterialIcons
            name="edit"
            size={Icons.size.normal}
            color={Colors.textLight}
            style={{
              top: 1,
              maxWidth: 24,
              textAlign: 'center',
              paddingLeft: 5,
            }}
          />
        </Button>
        <Button
          onPress={handleLogReview}
          style={{ ...Styles.general.headerButton }}
        >
          <FsText style={{ color: submitButtonColor }}>Review</FsText>
          <MaterialCommunityIcons
            name="chevron-right"
            size={Icons.size.normal}
            color={submitButtonColor}
            style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
          />
        </Button>
      </>
    );
  };

  return (
    <Screen
      title={`SafeClear RPFS ${logId}, MP ${
        currentLog.from_north_milepost || ''
      }-${currentLog.to_south_milepost || ''}, ${currentLog.start_time || ''}-${
        currentLog.end_time || ''
      }`}
      headerActionButton={renderLandscapeTopBarButtons()}
      style={{ backgroundColor: Colors.backgroundColor }}
      titlePaddingRight={80}
      lockToLandscape
    >
      <ScrollableScreen
        containerStyle={{ paddingTop: 0 }}
        refreshing={loadingCurrentLog}
        onRefresh={onRefresh}
      >
        <LandscapeUserStatus />
        <LandscapeEntries />
      </ScrollableScreen>
    </Screen>
  );
};

export default ActiveLogScreen;
