import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { View, Fab, Spinner } from 'native-base';
import { NavigationActions } from 'react-navigation';

import CreateUserForm from './form';
import {
  ScrollableScreen,
  FsAlert,
} from '../../../components/CustomComponents';
import { createUser, updateUser } from '../../../actions/SafeClear/currentLog';
import Screen from '../../../components/Screen';
import { Icons, Colors } from '../../../constants';

const CreateUserScreen = (props) => {
  const user = props.navigation.getParam('user');

  const [name, setName] = useState(user ? user.name : '');
  const [phone, setPhone] = useState(user ? user.phone : '');
  const [milepost, setMilepost] = useState(user ? user.milepost : '');
  const [creatingNewUser, setCreatingNewUser] = useState(false);

  const { currentLog } = useSelector((state) => ({
    currentLog: state.safeClear.currentLog.data,
  }));

  const dispatch = useDispatch();

  const onChange = (stateName, newValue) => {
    switch (stateName) {
      case 'name':
        setName(newValue);
        break;
      case 'phone':
        setPhone(newValue);
        break;
      case 'milepost':
        setMilepost(newValue);
        break;
      default:
        break;
    }
  };

  const handleSaveButton = async () => {
    if (!name || !phone) {
      return FsAlert.alertOk(
        'Missing fields data',
        'Please fill in all fields before proceeding to perform this action.'
      );
    }

    const newUserProperties = { name, phone, milepost };

    setCreatingNewUser(true);

    if (user) {
      await dispatch(
        updateUser({ id: user.id, data: { ...user, ...newUserProperties } })
      );
    } else {
      await dispatch(
        createUser({ user: newUserProperties, logId: currentLog.id })
      );
    }
    dispatch(NavigationActions.back());
  };

  const userIsUpdated = () =>
    user.name !== name || user.phone !== phone || user.milepost !== milepost;
  const displaySaveButton = (user && userIsUpdated()) || !user;

  if (currentLog.loadingUser) {
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );
  }

  return (
    <Screen title={user ? 'Editing POC' : 'New POC'} lockToLandscape>
      <ScrollableScreen containerStyle={{ paddingTop: 50 }}>
        <CreateUserForm
          name={name}
          phone={phone}
          milepost={milepost}
          onChange={onChange}
        />
      </ScrollableScreen>
      {displaySaveButton ? (
        <Fab
          disabled={creatingNewUser}
          onPress={handleSaveButton}
          style={{
            backgroundColor: creatingNewUser
              ? Colors.textGrey
              : Colors.secondary,
          }}
        >
          <MaterialCommunityIcons
            name="check"
            size={Icons.size.big}
            color={Colors.textLight}
            style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
          />
        </Fab>
      ) : null}
    </Screen>
  );
};

export default CreateUserScreen;
