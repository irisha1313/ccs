import React from 'react';
import { View } from 'react-native';

import { FsInputWithLabel } from '../../../components/CustomComponents';
import { formatPhoneNumber } from '../../../sharedMethods/users';

const CreateUserForm = ({ name, phone, milepost, onChange }) => {
  return (
    <View>
      <FsInputWithLabel
        name="name"
        label="NAME"
        selectTextOnFocus={true}
        containerStyle={{ marginTop: 24 }}
        returnKeyType="next"
        autoCapitalize="words"
        onChangeText={(newValue) => onChange('name', newValue)}
        value={name}
        placeholder={name || ''}
      />
      <FsInputWithLabel
        name="phone"
        label="PHONE"
        keyboardType={Platform.select({
          ios: 'numbers-and-punctuation',
          android: 'default',
        })}
        selectTextOnFocus={true}
        returnKeyType="next"
        containerStyle={[{ marginTop: 24 }]}
        onChangeText={(newValue) => {
          onChange('phone', formatPhoneNumber(newValue));
        }}
        value={phone}
        placeholder={phone ? phone : '() ___-____'}
      />
      <FsInputWithLabel
        name="milepost"
        label="MILEPOST"
        selectTextOnFocus={true}
        containerStyle={{ marginTop: 24 }}
        returnKeyType="next"
        autoCapitalize="words"
        onChangeText={(newValue) => onChange('milepost', newValue)}
        value={milepost}
        placeholder={milepost || ''}
      />
    </View>
  );
};

export default CreateUserForm;
