import React from 'react';
import { View } from 'native-base';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment-timezone';
import omit from 'lodash/omit';

import { Colors, Fonts } from '../../../constants';
import { User } from '../../../constants/SafeClear';
import { Formats } from '../../../constants/SafeClear';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
} from '../../../components/CustomComponents';
import Screen from '../../../components/Screen';
import IndividualOptionEntry from '../../../components/IndividualOptionEntry';
import { manageUserStatusUpdate } from '../../../sharedMethods/SafeClear/users';

const UserStatusScreen = (props) => {
  const status = props.navigation.getParam('status');

  const { currentLog, updatingUserStatus } = useSelector((state) => ({
    currentLog: state.safeClear.currentLog.data,
    updatingUserStatus: state.safeClear.currentLog.updatingUserStatus,
  }));

  const statusAttributeName = Object.values(User.statusMap).find(
    (value) => value.title === status
  ).attributeName;

  const usersInStatus = currentLog[statusAttributeName];

  const dispatch = useDispatch();

  const getUserOptions = () => {
    const remainingStatuses = omit(User.statusMap, statusAttributeName);
    return Object.values(remainingStatuses).map(
      (remainingStatusData) => remainingStatusData.verb
    );
  };

  const handleUserClick = async (user) => {
    const userOptions = getUserOptions();
    try {
      const selectedOption = await FsAlert.alertOptionsCancel(
        `Manage ${user.name}`,
        '',
        [...userOptions, User.removeOption]
      );

      await dispatch(
        manageUserStatusUpdate(
          selectedOption,
          user,
          currentLog.id,
          statusAttributeName
        )
      );
    } catch (error) {}
  };

  return (
    <Screen title={status} lockToLandscape>
      <ScrollableScreen
        containerStyle={{ paddingTop: 0 }}
        refreshing={updatingUserStatus}
      >
        <FsText
          style={{
            color: Colors.secondary,
            fontSize: Fonts.size.xbig,
            textAlign: 'center',
            fontWeight: 'bold',
            paddingTop: 50,
          }}
        >
          RPFS: {id} - Protection: {currentLog.protection_id}
        </FsText>
        <View style={{ paddingTop: 50 }}>
          {usersInStatus.map((user) => (
            <IndividualOptionEntry
              key={user.id}
              value={`${user.name} - MP ${user.milepost}`}
              onPress={() => {
                handleUserClick(user);
              }}
            />
          ))}
          {!usersInStatus.length ? (
            <FsText
              style={{
                color: Colors.textGrey,
                fontSize: Fonts.size.big,
                textAlign: 'center',
                fontWeight: 'bold',
              }}
            >
              No users to display.
            </FsText>
          ) : null}
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

export default UserStatusScreen;
