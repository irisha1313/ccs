import React, { useState, useEffect, useContext, useRef } from 'react';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { NavigationActions, NavigationContext } from 'react-navigation';
import { View, Spinner } from 'native-base';
import { FAB } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import { Appearance } from 'react-native';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment-timezone';

import { Colors, Icons, Fonts } from '../../../constants';
import { ActionTypes, Formats } from '../../../constants/SafeClear';
import { ScrollableScreen, FsText } from '../../../components/CustomComponents';
import { getLogsByUserId } from '../../../actions/SafeClear/logs';
import Screen from '../../../components/Screen';
import IndividualOptionEntry from '../../../components/IndividualOptionEntry';
import { useIsOnline } from '../../../context/netStateContext';

const SafeClearScreen = (props) => {
  const isOnline = useIsOnline();
  const [date, setDate] = useState(moment().format(Formats.receivedDateFormat));
  const [datePickerCurrentVisibility, setDatePickerVisibility] =
    useState(false);

  let previousDateRef = useRef(date);

  const dispatch = useDispatch();
  const { loggedUserData, safeClearUserData, logs, logsLoading, offline } =
    useSelector((state) => ({
      loggedUserData: state.auth.user,
      safeClearUserData: state.safeClear.user,
      logs: state.safeClear.logs,
      logsLoading: state.safeClear.logs.loading,
      offline: state.offline,
    }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();

  useEffect(() => {
    if (isNavigationFocus && isOnline) {
      onRefresh();
    }
  }, [isNavigationFocus, isOnline]);

  useEffect(() => {
    if (previousDateRef.current !== date) {
      getLogsForUser(safeClearUserData.id);
      previousDateRef.current = date;
    }
  }, [date]);

  const onRefresh = () => {
    getCurrentUserData();
  };

  const getCurrentUserData = () => {
    const userData = props.navigation.getParam('userData') || loggedUserData;

    dispatch({
      type: ActionTypes.SETUSERDATA,
      userData,
    });

    getLogsForUser(userData.id);
  };

  const getLogsForUser = (userId) => {
    dispatch(getLogsByUserId({ userId, date }));
  };

  const toggleDatePicker = () =>
    setDatePickerVisibility(!datePickerCurrentVisibility);
  const theme = Appearance.getColorScheme();

  const handleFabAction = () => {
    dispatch(
      NavigationActions.navigate({
        routeName: 'SafeClearCreateLogScreen',
      })
    );
  };

  if (!safeClearUserData) {
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );
  }

  const LogEntry = ({ id, date, protection_id, prepend, submitted }) => (
    <IndividualOptionEntry
      value={`${moment
        .parseZone(date)
        .format(
          Formats.displayDateFormat
        )} - RPFS: ${id} - Protection: ${protection_id}`}
      prepend={prepend}
      onPress={() => {
        dispatch(
          NavigationActions.navigate({
            routeName: submitted
              ? 'SafeClearSubmittedLogScreen'
              : 'SafeClearActiveLogScreen',
            params: { id, date, protection_id },
          })
        );
      }}
    />
  );

  const unsubmittedLogsValue = logs.unsubmitted.length
    ? logs.unsubmitted.map(({ id, date, protection_id }) => (
        <LogEntry
          id={id}
          key={id}
          prepend={
            <MaterialCommunityIcons
              name="record"
              size={Icons.size.normal}
              color={Colors.red}
            />
          }
          date={moment.parseZone(date).format(Formats.displayDateFormat)}
          protection_id={protection_id}
        />
      ))
    : null;

  const submittedLogsValue = logs.submitted.length ? (
    logs.submitted.map(({ id, date, protection_id }) => (
      <LogEntry
        id={id}
        key={id}
        date={date}
        protection_id={protection_id}
        submitted
      />
    ))
  ) : !logsLoading ? (
    <FsText
      style={{
        color: Colors.textGrey,
        fontSize: Fonts.size.big,
        textAlign: 'center',
        fontWeight: 'bold',
      }}
    >
      No submitted logs to display.
    </FsText>
  ) : null;

  return (
    <Screen title={safeClearUserData.user_name} lockToLandscape>
      <ScrollableScreen
        containerStyle={{ paddingTop: 0 }}
        refreshing={logsLoading}
        onRefresh={onRefresh}
      >
        {unsubmittedLogsValue}
        <FsText
          style={{
            color: Colors.secondary,
            fontSize: Fonts.size.xbig,
            textAlign: 'center',
            fontWeight: 'bold',
            paddingTop: 50,
          }}
        >
          Logs
        </FsText>
        <FsText
          onPress={toggleDatePicker}
          style={{
            color: Colors.secondaryTextGrey,
            fontSize: Fonts.size.big,
            textDecorationLine: 'underline',
            paddingTop: 30,
            paddingRight: 20,
            textAlign: 'right',
            fontWeight: 'bold',
          }}
        >
          <MaterialCommunityIcons
            name="calendar"
            size={Icons.size.normal}
            color={Colors.secondaryTextGrey}
          />
          {moment(date, Formats.receivedDateFormat).format(
            Formats.displayDateFormat
          )}
        </FsText>
        <View style={{ paddingTop: 50 }}>{submittedLogsValue}</View>
      </ScrollableScreen>
      <View style={{ position: 'absolute', bottom: 0, right: 0 }}>
        <FAB
          style={{
            backgroundColor: Colors.secondary,
            marginHorizontal: 20,
            marginBottom: 15,
          }}
          icon="plus"
          onPress={handleFabAction}
        />
      </View>
      <DateTimePickerModal
        isDarkModeEnabled={theme === 'dark'}
        isVisible={datePickerCurrentVisibility}
        mode="date"
        onConfirm={(selectedDate) => {
          setDate(moment(selectedDate).format(Formats.receivedDateFormat));
          toggleDatePicker();
        }}
        onCancel={toggleDatePicker}
      />
    </Screen>
  );
};

export default SafeClearScreen;
