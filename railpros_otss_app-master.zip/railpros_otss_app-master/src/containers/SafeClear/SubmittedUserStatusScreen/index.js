import React, { useState, useEffect } from 'react';
import { useSelector } from 'react-redux';
import { View } from 'native-base';
import { Col, Row, Grid } from 'react-native-easy-grid';
import moment from 'moment-timezone';
import isEqual from 'lodash/isEqual';

import { Colors, Fonts } from '../../../constants';
import { Formats } from '../../../constants/SafeClear';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
} from '../../../components/CustomComponents';
import Screen from '../../../components/Screen';
import { getStatsForUser } from '../../../actions/SafeClear/users';
import { useIsOnline } from '../../../context/netStateContext';

const SubmittedUserStatusScreen = (props) => {
  const user = props.navigation.getParam('user');
  const isOnline = useIsOnline();

  const { id, name, milepost } = user;

  const defaultUserLogs = {
    signedIn: [],
    signedOut: [],
    excepted: [],
    removed: undefined,
  };

  const [userLogs, setUserLogs] = useState({
    signedIn: [],
    signedOut: [],
    excepted: [],
    removed: undefined,
  });

  const { currentLog, loadingCurrentLog, offlinePOCsStatus } = useSelector(
    (state) => ({
      currentLog: state.safeClear.currentLog.data,
      loadingCurrentLog: state.safeClear.currentLog.loading,
      offlinePOCsStatus: state.offline.safeClear.pocsStatus,
    })
  );

  const getUserStats = async () => {
    if (isOnline) {
      const retrievedUserLogs = await getStatsForUser(id, currentLog.id);
      setUserLogs(retrievedUserLogs);
    } else if (id && currentLog.id) {
      const filteredOfflinePOCsStatus = offlinePOCsStatus.filter(
        ({ poc_id, log_id }) => poc_id === id && log_id === currentLog.id
      );

      if (filteredOfflinePOCsStatus.length) {
        const offlineUserLogs = {
          ...defaultUserLogs,
        };

        offlineUserLogs.signedIn = filteredOfflinePOCsStatus
          .filter(({ status }) => status === 'signedIn')
          .map(({ created_at }) => created_at);
        offlineUserLogs.signedOut = filteredOfflinePOCsStatus
          .filter(({ status }) => status === 'signedOut')
          .map(({ created_at }) => created_at);
        offlineUserLogs.excepted = filteredOfflinePOCsStatus.filter(
          ({ status }) => status === 'excepted'
        );

        setUserLogs(offlineUserLogs);
      }
    }
  };

  useEffect(() => {
    getUserStats();
  }, []);

  const HeaderCell = ({ children }) => (
    <Row style={{ height: 25 }}>
      <FsText
        style={{
          color: Colors.textGrey,
          fontWeight: 'bold',
        }}
      >
        {children}
      </FsText>
    </Row>
  );

  const Cell = ({ children, ...props }) => (
    <Row style={{ height: 20 }}>
      <FsText {...props}>{children}</FsText>
    </Row>
  );

  const formatTimeCell = (timestamp) =>
    currentLog?.timezone
      ? moment(timestamp)
          .tz(currentLog.timezone)
          .format(Formats.displayHourFormat)
      : '';

  return (
    <Screen title={name} lockToLandscape>
      <ScrollableScreen>
        <View>
          <FsText
            style={{
              color: Colors.secondary,
              fontSize: Fonts.size.xbig,
              textAlign: 'center',
              fontWeight: 'bold',
              paddingBottom: 25,
            }}
          >
            MP: {milepost}
          </FsText>
          {!loadingCurrentLog && userLogs.removed ? (
            <FsText
              style={{
                color: Colors.textGrey,
                fontSize: Fonts.size.small,
                textAlign: 'left',
                fontWeight: 'bold',
                paddingBottom: 20,
                paddingLeft: 25,
              }}
            >
              Removed at: {formatTimeCell(userLogs.removed)}
            </FsText>
          ) : null}
          <Grid>
            <Col
              style={{
                alignItems: 'center',
                borderRightWidth: 1,
                borderRightColor: Colors.grey,
              }}
            >
              <HeaderCell>IN</HeaderCell>
              {!loadingCurrentLog &&
                userLogs.signedIn.map((createdAtUTC) => (
                  <Cell style={{ color: 'green' }}>
                    {formatTimeCell(createdAtUTC)}
                  </Cell>
                ))}
            </Col>

            <Col style={{ alignItems: 'center' }}>
              <HeaderCell>OUT</HeaderCell>
              {!loadingCurrentLog &&
                userLogs.signedOut.map((createdAtUTC) => (
                  <Cell style={{ color: 'red' }}>
                    {formatTimeCell(createdAtUTC)}
                  </Cell>
                ))}
            </Col>

            <Col
              style={{
                alignItems: 'center',
                borderLeftWidth: 1,
                borderLeftColor: Colors.grey,
              }}
            >
              <HeaderCell>EXCEPTED</HeaderCell>
              {!loadingCurrentLog &&
                userLogs.excepted.map(({ created_at, reason }) => (
                  <Cell
                    style={
                      reason && {
                        color: 'blue',
                        textDecorationLine: 'underline',
                      }
                    }
                    onPress={() => {
                      if (reason) {
                        FsAlert.alertOk('Reason', reason);
                      }
                    }}
                  >
                    {formatTimeCell(created_at)}
                  </Cell>
                ))}
            </Col>
          </Grid>
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

export default SubmittedUserStatusScreen;
