import React, { useState, useEffect } from 'react';
import { View, Platform } from 'react-native';
import { Fab, Spinner } from 'native-base';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import _ from 'lodash';
import { useSelector } from 'react-redux';
import moment from 'moment-timezone';
import Constants from 'expo-constants';
import * as Device from 'expo-device';
import NetInfo from '@react-native-community/netinfo';
import { Dropdown } from 'react-native-material-dropdown-v2';

import { Colors, Icons, Styles, Fonts } from '../../constants';
import {
  ScrollableScreen,
  FsInputWithLabel,
  FsText,
  FsAlert,
} from '../../components/CustomComponents';
import { Screen } from '../../components';
import UploadImages from '../../components/UploadImages';
import LoadingModal from '../../components/LoadingModal';
import { uploadBugReportImages, sendBugReport } from '../../actions/bugReports';

const ReportBugScreen = ({ navigation }) => {
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userPhone, setUserPhone] = useState('');
  const [bugDescription, setBugDescription] = useState('');
  const [bugCategory, setBugCategory] = useState('Other');
  const [images, setImages] = useState([]);
  const { userData, location, organization } = useSelector(
    ({ auth, location, organizations }) => ({
      location,
      userData: auth.user,
      organization: organizations.currentOrganization,
    })
  );

  const [networkData, setNetworkData] = useState(null);
  const [sendingReport, setSendingReport] = useState(false);
  const [reportUploadingStatus, setReportUploadingStatus] = useState(
    'Initializing Upload'
  );
  const [reportUploadingProgress, setReportUploadingProgress] =
    useState('indeterminate');

  const deviceData = {
    isDevice: Device.isDevice,
    brand: Device.brand,
    manufacturer: Device.manufacturer,
    modelName: Device.modelName,
    modelId: Device.modelId,
    designName: Device.designName,
    productName: Device.productName,
    deviceYearClass: Device.deviceYearClass,
    totalMemory: Device.totalMemory,
    supportedCpuArchitectures: Device.supportedCpuArchitectures,
    osName: Device.osName,
    osVersion: Device.osVersion,
    osBuildId: Device.osBuildId,
    osInternalBuildId: Device.osInternalBuildId,
    deviceName: Device.deviceName,
  };

  const initialize = async () => {
    if (userData) {
      if (userData.name) setUserName(userData.name);
      if (userData.email) setUserEmail(userData.email);
      if (userData.phone) setUserPhone(userData.phone);
    }
    setLoading(false);
  };

  useEffect(() => {
    initialize();

    const getNetInfoListener = NetInfo.addEventListener(
      (fetchedNetworkData) => {
        setNetworkData(fetchedNetworkData);
      }
    );

    return () => {
      getNetInfoListener();
    };
  }, []);

  const handleOnSave = async () => {
    if (!canSave) {
      return FsAlert.alertOk(
        'Missing Data',
        'Please make sure to fill in your personal and bug description data properly'
      );
    } else {
      setSendingReport(true);
      setReportUploadingProgress(0);
      const createdAtUTC = moment().utc();

      const path = `bugReports/${createdAtUTC.year()}/${createdAtUTC.format(
        'MMMM'
      )}/${createdAtUTC.date()}/${createdAtUTC.format('HH:mm')}/`;

      let imagesURLs = [];

      if (images.length > 0) {
        setReportUploadingProgress(0.3);
        setReportUploadingStatus('Uploading Report Images');
        imagesURLs = await uploadBugReportImages(images, path);
      }
      setReportUploadingProgress(0.5);
      setReportUploadingStatus('Sending Bug Report');

      sendBugReport({
        imagesURLs,
        userData: {
          ...(organization?.settings && {
            orgName: organization.settings.name,
            orgId: organization.settings.id,
          }),
          ..._.omit(userData, ['password', 'jwt']),
          name: userName,
          email: userEmail,
          phone: userPhone,
        },
        appData: {
          location,
          version: Constants.expoConfig.version,
          bugDescription,
          bugCategory,
        },
        deviceData,
        networkData,
      });
      setReportUploadingProgress(1);
      setReportUploadingStatus('Report Sent');
      setTimeout(navigation.goBack, 1000);
    }
  };

  const containersStyle = { marginTop: 10 };

  if (loading) {
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );
  }

  if (sendingReport) {
    return (
      <LoadingModal
        visible
        progress={reportUploadingProgress}
        status={reportUploadingStatus}
      />
    );
  }

  const bugCategories = [
    {
      value: 'Location Issue (setting)',
    },
    {
      value: 'Location Issue (opening)',
    },
    {
      value: 'Location Issue (closing)',
    },
    {
      value: 'Other',
    },
  ];

  const canSave =
    userName.trim() !== '' &&
    userEmail.trim() !== '' &&
    bugDescription.trim() !== '';
  return (
    <Screen onBackPress={() => navigation.goBack()} title="Bug Report">
      <ScrollableScreen containerStyle={{ paddingTop: 0, paddingBottom: 240 }}>
        <View
          style={{
            marginHorizontal: 8,
            marginVertical: 10,
            borderRadius: Styles.constant.BorderRadius,
          }}
        >
          <FsInputWithLabel
            name="userName"
            label="Full Name"
            returnKeyType="next"
            autoCapitalize="words"
            onChangeText={setUserName}
            value={userName}
            placeholder="eg. John Deer"
          />
          <FsInputWithLabel
            containerStyle={containersStyle}
            name="userEmail"
            label="Email"
            returnKeyType="next"
            autoCapitalize="none"
            onChangeText={setUserEmail}
            value={userEmail}
            placeholder="eg. john.deer@railpros.com"
          />
          <FsInputWithLabel
            containerStyle={containersStyle}
            name="userPhone"
            label="Phone Number"
            returnKeyType="next"
            autoCapitalize="words"
            keyboardType={Platform.select({
              ios: 'numbers-and-punctuation',
              android: 'default',
            })}
            onChangeText={setUserPhone}
            value={userPhone}
            placeholder="eg. (123) 345-5678"
          />
          <Dropdown
            label="Category"
            fontSize={Fonts.size.normal}
            style={{
              fontFamily: Styles.constant.FontFamily,
              color: Colors.text,
              backgroundColor: 'transparent',
            }}
            containerStyle={{
              paddingHorizontal: 9,
              marginTop: 3,
            }}
            value={bugCategory}
            fontSize={Fonts.size.normal}
            data={bugCategories}
            onChangeText={setBugCategory}
          />
          <FsInputWithLabel
            containerStyle={containersStyle}
            name="description"
            label="Description"
            returnKeyType="next"
            onChangeText={setBugDescription}
            value={bugDescription}
            placeholder="A brief description of the bug you encountered"
          />
          <UploadImages onImagesUpdate={setImages} currentImages={images} />
        </View>
      </ScrollableScreen>
      <Fab
        onPress={handleOnSave}
        style={{
          backgroundColor: !canSave ? Colors.secondaryDark : Colors.secondary,
        }}
      >
        <MaterialCommunityIcons
          name={'check'}
          size={Icons.size.big}
          style={{ top: 1, maxWidth: 24, textAlign: 'center' }}
        />
      </Fab>
    </Screen>
  );
};

export default ReportBugScreen;
