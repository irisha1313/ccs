import React, { useState, useEffect, useContext } from 'react';
import { FlatList, Linking } from 'react-native';
import _ from 'lodash';
import {
  MaterialCommunityIcons,
  FontAwesome,
  MaterialIcons,
  FontAwesome5,
} from '@expo/vector-icons';
import { NavigationActions, NavigationContext } from 'react-navigation';
import { Spinner, View, Button } from 'native-base';
import { FAB } from 'react-native-paper';
import { useDispatch, useSelector } from 'react-redux';
import moment from 'moment-timezone';

import { Colors, Icons, Styles, Fonts } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsAlert,
  FsButton,
  FsButtonActionIcon,
} from '../../components/CustomComponents';
import { getFormbs } from '../../actions/formbs';
import { deleteUser } from '../../actions/user';
import { getOrganizationDataById } from '../../actions/organizations';
import { setLocation } from '../../actions/location';
import FormBEntry from '../../components/FormBEntry';
import Screen from '../../components/Screen';
import { onPressCall, onSendEmail } from '../../sharedMethods/users';
import Certificates from '../../components/Certificates';
import LoadingModal from '../../components/LoadingModal';
import {
  verifyLocationPermissions,
  getCurrentPosition,
} from '../../../src/sharedMethods/location';
import { USER_ROLES } from '../../utils/userRoles';

const FormBsScreen = (props) => {
  const [currentUserData, setCurrentUserData] = useState({});
  const [isReloadingLocation, setIsReloadingLocation] = useState(false);

  const dispatch = useDispatch();
  const {
    userData,
    formBsData,
    currentOrganizationSettings,
    currentOrganizationFlagmen,
  } = useSelector((state) => ({
    userData: state.auth.user,
    formBsData: state.formbs.data,
    currentOrganizationSettings:
      state.organizations.currentOrganization.settings,
    currentOrganizationFlagmen: state.organizations.currentOrganization.flagmen,
  }));

  const navigation = useContext(NavigationContext);
  const isNavigationFocus = navigation.isFocused();
  // on mount actions
  useEffect(() => {
    if (isNavigationFocus) {
      onRefresh();
    }
  }, [isNavigationFocus]);

  // on mount actions
  useEffect(() => {
    onRefresh();
  }, []);

  useEffect(() => {
    verifyCurrentUserIntegrity();
  }, [currentOrganizationFlagmen]);

  const verifyCurrentUserIntegrity = async () => {
    if (!_.isNil(currentUserData) && currentUserData.id) {
      const newPossibleFlagmanObject = currentOrganizationFlagmen.find(
        (flagman) => flagman.id === currentUserData.id
      );
      if (
        newPossibleFlagmanObject &&
        !_.isEqual(
          currentUserData.certificates,
          newPossibleFlagmanObject.certificates
        )
      ) {
        setCurrentUserData(newPossibleFlagmanObject);
      }
    }
  };

  const onRefresh = async () => {
    if (!_.isNil(currentOrganizationSettings.id)) {
      await dispatch(getOrganizationDataById(currentOrganizationSettings.id));
      await getFormBsForUserId();
    }
  };

  const getFormBsForUserId = async () => {
    const currentUserData =
      props.navigation.getParam('currentUserData') || userData;
    setCurrentUserData(currentUserData);
    dispatch(getFormbs({ user: currentUserData.id }));
  };

  const loggedUserIsCurrentUser = currentUserData.id === userData.id;
  const creationPermission =
    loggedUserIsCurrentUser || userData.role_id !== USER_ROLES.Flagmen;

  const FlagmanInformation = () => {
    const isValidPhoneNumber =
      !_.isNil(currentUserData.phone) && currentUserData.phone.trim() !== '';
    return (
      <View
        style={{
          flex: 1,
          paddingHorizontal: 10,
          paddingTop: 20,
          flexDirection: 'row',
          justifyContent: 'space-evenly',
        }}
      >
        <FsText style={{ color: Colors.secondaryLight, fontWeight: 'bold' }}>
          <FontAwesome
            name={'envelope'}
            size={Icons.size.small}
            color={Colors.accent}
          />
          {': '}
          <FsText
            style={{
              color: Colors.secondaryLight,
              fontWeight: 'normal',
              textDecorationColor: Colors.secondaryLight,
            }}
            onPress={() =>
              onSendEmail(currentUserData.name, currentUserData.email)
            }
          >
            {currentUserData.email}
          </FsText>
        </FsText>
        <FsText style={{ color: Colors.secondaryLight, fontWeight: 'bold' }}>
          <FontAwesome
            name={'phone'}
            size={Icons.size.small}
            color={Colors.accent}
          />
          {': '}
          <FsText
            style={{
              color: Colors.secondaryLight,
              fontWeight: 'normal',
              textDecorationColor: Colors.secondaryLight,
            }}
            onPress={() =>
              onPressCall(currentUserData.name, currentUserData.phone)
            }
          >
            {isValidPhoneNumber ? currentUserData.phone : 'N/A'}
          </FsText>
        </FsText>
      </View>
    );
  };

  const handleUserSettingsPress = async () => {
    try {
      const selectedOption = await FsAlert.alertOptionsCancel(
        `Manage ${currentUserData.name}`,
        'Select an action',
        ['Transfer', 'Delete']
      );
      if (selectedOption === 'Transfer') {
        dispatch(
          NavigationActions.navigate({
            routeName: 'UserOrgTransfer',
            params: { currentUser: currentUserData },
          })
        );
      } else {
        await FsAlert.alertYesCancel(
          'Deleting User',
          `Are you sure about deleting ${currentUserData.name}?`
        );
        dispatch(deleteUser(currentUserData.id, userData.org_id));
        dispatch(NavigationActions.back());
      }
    } catch (error) {}
  };

  const handleUserIncidentReportPress = async () =>
    dispatch(
      NavigationActions.navigate({
        routeName: 'SendIncidentReportScreen',
        params: { currentUser: currentUserData },
      })
    );

  const handleManualLocationSync = async () => {
    const permissionStatus = await verifyLocationPermissions(Linking);
    if (permissionStatus !== 'granted') {
      return;
    }

    setIsReloadingLocation(true);
    const currentLocation = await getCurrentPosition('BestForNavigation');

    // making sure users wait forr at least 3 seconds before
    // closing the location reloading modal
    setTimeout(async () => {
      await dispatch(setLocation(currentLocation.coords));
      setIsReloadingLocation(false);
    }, 3000);
  };

  if (!formBsData)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  const formBsForUser = formBsData
    .filter((formb) => formb.created_by === currentUserData.id)
    .sort((a, b) => {
      if (a && b) return a.id > b.id;
      return false;
    });

  const activeFormBs = formBsForUser
    .filter(({ isActive }) => isActive)
    .sort((a, b) => {
      if (a && b) return a.id > b.id;
      return false;
    });

  const inactiveFormBs = formBsForUser
    .filter(
      (formBForUser) =>
        !activeFormBs.find((activeFormB) => activeFormB.id === formBForUser.id)
    )
    .sort((a, b) => {
      if (a && b) return b.openFlags > a.openFlags && a.id > b.id;
      return false;
    });

  const filteredFormBs = [...activeFormBs, ...inactiveFormBs];

  const managersWithAccessToSafeClear = [
    'jeremy.holloway@railpros.com',
    'john.thomas@railpros.com',
    'michael.harvey@railpros.com',
    'jason.rowland@railpros.com',
    'joe.kelly@railpros.com',
    'sean.quigley@railpros.com',
    'alex@materializelabs.com',
    'alex.nordlinger@railpros.com',
    'christopher.oslin@railpros.com',
    'seniorvp@example.com',
  ];

  const isAbleToAccessSafeClearAsManager =
    managersWithAccessToSafeClear.includes(userData.email.toLowerCase()) &&
    (currentOrganizationSettings.id === 10 ||
      currentOrganizationSettings.id === 13) &&
    !loggedUserIsCurrentUser &&
    currentUserData.role_id === USER_ROLES.Flagmen;

  const usersWithSelfAccessToSafeClear = [
    'hflans@gmail.com',
    'travis.ford@railpros.com',
    'brian.mazur@railpros.com',
    'robert.grapes@railpros.com',
    'michael.grether@railpros.com',
  ];

  const isAbleToAccessSafeClearAsFlagman =
    usersWithSelfAccessToSafeClear.includes(userData.email.toLowerCase());

  const isAbleToAccessSafeClear =
    isAbleToAccessSafeClearAsFlagman || isAbleToAccessSafeClearAsManager;

  return (
    <Screen
      title={loggedUserIsCurrentUser ? 'My Protections' : currentUserData.name}
      headerActionButton={
        userData.role_id !== USER_ROLES.Flagmen &&
        !loggedUserIsCurrentUser && (
          <>
            <Button
              onPress={handleUserIncidentReportPress}
              style={{ ...Styles.general.headerButton }}
            >
              <MaterialCommunityIcons
                name="air-filter"
                size={Icons.size.normal}
                color={Colors.textLight}
                style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
              />
            </Button>
            <Button
              onPress={handleUserSettingsPress}
              style={{ ...Styles.general.headerButton }}
            >
              <MaterialIcons
                name="settings"
                size={Icons.size.normal}
                color={Colors.textLight}
                style={[{ top: 1 }, { maxWidth: 24 }, { textAlign: 'center' }]}
              />
            </Button>
          </>
        )
      }
    >
      <ScrollableScreen
        containerStyle={[{ paddingTop: 0 }]}
        refreshing={!formBsData}
        onRefresh={onRefresh}
      >
        {!loggedUserIsCurrentUser &&
        currentUserData.role_id === USER_ROLES.Flagmen ? (
          <FlagmanInformation />
        ) : null}
        {isAbleToAccessSafeClear ? (
          <View
            style={{
              display: 'flex',
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              marginHorizontal: 12,
            }}
          >
            <FsButtonActionIcon
              title="SafeClear"
              style={{
                display: 'flex',
                flex: 6,
                alignItems: 'center',
                alignContent: 'center',
                paddingRight: 3,
                marginVertical: 10,
                borderRadius: 10,
                backgroundColor: Colors.secondary,
              }}
              onPress={() =>
                dispatch(
                  NavigationActions.navigate({
                    routeName: 'SafeClearHomeScreen',
                    params: { userData: currentUserData },
                  })
                )
              }
              renderIcon={(color) => (
                <FontAwesome5
                  name="train"
                  color={color}
                  size={Icons.size.normal}
                />
              )}
            />
          </View>
        ) : null}
        {currentUserData.role_id === USER_ROLES.Flagmen ? (
          <Certificates
            currentUserData={currentUserData}
            currentOrganizationId={currentOrganizationSettings.id}
            canEdit={userData.role_id !== USER_ROLES.Flagmen}
          />
        ) : null}
        <FsText
          style={{
            color: Colors.secondary,
            fontSize: Fonts.size.xbig,
            textAlign: 'center',
            fontWeight: 'bold',
          }}
        >
          Protections
        </FsText>
        {loggedUserIsCurrentUser ? (
          <View
            style={{
              display: 'flex',
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              marginHorizontal: 12,
            }}
          >
            <FsButtonActionIcon
              title="NEW JOB BRIEFING"
              style={{
                display: 'flex',
                flex: 6,
                alignItems: 'center',
                alignContent: 'center',
                paddingRight: 3,
                marginVertical: 10,
                borderRadius: 10,
                backgroundColor: Colors.secondary,
              }}
              onPress={() =>
                dispatch(
                  NavigationActions.navigate({
                    routeName: 'CreateJobBriefingScreen',
                    params: {},
                  })
                )
              }
              renderIcon={(color) => (
                <MaterialIcons
                  name="record-voice-over"
                  color={color}
                  size={Icons.size.normal}
                />
              )}
            />
          </View>
        ) : null}
        {userData.role_id !== USER_ROLES.Flagmen && (
          <FsButton
            onPress={() =>
              dispatch(
                NavigationActions.navigate({
                  routeName: 'ArchivedFormBsScreen',
                  params: { currentUserData },
                })
              )
            }
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginHorizontal: 15,
            }}
          >
            <FontAwesome
              name="archive"
              size={Icons.size.normal}
              color={Colors.primary}
              style={{ minWidth: 24, textAlign: 'center' }}
            />

            <View style={{ flex: 1 }}>
              <FsText
                style={{ marginHorizontal: 12, color: Colors.secondaryDark }}
              >
                Archived
              </FsText>
            </View>
            <MaterialCommunityIcons
              name="chevron-right"
              size={Icons.size.xbig}
              color={Colors.primary}
            />
          </FsButton>
        )}
        {filteredFormBs.length > 0 ? (
          <FlatList
            data={filteredFormBs}
            listKey={moment().valueOf().toString()}
            keyExtractor={(item) => item.id.toString()}
            scrollEnabled={false}
            showsVerticalScrollIndicator={false}
            renderItem={(rowData) => (
              <FormBEntry
                formB={rowData.item}
                flags={rowData.item.items}
                currentUserData={currentUserData}
              />
            )}
            contentContainerStyle={[
              {
                marginTop: loggedUserIsCurrentUser ? 12 : 0,
              },
            ]}
          />
        ) : (
          <FsText
            style={{
              paddingTop: 10,
              color: Colors.secondaryDark,
              fontSize: Fonts.size.small,
              textAlign: 'center',
            }}
          >
            No Protections
          </FsText>
        )}
      </ScrollableScreen>
      {creationPermission && (
        <>
          <View style={{ position: 'absolute', bottom: 0, right: 0 }}>
            <FAB
              style={{
                backgroundColor: Colors.secondary,
                marginHorizontal: 20,
                marginBottom: 15,
              }}
              icon="plus"
              onPress={() =>
                dispatch(
                  NavigationActions.navigate({
                    routeName: 'CreateFormBScreen',
                    params: { currentUserId: currentUserData.id },
                  })
                )
              }
            />
          </View>
          <View style={{ position: 'absolute', bottom: 0, left: 0 }}>
            <FAB
              style={{
                backgroundColor: Colors.secondary,
                marginHorizontal: 20,
                marginBottom: 20,
              }}
              icon="target"
              onPress={handleManualLocationSync}
            />
          </View>
        </>
      )}
      {isReloadingLocation && (
        <LoadingModal
          visible
          spinning
          continuousAnimation
          progress="indeterminate"
          status="Refreshing your current location"
          icon={
            <MaterialCommunityIcons
              name="reload"
              size={100}
              color={Colors.primary}
            />
          }
        />
      )}
    </Screen>
  );
};

// Exports
export default FormBsScreen;
