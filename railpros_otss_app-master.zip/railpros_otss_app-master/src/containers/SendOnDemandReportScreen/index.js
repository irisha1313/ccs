import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import _ from 'lodash';
import { Spinner } from 'native-base';
import { useSelector } from 'react-redux';
import moment from 'moment-timezone';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Appearance } from 'react-native';

import { Colors, Icons } from '../../constants';
import {
  ScrollableScreen,
  FsText,
  FsButtonActionIcon,
  FsInputWithLabel,
  FsAlert,
} from '../../components/CustomComponents';
import Screen from '../../components/Screen';
import { sendDailyReportOnDemand } from '../../actions/reports';

const SendOnDemandReportScreen = (props) => {
  const { currentOrganization } = useSelector((state) => ({
    currentOrganization: state.organizations.currentOrganization,
  }));
  const [loading, setLoading] = useState(false);
  const [emailTo, setEmailTo] = useState('');
  const [date, setDate] = useState(moment().format());
  const [datePickerCurrentVisibility, setDatePickerVisibility] = useState(
    false
  );

  useEffect(() => {
    if (_.isNil(currentOrganization.settings.id)) {
      props.navigation.goBack();
      FsAlert.alertOk(
        'Report',
        'You must select a property before sending a report.'
      );
    }
  }, []);

  const confirmValidateForm = async () => {
    setLoading(true);
    try {
      const inputIsInvalid = checkIfInputIsInvalid();
      if (!inputIsInvalid) {
        await FsAlert.alertYesCancel(
          'Send Daily Report',
          `This will generate a report for all activity within this organization on ${moment(
            date
          ).format(
            'MM/DD/YYYY'
          )}.\n\nThis Report will be emailed to: ${emailTo}`,
          'OK, Send Report',
          'No'
        );
        await onPressDailyReport();
        setLoading(false);
      } else {
        FsAlert.alertOk(
          'Check Email Input',
          "Please fill in the email you want to send this organization's report to."
        );
        setLoading(false);
      }
      // we aren't catching a thing within this method
      // as it is used to handle the "No" selection
      // within FsAlert.alertYesCancel
    } catch (error) {
      setLoading(false);
    }
  };

  const checkIfInputIsInvalid = () => _.isEmpty(_.trim(emailTo));

  const onPressDailyReport = async () => {
    const emailArray = emailTo.split(',');
    await sendDailyReportOnDemand(currentOrganization.settings.id, emailArray, date);
    return props.navigation.goBack();
  };

  const toggleDatePicker = () =>
    setDatePickerVisibility(!datePickerCurrentVisibility);

  const theme = Appearance.getColorScheme();

  if (loading)
    return (
      <View
        style={{
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100%',
        }}
      >
        <Spinner color={Colors.secondary} />
      </View>
    );

  return (
    <Screen title="Send EOD Report">
      <ScrollableScreen containerStyle={[{ paddingBottom: 240 }]}>
        <View style={[{ paddingHorizontal: 16 }]}>
          <FsInputWithLabel
            label={'EMAIL'}
            keyboardType="email-address"
            labelRight="Enter multiple emails by separating with commas."
            selectTextOnFocus={true}
            returnKeyType="next"
            autoCorrect={false}
            autoCapitalize="none"
            value={emailTo}
            onChangeText={(text) => {
              setEmailTo(text);
            }}
            containerStyle={[{ marginTop: 24 }]}
          />
          <FsInputWithLabel
            label={'SELECTED DATE'}
            value={moment(date).format('MM/DD/YYYY')}
            editable={false}
            containerStyle={[{ marginTop: 24 }]}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.secondary,
            }}
            onPress={toggleDatePicker}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="calendar"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  SELECT A DIFFERENT DATE
                </FsText>
              </View>
            )}
          />
          <FsButtonActionIcon
            title=""
            style={{
              alignItems: 'center',
              alignContent: 'center',
              marginHorizontal: 10,
              borderRadius: 10,
              marginTop: 20,
              backgroundColor: Colors.green,
            }}
            onPress={confirmValidateForm}
            renderIcon={(color) => (
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <MaterialCommunityIcons
                  name="send"
                  color={color}
                  size={Icons.size.normal}
                />
                <FsText
                  style={{ color: Colors.textLight, paddingHorizontal: 8 }}
                >
                  SEND DAILY REPORT
                </FsText>
              </View>
            )}
          />
          <DateTimePickerModal
            isDarkModeEnabled={theme === 'dark'}
            isVisible={datePickerCurrentVisibility}
            mode="date"
            onConfirm={(date) => {
              setDate(date);
              toggleDatePicker();
            }}
            onCancel={toggleDatePicker}
          />
        </View>
      </ScrollableScreen>
    </Screen>
  );
};

// Exports
export default SendOnDemandReportScreen;
