import React from 'react';
import {
  Platform,
  View,
  Dimensions,
  Image,
  PixelRatio,
  Linking,
} from 'react-native';
import { Container, Button, Header, Body, Title, Spinner } from 'native-base';
import MapView, { Marker, PROVIDER_GOOGLE, Callout } from 'react-native-maps';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { connect } from 'react-redux';
import _ from 'lodash';

import { Styles, Colors, Icons } from '../../constants';
import { FsAlert, FsButton } from '../../components/CustomComponents';
import { FlagLabelMarker } from '../../components';
import { getFlagIcon, getFlagCoordinate } from '../../sharedMethods/flags';
import {
  verifyLocationPermissions,
  getCurrentPosition,
} from '../../sharedMethods/location';

const iosEdgePadding = { top: 50, right: 30, bottom: 50, left: 30 };

const androidEdgePadding = {
  top: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.top),
  right: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.right),
  bottom: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.bottom),
  left: PixelRatio.getPixelSizeForLayoutSize(iosEdgePadding.left),
};

const edgePadding =
  Platform.OS === 'android' ? androidEdgePadding : iosEdgePadding;

class FlagMapScreen extends React.Component {
  constructor(props) {
    super(props);
    const formB = props.navigation.getParam('formB', {});
    const flags = props.navigation.getParam('flags', []);
    const schedule = props.navigation.getParam('schedule', {});
    const currentLoggedInUser = props.navigation.getParam('userData', {});
    const establishedFlags = flags.filter(
      (flag) => !_.isNil(flag.established_gps_lat)
    );
    this.state = {
      formB,
      flags,
      schedule,
      establishedFlags,
      marginBottom: 1,
      loading: true,
      loadingLocationAsync: false,
      creatorLocations: [],
      currentLoggedInUser,
      mapRef: null,
      displayNoFlagsData: true,
    };
  }

  async componentDidMount() {
    await verifyLocationPermissions(Linking, this.props.navigation);
    this.setState({ loading: false });
  }

  fetchCurrentLocationAsync = async () => {
    const currentPosition = await getCurrentPosition();
    return {
      latitude: currentPosition.coords.latitude,
      longitude: currentPosition.coords.longitude,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  };

  moveCameraToCurrentPositionAsync = async () => {
    this.setState({ loadingLocationAsync: true });
    const currentPosition = await this.fetchCurrentLocationAsync();
    this.state.mapRef &&
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
    this.setState({ loadingLocationAsync: false });
  };

  fetchCurrentLocation() {
    return {
      ...this.props.currentLocation,
      latitudeDelta: 0,
      longitudeDelta: 0,
    };
  }

  redirectToCurrentLoc = () => {
    this.moveCameraToCurrentPositionAsync();
    const currentPosition = this.fetchCurrentLocation();
    this.state.mapRef &&
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
  };

  onFlagPress = (flag) => {
    this.props.navigation.navigate('FlagDetailsScreen', {
      currentFlag: flag,
      formB: this.state.formB,
      flags: this.state.flags,
      schedule: this.state.schedule,
    });
  };

  render() {
    if (this.state.loading)
      return (
        <View
          style={{
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            height: '100%',
          }}
        >
          <Spinner color={Colors.secondary} />
        </View>
      );

    return (
      <Container>
        <Header style={{ ...Styles.general.header, paddingTop: 0, height: 56 }}>
          <Button
            onPress={() => {
              this.props.navigation.goBack();
            }}
            style={{ ...Styles.general.headerButton }}
          >
            <MaterialCommunityIcons
              name={'arrow-left'}
              size={Icons.size.big}
              color={Colors.textLight}
              style={[{ top: 1 }, { maxWidth: 20 }, { textAlign: 'center' }]}
            />
          </Button>
          <Body
            style={{ paddingRight: 45, alignItems: 'center', paddingLeft: 0 }}
          >
            <Title style={{ paddingLeft: 0 }}>Open Flags</Title>
          </Body>
        </Header>
        <View style={[{ flex: 1 }]}>
          {!this.state.mapRef && (
            <View
              style={{
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Spinner color={Colors.secondary} />
            </View>
          )}
          <MapView
            {...Platform.select({
              ios: {
                provider: PROVIDER_GOOGLE,
              },
              android: {
                provider: PROVIDER_GOOGLE,
              },
            })}
            ref={(ref) => {
              if (!this.state.mapRef) {
                this.setState({ mapRef: ref });
              }
            }}
            style={[
              { width: Dimensions.get('window').width },
              {
                height:
                  Dimensions.get('window').height -
                  Styles.constant.StackNavigatorHeaderBarHeight,
              },
              { alignSelf: 'center' },
              { flex: 1 },
              { marginBottom: this.state.marginBottom },
            ]}
            mapType="hybrid"
            showsUserLocation={true}
            moveOnMarkerPress={false}
            onLayout={this.onLayoutMap}
            mapPadding={Styles.constant.MapViewEdgePaddingGoogleMaps}
          >
            {this.state.establishedFlags.length > 0 &&
              this.state.establishedFlags.map((flag) => (
                <Marker
                  key={'Marker' + flag.id}
                  onPress={() => this.onFlagPress(flag)}
                  coordinate={getFlagCoordinate(flag)}
                  pinColor={getFlagIcon(flag.type)}
                />
              ))}
            {this.state.establishedFlags.length > 0 &&
              this.state.establishedFlags.map((flag) => (
                <FlagLabelMarker
                  key={'FlagLabelMarker' + flag.id}
                  flag={flag}
                />
              ))}
          </MapView>
          {this.state.mapRef && (
            <RedirectToCurrentLoc
              onPress={this.redirectToCurrentLoc}
              loading={this.state.loadingLocationAsync}
            />
          )}
        </View>
      </Container>
    );
  }

  /**
   * We can't perform actions within the
   * componentDidMount method to manipulate <MapView>
   * as, it would most likely crash on Android devices.
   * Therefore, we need to provide any initializing methods
   * for it, over here.
   */
  onLayoutMap = async () => {
    const { establishedFlags } = this.state;
    const currentPosition = this.fetchCurrentLocation();
    const noEstablishedFlagsPresent = _.isEmpty(establishedFlags);

    if (noEstablishedFlagsPresent && this.state.displayNoFlagsData) {
      this.setState({ displayNoFlagsData: false });
      this.state.mapRef.animateCamera(
        {
          center: currentPosition,
        },
        {
          duration: 500,
        }
      );
      FsAlert.alertOk(
        'No Items Data',
        `The item for this ${this.props.currentOrganizationSettings.form_verbiage} have not been open yet.`
      );
    } else if (!noEstablishedFlagsPresent) {
      const establishedFlagsWithCoordinates =
        establishedFlags.map(getFlagCoordinate);
      this.state.mapRef.fitToCoordinates(
        _.cloneDeep(establishedFlagsWithCoordinates),
        {
          edgePadding,
          animated: true,
        }
      );
    }
  };
}

const RedirectToCurrentLoc = (props) => {
  return (
    <Callout
      style={[
        { alignSelf: 'flex-end' },
        { bottom: 30 },
        { zIndex: 99999999 },
        { right: 10 },
      ]}
    >
      <FsButton
        style={[
          { height: 60 },
          { width: 60 },
          { borderRadius: 30 },
          { backgroundColor: '#ffffff' },
          { alignSelf: 'center' },
          { alignItems: 'center' },
          { justifyContent: 'center' },
          Styles.general.shadowLightBorder,
          Styles.general.shadow,
        ]}
        onPress={props.onPress}
      >
        {props.loading ? (
          <Spinner color={Colors.secondary} />
        ) : (
          <Image
            source={require('../../assets/images/ic_gps_indicator.png')}
            style={{ tintColor: '#6d6d6d', width: 40, height: 40 }}
          />
        )}
      </FsButton>
    </Callout>
  );
};

const mapStateToProps = (state) => {
  return {
    currentLocation: state.location,
    currentOrganizationSettings:
      state.organizations.currentOrganization.settings,
  };
};

export default connect(mapStateToProps)(FlagMapScreen);
