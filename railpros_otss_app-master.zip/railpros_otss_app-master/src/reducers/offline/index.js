// Imports: Reducers
import { combineReducers } from 'redux';

import safeClear from './SafeClear';

// Redux: Offline Root Reducer
const rootReducer = {
  safeClear: combineReducers(safeClear),
};

// Exports
export default rootReducer;
