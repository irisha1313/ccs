export const initialState = {
  logs: [],
  pocs: [],
  pocsStatus: [],
  entries: [],
};
