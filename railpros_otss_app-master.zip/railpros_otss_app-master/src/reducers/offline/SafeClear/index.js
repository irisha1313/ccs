import logs from './logs';
import pocs from './pocs';
import pocsStatus from './pocsStatus';
import entries from './entries';

export default {
  logs,
  pocs,
  pocsStatus,
  entries,
};
