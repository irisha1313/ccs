// Imports: Reducers
import { combineReducers } from 'redux';
import { reducer as formReducer } from 'redux-form';
import auth from './auth';
import common from './common';
import formbs from './formbs';
import flagsByFormB from './flagsByFormB';
import schedulesByFormB from './schedulesByFormB';
import organizations from './organizations';
import location from './location';

import safeClear from './SafeClear';
import offline from './offline';

// Redux: Root Reducer
const rootReducer = {
  auth,
  common,
  formbs,
  flagsByFormB,
  schedulesByFormB,
  organizations,
  location,
  safeClear: combineReducers(safeClear),
  form: formReducer,
  offline: combineReducers(offline),
};

// Exports
export default rootReducer;
