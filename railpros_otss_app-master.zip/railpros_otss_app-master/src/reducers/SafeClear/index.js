import user from './user';
import logs from './logs';
import currentLog from './currentLog';

export default {
  user,
  logs,
  currentLog,
};
