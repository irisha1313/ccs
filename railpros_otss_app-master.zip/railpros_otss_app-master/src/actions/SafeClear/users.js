import api from '../../utils/api';

export const getStatsForUser = async (userId, logId) => {
  const result = await api.get(`safeclear/poc/stats/${userId}/log/${logId}`);
  return result.data;
};
