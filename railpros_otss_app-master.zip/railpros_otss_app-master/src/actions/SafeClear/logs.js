import { createAsyncThunk, unwrapResult } from '@reduxjs/toolkit';
import { omit } from 'lodash';

import api from '../../utils/api';
import { ActionTypes } from '../../constants/SafeClear';
import ErrorMessages from '../../constants/ErrorMessages';
import { updateCurrentLogSync } from './currentLog';
import {
  getLogsByUserIdOffline,
  createOfflineLog,
  updateLogOffline,
} from './offline/logs';

export const getLogsByUserId = createAsyncThunk(
  ActionTypes.SETLOGS,
  async (payload, thunkAPI) => {
    try {
      const result = await api.get(
        `/safeclear/log/${payload.userId}/${payload.date}`
      );
      return result.data;
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        return getLogsByUserIdOffline(payload, thunkAPI);
      }
      throw error.message;
    }
  }
);

export const createLog = createAsyncThunk(
  ActionTypes.CREATELOG,
  async ({ log, userId }, thunkAPI) => {
    try {
      const result = await api.post(`/safeclear/log/create/${userId}`, {
        ...omit(log, 'jobNumber'),
        job_number: log.jobNumber,
      });
      return result.data;
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const rawResult = await thunkAPI.dispatch(
          createOfflineLog({ log, userId })
        );
        const unwrappedResult = unwrapResult(rawResult);
        return unwrappedResult;
      }
      throw error.message;
    }
  }
);

export const updateLog = createAsyncThunk(
  ActionTypes.UPDATELOG,
  async (payload, thunkAPI) => {
    try {
      const result = await api.patch(`/safeclear/log/${payload.id}`, {
        ...omit(payload, ['id', 'jobNumber']),
        job_number: payload.jobNumber,
      });
      const updatedLog = result.data;
      await thunkAPI.dispatch(updateCurrentLogSync({ log: updatedLog }));
      return updatedLog;
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const offlineUpdatePayload = {
          ...omit(payload, ['jobNumber']),
          job_number: payload.jobNumber,
        };
        await thunkAPI.dispatch(updateLogOffline(offlineUpdatePayload));
        await thunkAPI.dispatch(
          updateCurrentLogSync({ log: offlineUpdatePayload })
        );
        return offlineUpdatePayload;
      }
      throw error.message;
    }
  }
);
