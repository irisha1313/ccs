import { createAsyncThunk, unwrapResult } from '@reduxjs/toolkit';

import api from '../../utils/api';
import ErrorMessages from '../../constants/ErrorMessages';
import { ActionTypes } from '../../constants/SafeClear';
import {
  getCurrentLogOffline,
  createUserOffline,
  updateUserOffline,
  updateUserStatusOffline,
  createEntryOffline,
  createNoteOffline,
} from './offline/currentLog';

export const getCurrentLog = createAsyncThunk(
  ActionTypes.SETCURRENTLOG,
  async ({ logId, underReview }, thunkAPI) => {
    try {
      const requestURL = underReview
        ? `/safeclear/log/${logId}/submitted-preview`
        : `/safeclear/log/${logId}`;
      const result = await api.get(requestURL);
      const offlineResult = getCurrentLogOffline(logId, thunkAPI, true);

      return { ...result.data, ...offlineResult };
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const result = getCurrentLogOffline(logId, thunkAPI);

        if (result) {
          return result;
        }
      }
      throw error;
    }
  }
);

export const updateCurrentLogSync = createAsyncThunk(
  ActionTypes.UPDATECURRENTLOG,
  ({ log: updatedLogData }) => {
    return updatedLogData;
  }
);

export const submitLog = async (logId) => {
  const result = await api.post(`/safeclear/log/${logId}/submit`, {
    logId,
  });
  return result.data;
};

export const updateUserStatus = createAsyncThunk(
  ActionTypes.UPDATEUSERSTATUS,
  async ({ userId, logId, fromStatus, toStatus, reason }, thunkAPI) => {
    try {
      const result = await api.patch(
        `/safeclear/poc/${userId}/log/${logId}/status`,
        {
          poc_id: userId,
          log_id: logId,
          status: toStatus,
          reason,
        }
      );
      return {
        userId,
        fromStatus,
        toStatus,
        created_at: result.data.created_at,
      };
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const rawResult = await thunkAPI.dispatch(
          updateUserStatusOffline(
            { userId, logId, fromStatus, toStatus, reason },
            thunkAPI
          )
        );
        const unwrappedResult = unwrapResult(rawResult);
        return {
          userId,
          fromStatus,
          toStatus,
          created_at: unwrappedResult.created_at,
        };
      }
    }
  }
);

export const createEntry = createAsyncThunk(
  ActionTypes.CREATEENTRY,
  async ({ entry, logId }, thunkAPI) => {
    try {
      const result = await api.post('/safeclear/log/entry', {
        ...entry,
        log_id: logId,
      });
      return result.data;
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const rawResult = await thunkAPI.dispatch(
          createEntryOffline({ entry, logId }, thunkAPI)
        );
        const unwrappedResult = unwrapResult(rawResult);
        return unwrappedResult.data;
      }
    }
  }
);

export const createNote = createAsyncThunk(
  ActionTypes.CREATENOTE,
  async ({ entryId, note }, thunkAPI) => {
    try {
      const result = await api.post('/safeclear/log/entry/note', {
        note,
        entry_id: entryId,
      });
      return { newNote: result.data, entryId };
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const rawResult = await thunkAPI.dispatch(
          createNoteOffline({ entryId, note }, thunkAPI)
        );
        const unwrappedResult = unwrapResult(rawResult);
        return { newNote: unwrappedResult.newNote, entryId };
      }
    }
  }
);

export const createUser = createAsyncThunk(
  ActionTypes.CREATEUSER,
  async ({ user, logId }, thunkAPI) => {
    try {
      const result = await api.post('/safeclear/poc', {
        log_id: logId,
        ...user,
      });
      return result.data;
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        const rawResult = await thunkAPI.dispatch(
          createUserOffline({ user, logId }, thunkAPI)
        );
        const unwrappedResult = unwrapResult(rawResult);
        return unwrappedResult;
      }
    }
  }
);

export const updateUser = createAsyncThunk(
  ActionTypes.UPDATEUSER,
  async ({ id, data }, thunkAPI) => {
    try {
      const result = await api.patch(`/safeclear/poc/${id}`, data);
      return { ...data, ...result.data };
    } catch (error) {
      if (error.message === ErrorMessages.NOINTERNET) {
        await thunkAPI.dispatch(updateUserOffline({ id, data }));
        return data;
      }
    }
  }
);
