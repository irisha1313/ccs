import { createAsyncThunk } from '@reduxjs/toolkit';
import { omit } from 'lodash';
import { v4 } from 'uuid';

import { OfflineActionTypes } from '../../../constants/SafeClear';
import api from '../../../utils/api';

export const getLogsByUserIdOffline = async (payload, thunkAPI) => {
  const currentState = thunkAPI.getState();
  const offlineLogs = currentState.offline.safeClear.logs;
  const lastOnlineLogs = currentState.safeClear.logs.unsubmitted;

  const presentInArray = {};

  const offlineFirstLogsArray = [...offlineLogs, ...lastOnlineLogs].filter(
    (log) => !presentInArray[log.id] && (presentInArray[log.id] = true)
  );

  return {
    submitted: [],
    unsubmitted: offlineFirstLogsArray,
    loading: false,
    editingLog: false,
  };
};

export const createOfflineLog = createAsyncThunk(
  OfflineActionTypes.CREATEOFFLINELOG,
  async ({ log, userId }) => {
    return {
      ...omit(log, 'jobNumber'),
      id: v4(),
      created_by: userId,
      job_number: log.jobNumber,
      submitted_at: null,
      submitted_by: null,
    };
  }
);

export const updateLogOffline = createAsyncThunk(
  OfflineActionTypes.UPDATELOGOFFLINE,
  async (payload, thunkAPI) => {
    const currentState = thunkAPI.getState();
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;

    return { data: payload, lastOnlineLogPayload };
  }
);

export const syncLogs = async (logSettingsToSync) => {
  const result = await api.post('/safeclear/log/sync', logSettingsToSync);
  return result.data;
};

export const syncEntries = async (entriesToSync) => {
  const result = await api.post('/safeclear/log/entry/sync', entriesToSync);
  return result.data;
};

export const syncEntryNotes = async (entryNotesToSync) => {
  const result = await api.post(
    '/safeclear/log/entry/note/sync',
    entryNotesToSync
  );
  return result.data;
};

export const syncPOCs = async (POCsToSync) => {
  const result = await api.post('/safeclear/poc/sync', POCsToSync);
  return result.data;
};

export const syncPOCsStatus = async (POCsStatusToSync) => {
  const result = await api.post('/safeclear/poc/stats/sync', POCsStatusToSync);
  return result.data;
};

export const syncPOCsStatusLogs = async (POCsStatusLogs) => {
  const result = await api.post(
    '/safeclear/poc/stats/logs/sync',
    POCsStatusLogs
  );
  return result.data;
};

export const syncPOCsStatusLogsReasons = async (POCsStatusLogsReasons) => {
  const result = await api.post(
    '/safeclear/poc/stats/logs/reason/sync',
    POCsStatusLogsReasons
  );
  return result.data;
};

export const resetOfflineStorage = createAsyncThunk(
  OfflineActionTypes.RESETOFFLINESTORAGE,
  () => {
    return;
  }
);
