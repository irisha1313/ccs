import { createAsyncThunk } from '@reduxjs/toolkit';
import { v4 } from 'uuid';
import moment from 'moment-timezone';
import omit from 'lodash/omit';

import { OfflineActionTypes } from '../../../constants/SafeClear';

export const getCurrentLogOffline = (
  logId,
  thunkAPI,
  skipLastOnline = false
) => {
  const currentState = thunkAPI.getState();
  const offlineLogResult = currentState.offline.safeClear.logs.find(
    ({ id }) => id === logId
  );

  if (skipLastOnline) {
    return offlineLogResult || {};
  }

  const lastOnlineLogResult = currentState.safeClear.logs.unsubmitted.find(
    ({ id }) => id === logId
  );

  return offlineLogResult || lastOnlineLogResult;
};

export const createUserOffline = createAsyncThunk(
  OfflineActionTypes.CREATEUSEROFFLINE,
  async ({ user, logId }, thunkAPI) => {
    const currentState = thunkAPI.getState();
    const currentUserId = currentState.auth.user.id;
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;

    return {
      data: {
        ...user,
        log_id: logId,
        id: v4(),
        created_by: currentUserId,
        created_at: moment.utc().format(),
      },
      lastOnlineLogPayload,
    };
  }
);

export const updateUserOffline = createAsyncThunk(
  OfflineActionTypes.UPDATEUSEROFFLINE,
  async (
    { id, data: { log_id, statusAttributeName, name, phone, milepost } },
    thunkAPI
  ) => {
    const currentState = thunkAPI.getState();
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;

    return {
      id,
      log_id,
      statusAttributeName,
      name,
      phone,
      milepost,
      lastOnlineLogPayload,
    };
  }
);

export const updateUserStatusOffline = createAsyncThunk(
  OfflineActionTypes.UPDATEUSERSTATUSOFFLINE,
  async ({ userId, logId, fromStatus, toStatus, reason }, thunkAPI) => {
    const currentState = thunkAPI.getState();
    const currentUserId = currentState.auth.user.id;
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;

    return {
      data: {
        userId,
        logId,
        fromStatus,
        toStatus,
        reason,
        created_by: currentUserId,
        created_at: moment.utc().format(),
      },
      lastOnlineLogPayload,
    };
  }
);

export const createEntryOffline = createAsyncThunk(
  OfflineActionTypes.CREATEENTRYOFFLINE,
  async ({ entry, logId }, thunkAPI) => {
    const currentState = thunkAPI.getState();
    const currentUserId = currentState.auth.user.id;
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;

    return {
      data: {
        ...omit(entry, 'logId'),
        id: v4(),
        log_id: logId,
        notes: [],
        created_by: currentUserId,
        created_at: moment.utc().format(),
      },
      lastOnlineLogPayload,
    };
  }
);

export const createNoteOffline = createAsyncThunk(
  OfflineActionTypes.CREATENOTEOFFLINE,
  async ({ entryId, note }, thunkAPI) => {
    const currentState = thunkAPI.getState();
    const currentUserId = currentState.auth.user.id;
    const lastOnlineLogPayload = currentState.safeClear.currentLog.data;
    const lastOnlineEntryPayload =
      currentState.safeClear.currentLog.data.entries.find(
        (existingEntry) => existingEntry.id === entryId
      );

    const newNote = {
      id: v4(),
      entry_id: entryId,
      note,
      created_by: currentUserId,
      created_at: moment.utc().format(),
    };
    return { newNote, lastOnlineLogPayload, lastOnlineEntryPayload };
  }
);
