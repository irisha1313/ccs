import { RNS3 } from 'react-native-aws3';
import api from '../utils/api';

const buildOptions = (keyPrefix) => ({
  keyPrefix,
  bucket: 'railpros-otss-job-briefings',
  region: 'us-east-2',
  accessKey: 'AKIAIA5TV4Y3A73JC7OA',
  secretKey: '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',
  successActionStatus: 201,
});

const mimeTypes = {
  mov: 'video/quicktime',
  jpg: 'image/jpeg',
  png: 'image/png',
  mp3: 'audio/mpeg',
  mp4: 'video/mp4',
  mpe: 'video/mpeg',
  mpeg: 'video/mpeg',
  caf: 'audio/x-caf',
  json: 'application/json',
  m4a: 'audio/m4a',
};

export const uploadBugReportImages = async (bugReportImages, path) => {
  const options = buildOptions(path);

  try {
    let imageFileName = `https://railpros-otss-job-briefings.s3.us-east-2.amazonaws.com/${path}`;
    const uploadedImagesNames = await Promise.all(
      bugReportImages.map(async (uri) => {
        const file = {
          uri,
          name: uri.split('/')[uri.split('/').length - 1],
          type: mimeTypes[uri.split('.')[uri.split('.').length - 1]],
        };
        await RNS3.put(file, options);
        return `${imageFileName}${file.name}`;
      })
    );
    return uploadedImagesNames;
  } catch (error) {
    console.log('\n\n', error.message, '\n\n');
    return false;
  }
};

export const sendBugReport = async (data) =>
  api.post('/bug-reports', data);
