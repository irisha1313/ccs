import api from '../utils/api';
import _ from 'lodash';
import { ActionTypes } from '../constants/';
import { getOrganizationDataById } from './organizations';
import {
  verifyIfWillBeCancelledEarly,
  getEarlyCancelConfirmation,
  getOngoingEarlyCancel,
} from '../sharedMethods/flags';
import { getFormb } from './formbs';

export const updateFlags =
  ({ currentUserId, flagsByType, formBId }) =>
  async (dispatch) => {
    if (flagsByType.updated?.length > 0) {
      await api.post(
        `/protections/${formBId}/items/_bulk-upsert/for-user/${currentUserId}`,
        {
          flags: flagsByType.updated,
        }
      );
    }
    if (flagsByType.removed?.length > 0) {
      await api.post(`/protections/${formBId}/items/_bulk-delete`, {
        ids: flagsByType.removed.map(({ id }) => id),
      });
    }
    await dispatch(getFormb(formBId));
  };

export const establishFlag =
  ({ flagId, formBId, flagPayload }) =>
  async (dispatch) => {
    await api.post(
      `/protections/${formBId}/items/${flagId}/_establish`,
      flagPayload
    );
    await dispatch(getFormb(formBId));
  };

export const createFlags =
  ({ flags, formBId, currentUserId }) =>
  async (dispatch) => {
    await api.post(
      `/protections/${formBId}/items/_bulk-upsert/for-user/${currentUserId}`,
      { flags }
    );
    await dispatch(getFormb(formBId));
  };

export const validateFlags =
  ({ flags }) =>
  async () => {
    const { data } = await api.post(
      `/protections/${null}/items/_bulk-upsert/for-user/validation`,
      { flags }
    );
    return data;
};


export const toggleFlagEstablishment =
  (flag, userId, orgId) => async (dispatch) => {
    let newProtectionExpirationTime;

    // if the flag's next state is to
    // be closed and the current protection
    // hasn't been canceled yet then,
    // a cancellation process should take place
    if (flag.is_established) {
      const earlyExpirationDetails = await verifyIfWillBeCancelledEarly(
        flag.protection_id
      );

      if (earlyExpirationDetails) {
        const {
          originalExpirationTime,
          newExpirationTimeInUTC,
          protectionTimezone,
        } = earlyExpirationDetails;
        const earlyCancelConfirmed = await getEarlyCancelConfirmation(
          originalExpirationTime,
          newExpirationTimeInUTC,
          protectionTimezone
        );

        // if a flag is being closed before time
        // and it's not confirmed that an early cancel
        // is taking place then, toggling the flag
        // shouldn't be possible
        if (!earlyCancelConfirmed) {
          return flag;
        }

        // if the early cancel has been confirmed
        // we proceed on feeding the backend with this new data
        newProtectionExpirationTime = newExpirationTimeInUTC;
      }
    } else {
      // if there's an ongoing cancellation
      // we should prevent flags from being
      // opened/reopened

      const isOngoingEarlyCancel = await getOngoingEarlyCancel(
        flag.protection_id
      );

      if (isOngoingEarlyCancel) {
        return flag;
      }
    }
    if (newProtectionExpirationTime) {
      await api.post(
        `/protections/${flag.protection_id}/items/${flag.id}/_toggle`,
        {
          newProtectionExpirationTime,
        }
      );
    } else {
      await api.post(
        `/protections/${flag.protection_id}/items/${flag.id}/_toggle`
      );
    }
    const updatedFormB = await dispatch(getFormb(flag.protection_id));
    await dispatch(getOrganizationDataById(orgId));

    const updatedFlag = updatedFormB.items.find(({ id }) => id === flag.id);
    return updatedFlag;
  };

export const pairFlags =
  ({ sourceFlag, targetFlag }) =>
  async (dispatch) => {
    await api.post(
      `/protections/${sourceFlag.protection_id}/items/${sourceFlag.id}/_pair`,
      {
        pairFlag: targetFlag.id,
      }
    );
    await dispatch(getFormb(sourceFlag.protection_id));
    return sourceFlag;
  };

export const unpairFlags =
  ({ sourceFlag, targetFlag }) =>
  async (dispatch) => {
    await api.post(
      `/protections/${sourceFlag.protection_id}/items/${sourceFlag.id}/_unpair`,
      {
        pairFlag: targetFlag.id,
      }
    );
    await dispatch(getFormb(sourceFlag.protection_id));
    return sourceFlag;
  };
