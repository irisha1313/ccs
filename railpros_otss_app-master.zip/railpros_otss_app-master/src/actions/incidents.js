import api from '../utils/api';

export const getIncidents = async formBId => {
    const { data } = await api.get(`/protections/${formBId}/incidents`);
    return data;
};

export const createIncidentReport = async (formBId, payload) => {
    const { data } = await api.post(`/protections/${formBId}/incidents`, payload);
    return data;
};
