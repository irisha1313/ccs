import api from '../utils/api';
import { ActionTypes } from '../constants/';
import { getOrganizationDataById } from './organizations';

export const getFormbsRaw = async (payload, retries = 0) => {
  try {
    const { data } = await api.get('/protections', { params: payload });
    return data;
  } catch (error) {
    // retrying form bs information fetch for a maximum number of times of 3
    if (retries < 3) {
      return getFormbsRaw(payload, retries + 1);
    } else {
      throw error;
    }
  }
};

export const getFormbs = (payload) => async (dispatch) => {
  dispatch({
    type: ActionTypes.SETFORMBS,
    data: await getFormbsRaw(payload),
  });
};

export const getFormbIdsByUserIdSync = async (userId) => {
  const result = await api.get(`/users/${userId}/protection/ids`);
  return result.data;
};

export const getFormb = (id) => async (dispatch) => {
  const { data } = await api.get(`/protections/${id}`);
  dispatch({
    type: ActionTypes.SETFORMB,
    data,
  });

  return data;
};

export const unarchiveFormB = async (formBId, payload) => {
  const { data } = await api.post(
    `/protections/${formBId}/_unarchive`,
    payload
  );
  return data;
};

export const getAllTags = async () => {
  const { data } = await api.get('/tags');
  return data;
};

export const addTag = async (name) => {
  const { data } = await api.post('/tags', { name });
  return data;
};

export const unarchiveAndTransferFormB = async (formBId, payload) => {
  const { data } = await api.post(`/protections/${formBId}/_transfer`, payload);
  return data;
};

export const updateFormB = (formb) => async (dispatch) => {
  await api.patch(`/protections/${formb.id}`, formb);
  dispatch(getOrganizationDataById(formb.organization_id));
  return dispatch({
    type: ActionTypes.UPDATEFORMBS,
    data: formb,
  });
};

export const createFormB = (formb, currentUserId) => async (dispatch) => {
  const { data } = await api.post(
    `/protections/_for-user/${currentUserId}`,
    formb
  );
  dispatch(getOrganizationDataById(formb.organization_id));
  dispatch({
    type: ActionTypes.CREATEFORMBS,
    data: {
      ...formb,
      id: data.id,
    },
  });
  return data.id;
};

export const deleteFormB = (id, orgId) => async (dispatch) => {
  await api.delete(`/protections/${id}`);
  dispatch(getOrganizationDataById(orgId));
  return dispatch({
    type: ActionTypes.DELETEFORMB,
    data: id,
  });
};

export const stopEarlyCancel = (id) => async (dispatch) => {
  const stopEarlyCanceOperation = await api.patch(
    `/protections/${id}/early_cancel/_stop`
  );

  if (stopEarlyCanceOperation.status === 204) {
    await dispatch({
      type: ActionTypes.UPDATEFORMBATTRIBUTE,
      data: {
        id,
        expires_at: null,
      },
    });
  }
  return stopEarlyCanceOperation;
};
