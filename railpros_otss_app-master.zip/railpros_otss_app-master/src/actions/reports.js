import api from '../utils/api';
import _ from 'lodash';

export const sendDailyReportOnDemand = async (
  organization_id,
  emails,
  date
) => {
  await api.post('/reports/eod', {
    organization_id,
    emails,
    date,
  });
};

export const sendIncidentReport = async (user, date) => {
  await api.post('/reports/audit', {
    user,
    date,
  });
};
