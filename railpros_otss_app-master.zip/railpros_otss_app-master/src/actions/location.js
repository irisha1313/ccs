import { ActionTypes } from '../constants/';

export const setLocation = (location = {}) => ({
    type: ActionTypes.SETLOCATION,
    location,
});
