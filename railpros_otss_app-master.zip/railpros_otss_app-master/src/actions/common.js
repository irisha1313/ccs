import api from '../utils/api';
import { ActionTypes } from '../constants/';

export const loading = (bool) => ({
  type: ActionTypes.LOADING,
  isLoading: bool,
});

export const showModal = (bool) => ({
  type: ActionTypes.SHOWMODAL,
  showModal: bool,
});

export const showIntro = (bool) => ({
  type: ActionTypes.SHOWINTRO,
  showIntro: bool,
});

// export const getFormBScreenRedirectionPermission = (
//   formBId,
//   currentUserId,
//   retries = 0
// ) => async (dispatch) => {
//   try {
//     const fetchResult = await api.axios.post('/api/user/getFormBPermission', {
//       formBId,
//       currentUserId,
//     });
//     if (fetchResult.status == 200) {
//       const resultData = fetchResult.data.data;
//       if (!resultData.permissionMessage) {
//         const organizationData = await api.axios.post(
//           '/api/organization/data',
//           { orgId: resultData.orgId }
//         );
//         await dispatch({
//           type: ActionTypes.SETCURRENTORGANIZATION,
//           data: organizationData.data.data,
//         });
//         return {
//           creatorData: resultData.creatorData,
//         };
//       }
//       return {
//         error: resultData.permissionMessage,
//       };
//     }
//     return false;
//   } catch (error) {
//     if (retries < 3) {
//       return dispatch(
//         getFormBScreenRedirectionPermission(formBId, currentUserId, retries + 1)
//       );
//     } else {
//       throw error;
//     }
//   }
// };
