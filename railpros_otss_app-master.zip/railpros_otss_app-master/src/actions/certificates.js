import api from '../utils/api';
import { ActionTypes } from '../constants/';
import { getOrganizationDataById } from './organizations';

export const getCertificateOptionsByOrgId = async (orgId) => {
  try {
    const result = await api.get(`organizations/${orgId}/certificates`);
    return result.data;
  } catch (error) {
    throw error;
  }
};

export const updateCertificates =
  (payload, orgId, userId) => async (dispatch) => {
    const updateOperation = await api.patch(
      `organizations/${orgId}/users/${userId}/certificates`,
      payload
    );
    if (updateOperation.status == 200) {
      dispatch(getOrganizationDataById(orgId));
    }
    return payload;
  };
