import api from '../utils/api';

export const createJobBriefing = async (jobBriefing) => {
  try {
    const jobBriefingCreationResult = await api.post(
      '/job-briefings',
      jobBriefing
    );
    return jobBriefingCreationResult.data;
  } catch (error) {
    return false;
  }
};
