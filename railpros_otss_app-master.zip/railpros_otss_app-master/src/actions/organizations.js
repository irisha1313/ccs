import api from '../utils/api';
import _ from 'lodash';
import { ActionTypes } from '../constants/';
import { USER_ROLES } from '../utils/userRoles';

const groupUsersByRole = (users) =>
  users.reduce((acc, user) => {
    acc[user.role_id] = acc[user.role_id] || [];
    acc[user.role_id].push(user);
    return acc;
  }, {});

export const getUserOrganizations = () => async (dispatch) => {
  const { data } = await api.get('/me/organizations');
  dispatch({
    type: ActionTypes.SETORGANIZATIONS,
    data,
  });
};

export const getOrganizationDataById = (orgId) => async (dispatch) => {
  const [organization, usersByRole] = await Promise.all([
    api.get(`/organizations/${orgId}`).then(({ data }) => data),
    api
      .get(`/organizations/${orgId}/users`)
      .then(({ data }) => groupUsersByRole(data)),
  ]);

  return dispatch({
    type: ActionTypes.SETCURRENTORGANIZATION,
    data: {
      settings: organization,
      flagmen: usersByRole[USER_ROLES.Flagmen],
      management: [
        ...(usersByRole[USER_ROLES.Director] || []),
        ...(usersByRole[USER_ROLES.OrgManager] || []),
        ...(usersByRole[USER_ROLES.Supervisor] || []),
      ],
    },
  });
};

export const getUserOrganization = () => async (dispatch) => {
  const { data } = await api.get('/me/organization');
  const organization = data;
  if (!organization) throw new Error('User has no linked organizations');

  return dispatch(getOrganizationDataById(organization.id));
};

export const getAllOrganizations = async () => {
  try {
    const result = await api.get('/organizations');
    return result.data;
  } catch (error) {
    throw error;
  }
};

export const updateOrganization = async (id, newOrgData) => {
  const { data } = await api.patch(`/organizations/${id}`, newOrgData);
  return data;
};

export const clearOrganizationData = async (dispatch) => {
  return dispatch({
    type: ActionTypes.SETCURRENTORGANIZATION,
    data: {
      flagmen: [],
      management: [],
      settings: {},
    },
  });
};
