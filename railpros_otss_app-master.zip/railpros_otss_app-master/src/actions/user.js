import omit from 'lodash/omit';
import Constants from 'expo-constants';
import { getOrganizationDataById } from './organizations';

import api, {
  getUserFromAccessToken,
  refreshTokens,
  updateTokens,
} from '../utils/api';
import { ActionTypes } from '../constants/';
import { getLanguage } from '../utils/common';

const normalizeFullUserData = ({ appVersion, time, ...user }) => ({
  ...user,
  ...time,
  ...(appVersion && { app_version: appVersion?.version }),
});

export const login = (payload) => async (dispatch) => {
  dispatch({ type: ActionTypes.LOADING, isLoading: true });
  try {
    const result = await api.post('/auth/login', payload);
    updateTokens(result.data);
    const user = getUserFromAccessToken();
    dispatch({
      type: ActionTypes.LOGIN,
      data: user,
    });
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
    return result;
  } catch (error) {
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
    throw error;
  }
};

export const ssoLogin = (payload) => async (dispatch) => {
  dispatch({ type: ActionTypes.LOADING, isLoading: true });
  try {
    const result = await api.get('/auth/azure/by-token', {
      headers: { Authorization: `Bearer ${payload.accessToken}` },
    });
    updateTokens(result.data);
    const user = getUserFromAccessToken();
    dispatch({
      type: ActionTypes.LOGIN,
      data: user,
    });
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
    return result;
  } catch (error) {
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
    throw error;
  }
};

export const fetchFullUserData = () => async (dispatch) => {
  try {
    const { data } = await api.get('/me');
    const normalizedData = normalizeFullUserData(data);
    dispatch({
      type: ActionTypes.LOGIN,
      data: normalizedData,
    });
    return normalizedData;
  } finally {
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
  }
};

export const autoLogin = () => async (dispatch) => {
  dispatch({ type: ActionTypes.LOADING, isLoading: true });
  try {
    await refreshTokens();
    const user = getUserFromAccessToken();
    dispatch({
      type: ActionTypes.LOGIN,
      data: user,
    });
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
  } catch (error) {
    dispatch({ type: ActionTypes.LOADING, isLoading: false });
    throw error;
  }
};

export const logoutUser = () => (dispatch) => {
  return dispatch({ type: ActionTypes.RESETSTATE });
};

export const setLanguage = (payloads) => (dispatch) => {
  dispatch({ type: ActionTypes.SHOWMODAL, showModal: false });
  return dispatch({
    type: ActionTypes.LANGUAGECODE,
    language: getLanguage(payloads.id),
    languageId: payloads.id,
    languageSet: payloads.set,
  });
};

export const createUser = (organizationId, newUserData) => async (dispatch) => {
  await api.post(`/organizations/${organizationId}/users`, newUserData);
  dispatch(getOrganizationDataById(organizationId));
};

export const deleteUser = (userId, organisationId) => async (dispatch) => {
  await api.delete(`/users/${userId}`);
  dispatch(getOrganizationDataById(organisationId));
};

export const transferUser =
  (userId, newOrgId, currentOrgId) => async (dispatch) => {
    await api.post(`/organizations/${currentOrgId}/users/${userId}/_transfer`, {
      organizationId: newOrgId,
    });
    dispatch(getOrganizationDataById(currentOrgId));
  };

export const reportForDuty = (userId, data) => async (dispatch) => {
  console.log(`/users/${userId}/_report-for-duty`, data);
  const user = await api
    .post(`/users/${userId}/_report-for-duty`, data)
    .then(({ data }) => normalizeFullUserData(data));
    console.log(user);
  return dispatch({ type: ActionTypes.UPDATEUSER, data: user });
};

export const debrief = (userId, data) => async (dispatch) => {
  const user = await api
    .post(`/users/${userId}/_debrief`, data)
    .then(({ data }) => normalizeFullUserData(data));
  return dispatch({ type: ActionTypes.UPDATEUSER, data: user });
};

export const forcedDebrief = async (userId, data) =>
  api.post(`/users/${userId}/_debrief`, data);

export const updateUser = (data) => async (dispatch) => {
  const user = await api
    .patch('/me', omit(data, ['control_panel_access']))
    .then(({ data }) => normalizeFullUserData(data));
  return dispatch({ type: ActionTypes.UPDATEUSER, data: user });
};

export const sendDownloadURLToPhone = () => api.post('/me/_send-download-url');

export const getRoles = async () => {
  const { data } = await api.get('/roles');
  return data;
};

export const getExcludedUsersFromFormBCallNotifications = async (formBId) => {
  const operationSuccess = await api.post('/excluded_from_call_notifications', {
    formBId,
  });
  return operationSuccess.data.data;
};

export const addRegisterDeviceForUser = async (userId, deviceToken) => {
  await api.post('/me/_register-device', {
    token: deviceToken,
  });
};

export const syncAppVersion = async (appVersion) => {
  if (appVersion !== Constants.expoConfig.version) {
    await api.post('/me/update-app-version', {
      version: Constants.expoConfig.version,
    });
  }
};

export const getExistingUsersSync = async (organizationId) => {
  const { data } = await api.get(
    `/organizations/${organizationId}/users/metadata`
  );
  return data;
};

export const saveLocation = async (deviceId, location) => {
  const operationSuccess = await api.post('/save-position', {
    deviceId,
    location,
  });
  return operationSuccess.data.data;
};

export const sendPastDutyReminder = async (userId) => {
  await api.post(`/users/${userId}/_past-shift-reminder`);
};
