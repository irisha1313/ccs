import api from '../utils/api';

export const getExcludedUsersFromFormBCallNotifications = async (formBId) => {
  const { data } = await api.get(
    `/protections/${formBId}/users?disabledCallNotifications=1`
  );
  return data;
};

export const updateIdsFromManagementExcludedFromNotifications = async (
  payload
) => {
  const { idsFromManagementExcludedFromNotifications, protectionId } = payload;
  const operationSuccess = await api.patch(
    `/protections/${protectionId}/users/disabled_call_notifications`,
    idsFromManagementExcludedFromNotifications
  );
  return operationSuccess.data;
};
